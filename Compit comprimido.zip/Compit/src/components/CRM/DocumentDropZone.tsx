import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import { FileIcon, BoltIcon, CheckCircleIcon, AlertIcon } from "../../icons";
import Badge from "../ui/badge/Badge";
import Alert from "../ui/alert/Alert";

interface DocumentDropZoneProps {
  onDocumentProcessed: (extractedData: any) => void;
  onError?: (error: string) => void;
}

export default function DocumentDropZone({ onDocumentProcessed, onError }: DocumentDropZoneProps) {
  const [processing, setProcessing] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [extractionResults, setExtractionResults] = useState<any[]>([]);

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    setProcessing(true);
    setUploadedFiles((prev) => [...prev, ...acceptedFiles]);

    try {
      for (const file of acceptedFiles) {
        // Crear FormData para enviar el archivo
        const formData = new FormData();
        formData.append("document", file);

        // Llamar al endpoint de extracción de datos
        const API_BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";
        const token = localStorage.getItem("token");
        const response = await fetch(`${API_BASE_URL}/ai/extract-document-data`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
          },
          body: formData,
        });

        if (!response.ok) {
          throw new Error("Error al procesar documento");
        }

        const result = await response.json();
        setExtractionResults((prev) => [...prev, { file: file.name, data: result }]);
        
        // Llamar al callback con los datos extraídos
        if (result.extractedData || result.contactCreated) {
          onDocumentProcessed(result);
        }
      }
    } catch (error: any) {
      console.error("Error procesando documentos:", error);
      if (onError) {
        onError(error.message || "Error al procesar documentos");
      }
    } finally {
      setProcessing(false);
    }
  }, [onDocumentProcessed, onError]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "application/pdf": [".pdf"],
      "image/png": [".png"],
      "image/jpeg": [".jpg", ".jpeg"],
      "application/msword": [".doc"],
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"],
    },
    multiple: true,
  });

  const removeFile = (index: number) => {
    setUploadedFiles((prev) => prev.filter((_, i) => i !== index));
    setExtractionResults((prev) => prev.filter((_, i) => i !== index));
  };

  return (
    <div className="space-y-4">
      <div
        {...getRootProps()}
        className={`relative border-2 border-dashed rounded-xl p-8 transition-all cursor-pointer ${
          isDragActive
            ? "border-brand-500 bg-brand-50 dark:bg-brand-900/20"
            : "border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50"
        } ${processing ? "opacity-50 cursor-not-allowed" : "hover:border-brand-400 hover:bg-gray-100 dark:hover:bg-gray-800"}`}
      >
        <input {...getInputProps()} disabled={processing} />
        
        <div className="flex flex-col items-center text-center">
          <div className={`mb-4 flex h-16 w-16 items-center justify-center rounded-full ${
            isDragActive ? "bg-brand-100 dark:bg-brand-500/20" : "bg-gray-200 dark:bg-gray-800"
          }`}>
            {processing ? (
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-500"></div>
            ) : (
              <FileIcon className="w-8 h-8 text-brand-500 dark:text-brand-400" />
            )}
          </div>

          <h4 className="mb-2 text-lg font-semibold text-gray-800 dark:text-white">
            {processing
              ? "Procesando documentos con IA..."
              : isDragActive
              ? "Suelta los documentos aquí"
              : "Arrastra documentos aquí o haz clic para seleccionar"}
          </h4>

          <p className="mb-4 text-sm text-gray-600 dark:text-gray-400 max-w-md">
            {processing
              ? "Extrayendo datos personales, económicos y creando ficha del cliente automáticamente..."
              : "Soporta PDF, imágenes (PNG, JPG) y documentos Word. La IA extraerá automáticamente los datos del cliente."}
          </p>

          <div className="flex items-center gap-2">
            <BoltIcon className="w-5 h-5 text-brand-500 dark:text-brand-400" />
            <Badge color="info" variant="light" size="sm">
              Extracción Automática con IA
            </Badge>
          </div>
        </div>
      </div>

      {/* Archivos subidos y resultados */}
      {uploadedFiles.length > 0 && (
        <div className="space-y-3">
          <h5 className="text-sm font-semibold text-gray-700 dark:text-gray-300">
            Documentos procesados ({uploadedFiles.length})
          </h5>
          {uploadedFiles.map((file, index) => {
            const result = extractionResults[index];
            return (
              <div
                key={index}
                className="flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200 dark:bg-gray-800 dark:border-gray-700"
              >
                <div className="flex items-center gap-3 flex-1">
                  <FileIcon className="w-5 h-5 text-gray-400" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-800 dark:text-white truncate">
                      {file.name}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {(file.size / 1024).toFixed(2)} KB
                    </p>
                  </div>
                  {result?.data ? (
                    <div className="flex flex-col gap-1 items-end">
                      <div className="flex items-center gap-2">
                        <CheckCircleIcon className="w-5 h-5 text-success-500" />
                        <Badge color="success" variant="light" size="sm">
                          {result.data.contactCreated ? "Cliente creado" : "Datos extraídos"}
                        </Badge>
                      </div>
                      {result.data.asnefCheck && result.data.asnefCheck.checked && (
                        <Badge 
                          color={result.data.asnefCheck.has_debt 
                            ? (result.data.asnefCheck.risk_level === 'very_high' || result.data.asnefCheck.risk_level === 'high' ? 'error' : 'warning')
                            : 'success'} 
                          variant="light" 
                          size="sm"
                        >
                          {result.data.asnefCheck.has_debt 
                            ? `⚠️ ASNEF: ${result.data.asnefCheck.total_debt ? `€${Number(result.data.asnefCheck.total_debt).toLocaleString()}` : 'Deuda detectada'}`
                            : '✓ ASNEF: Sin deudas'}
                        </Badge>
                      )}
                    </div>
                  ) : processing ? (
                    <div className="flex items-center gap-2">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-brand-500"></div>
                      <span className="text-xs text-gray-500">Procesando...</span>
                    </div>
                  ) : (
                    <AlertIcon className="w-5 h-5 text-warning-500" />
                  )}
                </div>
                <button
                  onClick={() => removeFile(index)}
                  className="ml-4 p-2 text-gray-400 hover:text-error-500 transition-colors"
                  title="Eliminar"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* Alerta informativa */}
      <Alert
        variant="info"
        title="Extracción Automática de Datos"
        message="Al arrastrar documentos (DNI, estados de cuenta, comprobantes, etc.), la IA extraerá automáticamente: datos personales, información económica, ingresos, consultará ASNEF para verificar deudas en mora, y creará la ficha completa del cliente en el sistema."
      />
    </div>
  );
}

