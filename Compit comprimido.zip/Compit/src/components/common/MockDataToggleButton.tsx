import { useMockData } from "../../context/MockDataContext";
import { BoltIcon } from "../../icons";

export const MockDataToggleButton: React.FC = () => {
  const { useMockData: isMockDataEnabled, toggleMockData } = useMockData();

  return (
    <button
      onClick={toggleMockData}
      className={`relative flex items-center justify-center w-10 h-10 rounded-lg transition-colors ${
        isMockDataEnabled
          ? "bg-yellow-100 text-yellow-600 dark:bg-yellow-500/20 dark:text-yellow-400"
          : "text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-800"
      }`}
      title={isMockDataEnabled ? "Desactivar datos mock" : "Activar datos mock"}
      aria-label={isMockDataEnabled ? "Desactivar datos mock" : "Activar datos mock"}
    >
      <BoltIcon className="w-5 h-5" />
      {isMockDataEnabled && (
        <span className="absolute top-1 right-1 w-2 h-2 bg-yellow-500 rounded-full border border-white dark:border-gray-900"></span>
      )}
    </button>
  );
};
