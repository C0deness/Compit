import { useState, useRef, useEffect } from "react";
import { ChatIcon, PaperPlaneIcon, BoltIcon, UserCircleIcon, CloseLineIcon } from "../../icons";
import { aiAPI } from "../../services/api";
import Badge from "../ui/badge/Badge";

export default function RockitAssistantButton() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Array<{ role: string; content: string }>>([
    {
      role: "assistant",
      content:
        "¡Hola! 👋 Soy tu Asistente Rockit, potenciado por inteligencia artificial. Puedo ayudarte con información sobre préstamos hipotecarios, tasas de interés, documentación requerida, procesos de cierre y mucho más. ¿En qué puedo asistirte hoy?",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMessage = input.trim();
    setInput("");
    setMessages((prev) => [...prev, { role: "user", content: userMessage }]);
    setLoading(true);

    try {
      const conversationHistory = messages.map((m) => ({
        role: m.role === "user" ? "user" : "assistant",
        content: m.content,
      }));

      const response = await aiAPI.mortgageChat(userMessage, conversationHistory);
      setMessages((prev) => [...prev, { role: "assistant", content: response.response }]);
    } catch (error) {
      console.error("Error en chat:", error);
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: "Lo siento, hubo un error al procesar tu mensaje. Por favor intenta de nuevo.",
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const suggestedQuestions = [
    "¿Qué documentos necesito para una hipoteca?",
    "¿Cuál es la diferencia entre tasa fija y variable?",
    "¿Cuánto tiempo tarda el proceso de aprobación?",
    "¿Qué es un pre-aprobación?",
  ];

  return (
    <>
      {/* Botón Flotante */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`fixed bottom-6 right-6 z-50 flex items-center justify-center w-14 h-14 rounded-full bg-brand-500 text-white shadow-lg hover:bg-brand-600 transition-all duration-300 hover:scale-110 hover:shadow-xl ${!isOpen ? 'rockit-assistant-button-pulse' : ''}`}
        aria-label="Abrir Asistente Rockit"
      >
        {isOpen ? (
          <CloseLineIcon className="w-6 h-6" />
        ) : (
          <ChatIcon className="w-6 h-6" />
        )}
        {!isOpen && (
          <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-success-500 text-xs font-bold text-white animate-pulse">
            <BoltIcon className="w-3 h-3" />
          </span>
        )}
      </button>

      {/* Modal del Chat */}
      {isOpen && (
        <div className="rockit-assistant-modal fixed bottom-24 right-6 z-50 w-96 h-[600px] flex flex-col bg-white rounded-2xl shadow-2xl border border-gray-200 dark:bg-gray-800 dark:border-gray-700 overflow-hidden">
          {/* Header del Modal */}
          <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-brand-500 to-brand-600">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm">
                <BoltIcon className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-white text-sm">Asistente Rockit</h3>
                <p className="text-xs text-white/80">Potenciado por IA</p>
              </div>
            </div>
            <Badge color="success" variant="light" size="xs">
              En línea
            </Badge>
          </div>

          {/* Área de Mensajes */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50/50 dark:bg-gray-900/30">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div className={`flex gap-2 max-w-[85%] ${message.role === "user" ? "flex-row-reverse" : "flex-row"}`}>
                  {/* Avatar */}
                  <div className="flex-shrink-0">
                    {message.role === "user" ? (
                      <div className="flex items-center justify-center w-7 h-7 rounded-full bg-brand-500">
                        <UserCircleIcon className="w-4 h-4 text-white" />
                      </div>
                    ) : (
                      <div className="flex items-center justify-center w-7 h-7 rounded-full bg-brand-100 dark:bg-brand-500/20">
                        <BoltIcon className="w-4 h-4 text-brand-500 dark:text-brand-400" />
                      </div>
                    )}
                  </div>

                  {/* Burbuja de Mensaje */}
                  <div
                    className={`rounded-lg p-3 ${
                      message.role === "user"
                        ? "bg-brand-500 text-white rounded-tr-none"
                        : "bg-white text-gray-800 dark:bg-gray-700 dark:text-white rounded-tl-none border border-gray-200 dark:border-gray-600"
                    }`}
                  >
                    <p className="text-xs whitespace-pre-wrap leading-relaxed">{message.content}</p>
                  </div>
                </div>
              </div>
            ))}

            {/* Indicador de carga */}
            {loading && (
              <div className="flex justify-start">
                <div className="flex gap-2">
                  <div className="flex items-center justify-center w-7 h-7 rounded-full bg-brand-100 dark:bg-brand-500/20">
                    <BoltIcon className="w-4 h-4 text-brand-500 dark:text-brand-400" />
                  </div>
                  <div className="bg-white rounded-lg p-3 border border-gray-200 dark:bg-gray-700 dark:border-gray-600">
                    <div className="flex space-x-1">
                      <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce"></div>
                      <div
                        className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce"
                        style={{ animationDelay: "0.2s" }}
                      ></div>
                      <div
                        className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce"
                        style={{ animationDelay: "0.4s" }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Preguntas sugeridas (solo en el primer mensaje) */}
            {messages.length === 1 && !loading && (
              <div className="mt-2">
                <p className="text-xs font-medium text-gray-500 dark:text-gray-400 mb-2">
                  Preguntas sugeridas:
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {suggestedQuestions.map((question, index) => (
                    <button
                      key={index}
                      onClick={() => setInput(question)}
                      className="px-2.5 py-1 text-xs font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700 dark:hover:bg-gray-700 transition-colors"
                    >
                      {question}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <form onSubmit={handleSend} className="p-4 border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Escribe tu pregunta..."
                className="flex-1 h-9 rounded-lg border border-gray-300 bg-transparent px-3 py-2 text-xs shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-2 focus:border-brand-300 focus:ring-brand-500/20 dark:bg-gray-900 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800"
                disabled={loading}
              />
              <button
                type="submit"
                disabled={loading || !input.trim()}
                className="flex items-center justify-center w-9 h-9 rounded-lg bg-brand-500 text-white hover:bg-brand-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <PaperPlaneIcon className="w-4 h-4" />
              </button>
            </div>
            <p className="mt-1.5 text-xs text-gray-500 dark:text-gray-400 text-center">
              Respuestas generadas por IA
            </p>
          </form>
        </div>
      )}
    </>
  );
}
