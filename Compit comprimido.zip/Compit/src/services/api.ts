import { generateMockNews, generateMockAlerts, generateMockRecommendations, generateMockKPIs, generateMockKPISummary, generateMockCompetitors, generateMockNotifications } from '../utils/mockData';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// Función para obtener el estado de mock data desde localStorage
const getUseMockData = (): boolean => {
  if (typeof window === 'undefined') return false;
  return localStorage.getItem('useMockData') === 'true';
};


// Helper para hacer requests autenticados
const authFetch = async (endpoint: string, options: RequestInit = {}) => {
  const token = localStorage.getItem('token');
  
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...options.headers,
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers,
  });

  if (response.status === 401) {
    localStorage.removeItem('token');
    window.location.href = '/signin';
    throw new Error('No autorizado');
  }

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: 'Error desconocido' }));
    throw new Error(error.error || 'Error en la petición');
  }

  return response.json();
};

// Auth API
export const authAPI = {
  register: async (data: {
    email: string;
    password: string;
    firstName?: string;
    lastName?: string;
    phone?: string;
  }) => {
    return authFetch('/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  login: async (email: string, password: string) => {
    return authFetch('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
  },

  getMe: async () => {
    return authFetch('/auth/me');
  },
};

// Contacts API
export const contactsAPI = {
  getAll: async (filters?: { status?: string; search?: string }) => {
    const params = new URLSearchParams();
    if (filters?.status) params.append('status', filters.status);
    if (filters?.search) params.append('search', filters.search);
    const query = params.toString();
    return authFetch(`/contacts${query ? `?${query}` : ''}`);
  },

  getById: async (id: number) => {
    return authFetch(`/contacts/${id}`);
  },

  create: async (data: any) => {
    return authFetch('/contacts', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  update: async (id: string | number, data: any) => {
    return authFetch(`/contacts/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  delete: async (id: string | number) => {
    return authFetch(`/contacts/${id}`, {
      method: 'DELETE',
    });
  },

  addActivity: async (id: number, data: any) => {
    return authFetch(`/contacts/${id}/activities`, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },
};

// Properties API
export const propertiesAPI = {
  getAll: async (filters?: {
    status?: string;
    type?: string;
    search?: string;
    minPrice?: number;
    maxPrice?: number;
  }) => {
    const params = new URLSearchParams();
    if (filters?.status) params.append('status', filters.status);
    if (filters?.type) params.append('type', filters.type);
    if (filters?.search) params.append('search', filters.search);
    if (filters?.minPrice) params.append('minPrice', filters.minPrice.toString());
    if (filters?.maxPrice) params.append('maxPrice', filters.maxPrice.toString());
    const query = params.toString();
    return authFetch(`/properties${query ? `?${query}` : ''}`);
  },

  getById: async (id: number) => {
    return authFetch(`/properties/${id}`);
  },

  create: async (data: any) => {
    return authFetch('/properties', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  update: async (id: number, data: any) => {
    return authFetch(`/properties/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  delete: async (id: number) => {
    return authFetch(`/properties/${id}`, {
      method: 'DELETE',
    });
  },
};

// Deals API
export const dealsAPI = {
  getAll: async (filters?: { status?: string }) => {
    const params = new URLSearchParams();
    if (filters?.status) params.append('status', filters.status);
    const query = params.toString();
    return authFetch(`/deals${query ? `?${query}` : ''}`);
  },

  getById: async (id: number) => {
    return authFetch(`/deals/${id}`);
  },

  create: async (data: any) => {
    return authFetch('/deals', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  update: async (id: number, data: any) => {
    return authFetch(`/deals/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  uploadDocument: async (dealId: number, file: File, name: string, type: string) => {
    const formData = new FormData();
    formData.append('document', file);
    formData.append('name', name);
    formData.append('type', type);

    const token = localStorage.getItem('token');
    const response = await fetch(`${API_BASE_URL}/deals/${dealId}/documents`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: formData,
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Error desconocido' }));
      throw new Error(error.error || 'Error al subir documento');
    }

    return response.json();
  },

  updateDocument: async (dealId: number, docId: number, data: any) => {
    return authFetch(`/deals/${dealId}/documents/${docId}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },
};

// Farming API
export const farmingAPI = {
  getZones: async () => {
    return authFetch('/farming/zones');
  },

  analyzeZone: async (latitude: number, longitude: number, radius?: number) => {
    return authFetch('/farming/analyze', {
      method: 'POST',
      body: JSON.stringify({ latitude, longitude, radius }),
    });
  },

  generateKit: async (zoneName: string, analysisData: any) => {
    return authFetch('/farming/generate-kit', {
      method: 'POST',
      body: JSON.stringify({ zoneName, analysisData }),
    });
  },

  saveZone: async (data: any) => {
    return authFetch('/farming/zones', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },
};

// Financing API
export const financingAPI = {
  getAll: async (filters?: { status?: string; loan_type?: string }) => {
    const params = new URLSearchParams();
    if (filters?.status) params.append('status', filters.status);
    if (filters?.loan_type) params.append('loan_type', filters.loan_type);
    const query = params.toString();
    return authFetch(`/financing${query ? `?${query}` : ''}`);
  },

  getById: async (id: string | number) => {
    return authFetch(`/financing/${id}`);
  },

  create: async (data: any) => {
    return authFetch('/financing', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  update: async (id: string | number, data: any) => {
    return authFetch(`/financing/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  delete: async (id: string | number) => {
    return authFetch(`/financing/${id}`, {
      method: 'DELETE',
    });
  },

  calculate: async (data: { loan_amount: number; interest_rate: number; loan_term: number; down_payment?: number }) => {
    return authFetch('/financing/calculate', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },
};

// Automation API
export const automationAPI = {
  getWorkflows: async () => {
    return authFetch('/automation/workflows');
  },

  createWorkflow: async (data: any) => {
    return authFetch('/automation/workflows', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  updateWorkflow: async (id: number, data: any) => {
    return authFetch(`/automation/workflows/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  deleteWorkflow: async (id: number) => {
    return authFetch(`/automation/workflows/${id}`, {
      method: 'DELETE',
    });
  },
};

// AI API
export const aiAPI = {
  mortgageChat: async (message: string, conversationHistory: any[] = []) => {
    return authFetch('/ai/chat/mortgage', {
      method: 'POST',
      body: JSON.stringify({ message, conversationHistory }),
    });
  },

  generateSocialContent: async (propertyId: number) => {
    return authFetch('/ai/generate-social-content', {
      method: 'POST',
      body: JSON.stringify({ propertyId }),
    });
  },
};

// Notifications API
export const notificationsAPI = {
  getAll: async (filters?: { read?: boolean; type?: string; limit?: number }) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 300));
      let mockNotifications = generateMockNotifications();
      
      if (filters?.read !== undefined) {
        mockNotifications = mockNotifications.filter(n => n.read === filters.read);
      }
      if (filters?.type) {
        mockNotifications = mockNotifications.filter(n => n.type === filters.type);
      }
      
      const limit = filters?.limit || 50;
      const notifications = mockNotifications.slice(0, limit);
      
      return notifications;
    }
    
    const params = new URLSearchParams();
    if (filters?.read !== undefined) params.append('read', filters.read.toString());
    if (filters?.type) params.append('type', filters.type);
    if (filters?.limit) params.append('limit', filters.limit.toString());
    const query = params.toString();
    return authFetch(`/notifications${query ? `?${query}` : ''}`);
  },

  getUnreadCount: async () => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 200));
      const mockNotifications = generateMockNotifications();
      const unreadCount = mockNotifications.filter(n => !n.read).length;
      return { count: unreadCount };
    }
    return authFetch('/notifications/unread-count');
  },

  markAsRead: async (id: string | number) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 200));
      return { success: true };
    }
    return authFetch(`/notifications/${id}/read`, {
      method: 'PUT',
    });
  },

  markAllAsRead: async () => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 200));
      return { success: true };
    }
    return authFetch('/notifications/read-all', {
      method: 'PUT',
    });
  },

  delete: async (id: string | number) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 200));
      return { message: 'Notificación eliminada correctamente' };
    }
    return authFetch(`/notifications/${id}`, {
      method: 'DELETE',
    });
  },
};

// Reports API
export const reportsAPI = {
  getContactsReport: async (filters?: any) => {
    const params = new URLSearchParams();
    if (filters?.status) params.append('status', filters.status);
    if (filters?.startDate) params.append('startDate', filters.startDate);
    if (filters?.endDate) params.append('endDate', filters.endDate);
    const query = params.toString();
    return authFetch(`/reports/contacts${query ? `?${query}` : ''}`);
  },

  getDealsReport: async (filters?: any) => {
    const params = new URLSearchParams();
    if (filters?.status) params.append('status', filters.status);
    if (filters?.startDate) params.append('startDate', filters.startDate);
    if (filters?.endDate) params.append('endDate', filters.endDate);
    const query = params.toString();
    return authFetch(`/reports/deals${query ? `?${query}` : ''}`);
  },

  getPropertiesReport: async (filters?: any) => {
    const params = new URLSearchParams();
    if (filters?.status) params.append('status', filters.status);
    if (filters?.type) params.append('type', filters.type);
    if (filters?.startDate) params.append('startDate', filters.startDate);
    if (filters?.endDate) params.append('endDate', filters.endDate);
    const query = params.toString();
    return authFetch(`/reports/properties${query ? `?${query}` : ''}`);
  },

  getFinancingReport: async (filters?: any) => {
    const params = new URLSearchParams();
    if (filters?.status) params.append('status', filters.status);
    if (filters?.loan_type) params.append('loan_type', filters.loan_type);
    if (filters?.startDate) params.append('startDate', filters.startDate);
    if (filters?.endDate) params.append('endDate', filters.endDate);
    const query = params.toString();
    return authFetch(`/reports/financing${query ? `?${query}` : ''}`);
  },

  getDashboardReport: async (filters?: any) => {
    const params = new URLSearchParams();
    if (filters?.startDate) params.append('startDate', filters.startDate);
    if (filters?.endDate) params.append('endDate', filters.endDate);
    const query = params.toString();
    return authFetch(`/reports/dashboard${query ? `?${query}` : ''}`);
  },

  generateMonthlyPDF: async (month?: number, year?: number) => {
    const token = localStorage.getItem('token');
    const params = new URLSearchParams();
    if (month) params.append('month', month.toString());
    if (year) params.append('year', year.toString());
    const query = params.toString();
    
    const response = await fetch(`${API_BASE_URL}/reports/monthly/pdf${query ? `?${query}` : ''}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      throw new Error('Error al generar PDF');
    }

    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `reporte-mensual-${month || new Date().getMonth() + 1}-${year || new Date().getFullYear()}.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  },

  generateConsolidatedPDF: async (startDate?: string, endDate?: string) => {
    const token = localStorage.getItem('token');
    const params = new URLSearchParams();
    if (startDate) params.append('startDate', startDate);
    if (endDate) params.append('endDate', endDate);
    const query = params.toString();
    
    const response = await fetch(`${API_BASE_URL}/reports/consolidated/pdf${query ? `?${query}` : ''}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      throw new Error('Error al generar PDF');
    }

    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const filename = startDate && endDate
      ? `reporte-consolidado-${startDate}-${endDate}.pdf`
      : `reporte-consolidado-${new Date().toISOString().split('T')[0]}.pdf`;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  },
};

// News API
export const newsAPI = {
  getAll: async (filters?: {
    category?: string;
    brand?: string;
    model?: string;
    is_read?: boolean;
    limit?: number;
    page?: number;
  }) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 300));
      let mockNews = generateMockNews();
      
      if (filters?.category) {
        mockNews = mockNews.filter(n => n.category === filters.category);
      }
      if (filters?.brand) {
        mockNews = mockNews.filter(n => n.brand?.toLowerCase().includes(filters.brand!.toLowerCase()));
      }
      if (filters?.model) {
        mockNews = mockNews.filter(n => n.model?.toLowerCase().includes(filters.model!.toLowerCase()));
      }
      if (filters?.is_read !== undefined) {
        mockNews = mockNews.filter(n => n.is_read === filters.is_read);
      }
      
      const limit = filters?.limit || 50;
      const page = filters?.page || 1;
      const start = (page - 1) * limit;
      const end = start + limit;
      
      return {
        news: mockNews.slice(start, end),
        pagination: {
          total: mockNews.length,
          page,
          limit,
          pages: Math.ceil(mockNews.length / limit),
        },
      };
    }
    
    const params = new URLSearchParams();
    if (filters?.category) params.append('category', filters.category);
    if (filters?.brand) params.append('brand', filters.brand);
    if (filters?.model) params.append('model', filters.model);
    if (filters?.is_read !== undefined) params.append('is_read', filters.is_read.toString());
    if (filters?.limit) params.append('limit', filters.limit.toString());
    if (filters?.page) params.append('page', filters.page.toString());
    const query = params.toString();
    return authFetch(`/news${query ? `?${query}` : ''}`);
  },

  getById: async (id: string) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 200));
      const mockNews = generateMockNews();
      return mockNews.find(n => n._id === id) || mockNews[0];
    }
    return authFetch(`/news/${id}`);
  },

  markAsRead: async (id: string) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 200));
      return { success: true };
    }
    return authFetch(`/news/${id}/read`, {
      method: 'PATCH',
    });
  },

  delete: async (id: string) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 200));
      return { message: 'Noticia eliminada correctamente' };
    }
    return authFetch(`/news/${id}`, {
      method: 'DELETE',
    });
  },
};

// Alerts API
export const alertsAPI = {
  getAll: async (filters?: {
    type?: string;
    severity?: string;
    is_read?: boolean;
    limit?: number;
    page?: number;
  }) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 300));
      let mockAlerts = generateMockAlerts();
      
      if (filters?.type) {
        mockAlerts = mockAlerts.filter(a => a.type === filters.type);
      }
      if (filters?.severity) {
        mockAlerts = mockAlerts.filter(a => a.severity === filters.severity);
      }
      if (filters?.is_read !== undefined) {
        mockAlerts = mockAlerts.filter(a => a.is_read === filters.is_read);
      }
      
      const limit = filters?.limit || 50;
      const page = filters?.page || 1;
      const start = (page - 1) * limit;
      const end = start + limit;
      const unreadCount = mockAlerts.filter(a => !a.is_read).length;
      
      return {
        alerts: mockAlerts.slice(start, end),
        pagination: {
          total: mockAlerts.length,
          page,
          limit,
          pages: Math.ceil(mockAlerts.length / limit),
        },
        unread_count: unreadCount,
      };
    }
    
    const params = new URLSearchParams();
    if (filters?.type) params.append('type', filters.type);
    if (filters?.severity) params.append('severity', filters.severity);
    if (filters?.is_read !== undefined) params.append('is_read', filters.is_read.toString());
    if (filters?.limit) params.append('limit', filters.limit.toString());
    if (filters?.page) params.append('page', filters.page.toString());
    const query = params.toString();
    return authFetch(`/alerts${query ? `?${query}` : ''}`);
  },

  getById: async (id: string) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 200));
      const mockAlerts = generateMockAlerts();
      return mockAlerts.find(a => a._id === id) || mockAlerts[0];
    }
    return authFetch(`/alerts/${id}`);
  },

  markAsRead: async (id: string) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 200));
      return { success: true };
    }
    return authFetch(`/alerts/${id}/read`, {
      method: 'PATCH',
    });
  },

  markActionTaken: async (id: string, results?: string) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 200));
      return { success: true, action_taken: true };
    }
    return authFetch(`/alerts/${id}/action`, {
      method: 'PATCH',
      body: JSON.stringify({ results }),
    });
  },

  delete: async (id: string) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 200));
      return { message: 'Alerta eliminada correctamente' };
    }
    return authFetch(`/alerts/${id}`, {
      method: 'DELETE',
    });
  },
};

// Recommendations API
export const recommendationsAPI = {
  getAll: async (filters?: {
    type?: string;
    status?: string;
    limit?: number;
    page?: number;
  }) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 300));
      let mockRecs = generateMockRecommendations();
      
      if (filters?.type) {
        mockRecs = mockRecs.filter(r => r.type === filters.type);
      }
      if (filters?.status) {
        mockRecs = mockRecs.filter(r => r.status === filters.status);
      }
      
      const limit = filters?.limit || 50;
      const page = filters?.page || 1;
      const start = (page - 1) * limit;
      const end = start + limit;
      
      return {
        recommendations: mockRecs.slice(start, end),
        pagination: {
          total: mockRecs.length,
          page,
          limit,
          pages: Math.ceil(mockRecs.length / limit),
        },
      };
    }
    
    const params = new URLSearchParams();
    if (filters?.type) params.append('type', filters.type);
    if (filters?.status) params.append('status', filters.status);
    if (filters?.limit) params.append('limit', filters.limit.toString());
    if (filters?.page) params.append('page', filters.page.toString());
    const query = params.toString();
    return authFetch(`/recommendations${query ? `?${query}` : ''}`);
  },

  getById: async (id: string) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 200));
      const mockRecs = generateMockRecommendations();
      return mockRecs.find(r => r._id === id) || mockRecs[0];
    }
    return authFetch(`/recommendations/${id}`);
  },

  updateStatus: async (id: string, status: string, results?: string) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 200));
      return { success: true, status };
    }
    return authFetch(`/recommendations/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status, results }),
    });
  },

  delete: async (id: string) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 200));
      return { message: 'Recomendación eliminada correctamente' };
    }
    return authFetch(`/recommendations/${id}`, {
      method: 'DELETE',
    });
  },
};

// KPIs API
export const kpisAPI = {
  getAll: async (filters?: {
    category?: string;
    period?: string;
    limit?: number;
    page?: number;
  }) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 300));
      let mockKPIs = generateMockKPIs();
      
      if (filters?.category) {
        mockKPIs = mockKPIs.filter(k => k.category === filters.category);
      }
      
      const limit = filters?.limit || 100;
      const page = filters?.page || 1;
      const start = (page - 1) * limit;
      const end = start + limit;
      
      return {
        kpis: mockKPIs.slice(start, end),
        pagination: {
          total: mockKPIs.length,
          page,
          limit,
          pages: Math.ceil(mockKPIs.length / limit),
        },
      };
    }
    
    const params = new URLSearchParams();
    if (filters?.category) params.append('category', filters.category);
    if (filters?.period) params.append('period', filters.period);
    if (filters?.limit) params.append('limit', filters.limit.toString());
    if (filters?.page) params.append('page', filters.page.toString());
    const query = params.toString();
    return authFetch(`/kpis${query ? `?${query}` : ''}`);
  },

  getSummary: async (period?: string) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 300));
      return {
        summary: generateMockKPISummary(),
      };
    }
    const params = new URLSearchParams();
    if (period) params.append('period', period);
    const query = params.toString();
    return authFetch(`/kpis/summary${query ? `?${query}` : ''}`);
  },

  getById: async (id: string) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 200));
      const mockKPIs = generateMockKPIs();
      return mockKPIs.find(k => k._id === id) || mockKPIs[0];
    }
    return authFetch(`/kpis/${id}`);
  },

  delete: async (id: string) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 200));
      return { message: 'KPI eliminado correctamente' };
    }
    return authFetch(`/kpis/${id}`, {
      method: 'DELETE',
    });
  },
};

// Competitors API
export const competitorsAPI = {
  getAll: async (filters?: {
    is_active?: boolean;
    type?: string;
  }) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 300));
      let mockCompetitors = generateMockCompetitors();
      
      if (filters?.is_active !== undefined) {
        mockCompetitors = mockCompetitors.filter(c => c.is_active === filters.is_active);
      }
      if (filters?.type) {
        mockCompetitors = mockCompetitors.filter(c => c.type === filters.type);
      }
      
      return {
        competitors: mockCompetitors,
      };
    }
    
    const params = new URLSearchParams();
    if (filters?.is_active !== undefined) params.append('is_active', filters.is_active.toString());
    if (filters?.type) params.append('type', filters.type);
    const query = params.toString();
    return authFetch(`/competitors${query ? `?${query}` : ''}`);
  },

  getById: async (id: string) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 200));
      const mockCompetitors = generateMockCompetitors();
      return mockCompetitors.find(c => c._id === id) || mockCompetitors[0];
    }
    return authFetch(`/competitors/${id}`);
  },

  create: async (data: any) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 300));
      return {
        _id: `mock-competitor-${Date.now()}`,
        ...data,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
    }
    return authFetch('/competitors', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  update: async (id: string, data: any) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 300));
      return {
        _id: id,
        ...data,
        updated_at: new Date().toISOString(),
      };
    }
    return authFetch(`/competitors/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  delete: async (id: string) => {
    if (getUseMockData()) {
      await new Promise(resolve => setTimeout(resolve, 200));
      return { message: 'Competidor eliminado correctamente' };
    }
    return authFetch(`/competitors/${id}`, {
      method: 'DELETE',
    });
  },
};
