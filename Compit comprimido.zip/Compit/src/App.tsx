import { BrowserRouter as Router, Routes, Route } from "react-router";
import SignIn from "./pages/AuthPages/SignIn";
import SignUp from "./pages/AuthPages/SignUp";
import NotFound from "./pages/OtherPage/NotFound";
import Landing from "./pages/Landing";
import UserProfiles from "./pages/UserProfiles";
import AppLayout from "./layout/AppLayout";
import { ScrollToTop } from "./components/common/ScrollToTop";
import Home from "./pages/Dashboard/Home";
import Contacts from "./pages/CRM/Contacts";
import Properties from "./pages/CRM/Properties";
import Deals from "./pages/CRM/Deals";
import Farming from "./pages/CRM/Farming";
import Automation from "./pages/CRM/Automation";
import MortgageChat from "./pages/CRM/MortgageChat";
import Financing from "./pages/CRM/Financing";
import Reports from "./pages/CRM/Reports";
import News from "./pages/CRM/News";
import Alerts from "./pages/CRM/Alerts";
import Recommendations from "./pages/CRM/Recommendations";
import KPIs from "./pages/CRM/KPIs";
import Competitors from "./pages/CRM/Competitors";
import Pricing from "./pages/Pricing";

export default function App() {
  return (
    <>
      <Router>
        <ScrollToTop />
        <Routes>
          {/* Dashboard Layout */}
          <Route element={<AppLayout />}>
            <Route index path="/" element={<Home />} />

            {/* AutoMarket Intelligence Pages */}
            <Route path="/news" element={<News />} />
            <Route path="/alerts" element={<Alerts />} />
            <Route path="/recommendations" element={<Recommendations />} />
            <Route path="/kpis" element={<KPIs />} />
            <Route path="/competitors" element={<Competitors />} />
            <Route path="/reports" element={<Reports />} />
            
            {/* Legacy CRM Pages (mantener por compatibilidad) */}
            <Route path="/contacts" element={<Contacts />} />
            <Route path="/properties" element={<Properties />} />
            <Route path="/deals" element={<Deals />} />
            <Route path="/farming" element={<Farming />} />
            <Route path="/automation" element={<Automation />} />
            <Route path="/mortgage-chat" element={<MortgageChat />} />
            <Route path="/financing" element={<Financing />} />

            {/* Others Page */}
            <Route path="/profile" element={<UserProfiles />} />
            <Route path="/pricing" element={<Pricing />} />
          </Route>

          {/* Public Pages */}
          <Route path="/landing" element={<Landing />} />
          
          {/* Auth Layout */}
          <Route path="/signin" element={<SignIn />} />
          <Route path="/signup" element={<SignUp />} />

          {/* Fallback Route */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Router>
    </>
  );
}
