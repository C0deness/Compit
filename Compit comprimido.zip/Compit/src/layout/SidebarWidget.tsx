import { useNavigate } from "react-router";
import Button from "../components/ui/button/Button";
import { ArrowRightIcon, BoltIcon } from "../icons";

export default function SidebarWidget() {
  const navigate = useNavigate();

  const handleUpgrade = () => {
    navigate("/pricing");
  };

  return (
    <div
      className={`
        mx-auto mb-10 w-full max-w-60 rounded-2xl bg-gradient-to-br from-brand-50 to-brand-100 px-4 py-6 text-center dark:from-brand-900/20 dark:to-brand-800/20 border border-brand-200 dark:border-brand-700`}
    >
      <div className="mb-3 flex items-center justify-center">
        <div className="flex items-center justify-center w-12 h-12 rounded-full bg-brand-500 text-white">
          <BoltIcon className="w-6 h-6" />
        </div>
      </div>
      
      <h3 className="mb-2 text-lg font-bold text-gray-900 dark:text-white">
        Desbloquea Todo el Poder
      </h3>
      
      <p className="mb-4 text-sm text-gray-600 dark:text-gray-300 leading-relaxed">
        Accede a funciones avanzadas de IA, análisis predictivo y automatizaciones ilimitadas. 
        <span className="block mt-1 font-semibold text-brand-600 dark:text-brand-400">
          Potencia tus ventas hoy mismo.
        </span>
      </p>
      
      <Button
        onClick={handleUpgrade}
        size="sm"
        variant="primary"
        className="w-full font-semibold shadow-lg hover:shadow-xl transition-all"
        endIcon={<ArrowRightIcon className="w-4 h-4" />}
      >
        Mejorar Plan
      </Button>
      
      <p className="mt-3 text-xs text-gray-500 dark:text-gray-400">
        ✨ Sin compromiso • Cancela cuando quieras
      </p>
    </div>
  );
}
