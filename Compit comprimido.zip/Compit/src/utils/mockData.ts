// Datos mock para todas las secciones de AutoMarket Intelligence

export const generateMockNews = () => {
  const categories = ['precio', 'stock', 'financiacion', 'competencia', 'general'];
  const brands = ['Toyota', 'Volkswagen', 'Ford', 'BMW', 'Mercedes-Benz', 'Audi', 'Seat', 'Renault'];
  const models = ['Corolla', 'Golf', 'Focus', 'Serie 3', 'Clase A', 'A3', 'Ibiza', 'Clio'];
  const sources = ['Coches.net', 'Autocasion', 'Motor.es', 'El Mundo Motor', 'TopGear España'];
  
  return Array.from({ length: 20 }, (_, i) => {
    const category = categories[Math.floor(Math.random() * categories.length)];
    const brand = brands[Math.floor(Math.random() * brands.length)];
    const model = models[Math.floor(Math.random() * models.length)];
    const price = Math.floor(Math.random() * 50000) + 10000;
    const daysAgo = Math.floor(Math.random() * 30);
    
    const contentDetails = {
      precio: `El ${brand} ${model} ha experimentado cambios significativos en su precio de mercado. El precio actualizado es de €${price.toLocaleString()}, lo que representa una variación importante en comparación con el mes anterior. Este cambio puede afectar la estrategia de precios de vehículos usados similares en tu inventario. Se recomienda revisar la competitividad de tus precios y considerar ajustes si es necesario para mantener tu posición en el mercado.`,
      stock: `Nuevas unidades del ${brand} ${model} están disponibles en concesionarios de la zona. Este aumento en el stock puede indicar una mayor disponibilidad en el mercado, lo que podría afectar la demanda y los precios. Es importante monitorear cómo esto impacta en la rotación de inventario y considerar estrategias de marketing para destacar tu oferta.`,
      financiacion: `Nuevas condiciones de financiación están disponibles para el ${brand} ${model}. Los concesionarios están ofreciendo planes de financiación más atractivos, incluyendo tasas de interés reducidas y períodos de pago extendidos. Esta es una oportunidad para revisar tus propias ofertas de financiación y asegurarte de mantener la competitividad en este aspecto crucial para los clientes.`,
      competencia: `Se han detectado movimientos importantes de la competencia relacionados con ${brand} ${model}. Los competidores están implementando nuevas estrategias de marketing y precios que podrían afectar tu posición en el mercado. Es recomendable analizar estas acciones y considerar respuestas estratégicas para mantener tu ventaja competitiva.`,
      general: `Actualización importante del mercado relacionada con ${brand} ${model}. Esta noticia contiene información relevante que puede impactar en tu estrategia comercial. Se recomienda revisar los detalles completos y considerar cómo esta información puede ser utilizada para mejorar tu negocio.`
    };
    
    return {
      _id: `mock-news-${i}`,
      title: `${brand} ${model}: ${category === 'precio' ? 'Nuevo precio' : category === 'stock' ? 'Stock disponible' : category === 'financiacion' ? 'Ofertas de financiación' : 'Noticia relevante'}`,
      content: contentDetails[category as keyof typeof contentDetails] || contentDetails.general,
      summary: `Resumen automático generado por IA: ${brand} ${model} ha mostrado cambios relevantes en el área de ${category}. Esta información ha sido procesada y analizada para proporcionarte insights accionables sobre el mercado automotriz.`,
      source: sources[Math.floor(Math.random() * sources.length)],
      source_url: `https://example.com/news/${i}`,
      category,
      keywords: [brand, model, category, 'automóvil', 'concesionario', 'mercado', 'análisis'],
      brand,
      model,
      price: category === 'precio' ? price : null,
      relevance_score: Math.floor(Math.random() * 50) + 50,
      published_at: new Date(Date.now() - daysAgo * 24 * 60 * 60 * 1000).toISOString(),
      processed_at: new Date().toISOString(),
      is_read: Math.random() > 0.7,
    };
  });
};

export const generateMockAlerts = () => {
  const types = ['precio', 'stock', 'financiacion', 'competencia', 'kpi', 'recomendacion'];
  const severities = ['low', 'medium', 'high', 'critical'];
  const brands = ['Toyota', 'Volkswagen', 'Ford', 'BMW'];
  const models = ['Corolla', 'Golf', 'Focus', 'Serie 3'];
  
  return Array.from({ length: 15 }, (_, i) => {
    const type = types[Math.floor(Math.random() * types.length)];
    const severity = severities[Math.floor(Math.random() * severities.length)];
    const brand = brands[Math.floor(Math.random() * brands.length)];
    const model = models[Math.floor(Math.random() * models.length)];
    const daysAgo = Math.floor(Math.random() * 7);
    
    const actionTaken = Math.random() > 0.8;
    const createdAt = new Date(Date.now() - daysAgo * 24 * 60 * 60 * 1000);
    
    return {
      _id: `mock-alert-${i}`,
      type,
      severity,
      title: `Alerta de ${type}: ${brand} ${model}`,
      message: `Se ha detectado un cambio importante relacionado con ${type} para ${brand} ${model}. Se recomienda revisar la información detallada y considerar acciones inmediatas si es necesario. Esta alerta ha sido generada automáticamente por nuestro sistema de vigilancia competitiva.`,
      description: `Descripción detallada: El mercado ha mostrado cambios significativos en el área de ${type}. Para ${brand} ${model}, se han observado variaciones que requieren atención. Se recomienda analizar las tendencias y considerar ajustes en la estrategia comercial.`,
      brand,
      model,
      is_read: Math.random() > 0.6,
      action_taken: actionTaken,
      action_results: actionTaken ? 'Se ha tomado acción sobre esta alerta. Se ha contactado con el equipo comercial y se ha iniciado un análisis detallado de la situación.' : null,
      related_entity: {
        type: Math.random() > 0.5 ? 'News' : 'Competitor',
        id: `mock-entity-${i}`,
      },
      created_at: createdAt.toISOString(),
      updated_at: new Date(createdAt.getTime() + Math.floor(Math.random() * 2) * 24 * 60 * 60 * 1000).toISOString(),
    };
  });
};

export const generateMockRecommendations = () => {
  const types = ['rotacion_stock', 'pricing_vo', 'estrategia_financiacion', 'competencia', 'marketing'];
  const statuses = ['pending', 'in_progress', 'completed', 'dismissed'];
  const impacts = ['low', 'medium', 'high'];
  const brands = ['Toyota', 'Volkswagen', 'Ford', 'BMW', 'Mercedes-Benz', 'Audi'];
  const models = ['Corolla', 'Golf', 'Focus', 'Serie 3', 'Clase A', 'A3'];
  
  return Array.from({ length: 10 }, (_, i) => {
    const type = types[Math.floor(Math.random() * types.length)];
    const status = statuses[Math.floor(Math.random() * statuses.length)];
    const impact = impacts[Math.floor(Math.random() * impacts.length)];
    
    const titles: Record<string, string> = {
      rotacion_stock: 'Optimizar rotación de stock',
      pricing_vo: 'Ajustar precios de vehículos usados',
      estrategia_financiacion: 'Mejorar ofertas de financiación',
      competencia: 'Responder a movimientos de competencia',
      marketing: 'Campaña de marketing sugerida',
    };
    
    const descriptions: Record<string, string> = {
      rotacion_stock: 'Se recomienda revisar el stock de vehículos con más de 90 días en inventario y considerar promociones especiales.',
      pricing_vo: 'Los precios de vehículos usados similares en el mercado han bajado un 5%. Considera ajustar tus precios.',
      estrategia_financiacion: 'La competencia está ofreciendo mejores condiciones de financiación. Revisa tus ofertas actuales.',
      competencia: 'Un competidor ha lanzado una nueva promoción. Considera una respuesta estratégica.',
      marketing: 'Momento óptimo para lanzar una campaña de marketing basada en las tendencias actuales del mercado.',
    };
    
    const createdAt = new Date(Date.now() - Math.floor(Math.random() * 14) * 24 * 60 * 60 * 1000);
    const hasResults = status === 'completed' && Math.random() > 0.5;
    
    return {
      _id: `mock-rec-${i}`,
      type,
      title: titles[type],
      description: descriptions[type] + ' Esta recomendación ha sido generada mediante análisis de datos y algoritmos de inteligencia artificial para optimizar tu estrategia comercial.',
      action_items: [
        { title: 'Revisar inventario actual', description: 'Analizar vehículos con mayor tiempo en stock y evaluar estrategias de rotación', priority: 'high' },
        { title: 'Definir estrategia de precios', description: 'Comparar con competencia y ajustar según análisis de mercado', priority: 'medium' },
        { title: 'Implementar campaña de marketing', description: 'Desarrollar campaña específica basada en los datos analizados', priority: type === 'marketing' ? 'high' : 'low' },
      ],
      expected_impact: impact,
      confidence_score: Math.floor(Math.random() * 30) + 70,
      status,
      action_details: {
        target_vehicles: type === 'rotacion_stock' ? [`${brands[Math.floor(Math.random() * brands.length)]} ${models[Math.floor(Math.random() * models.length)]}`, `${brands[Math.floor(Math.random() * brands.length)]} ${models[Math.floor(Math.random() * models.length)]}`] : undefined,
        suggested_price: type === 'pricing_vo' ? Math.floor(Math.random() * 30000) + 15000 : undefined,
        financing_offer: type === 'estrategia_financiacion' ? 'Financiación al 0% durante 12 meses o 2.9% a 60 meses' : undefined,
        marketing_channel: type === 'marketing' ? ['Facebook Ads', 'Google Ads', 'Email Marketing'][Math.floor(Math.random() * 3)] : undefined,
      },
      results: hasResults ? 'La recomendación ha sido implementada exitosamente. Se ha observado un aumento del 15% en las consultas y un 8% en las conversiones.' : null,
      created_at: createdAt.toISOString(),
      updated_at: new Date(createdAt.getTime() + Math.floor(Math.random() * 3) * 24 * 60 * 60 * 1000).toISOString(),
    };
  });
};

export const generateMockKPIs = () => {
  const categories = ['precio_vo', 'stock', 'financiacion', 'competencia', 'ventas'];
  
  return categories.map((category, i) => {
    const baseValue = Math.floor(Math.random() * 10000) + 5000;
    const previousValue = baseValue + (Math.floor(Math.random() * 2000) - 1000);
    const change = ((baseValue - previousValue) / previousValue) * 100;
    
    return {
      _id: `mock-kpi-${i}`,
      name: `KPI ${category}`,
      category,
      value: baseValue,
      previous_value: previousValue,
      unit: category === 'precio_vo' ? '€' : category === 'stock' ? 'unidades' : 'unidad',
      trend: change > 5 ? 'up' : change < -5 ? 'down' : 'stable',
      change_percentage: parseFloat(change.toFixed(2)),
      period: 'monthly',
      period_date: new Date().toISOString(),
    };
  });
};

export const generateMockKPISummary = () => {
  const categories = ['precio_vo', 'stock', 'financiacion', 'competencia', 'ventas'];
  
  return categories.map((category) => {
    const current = Math.floor(Math.random() * 10000) + 5000;
    const average = current + (Math.floor(Math.random() * 2000) - 1000);
    const min = Math.floor(average * 0.7);
    const max = Math.floor(average * 1.3);
    const trend = Math.random() > 0.5 ? 'up' : Math.random() > 0.5 ? 'down' : 'stable';
    
    return {
      category,
      current,
      average,
      min,
      max,
      trend,
      count: Math.floor(Math.random() * 50) + 20,
    };
  });
};

export const generateMockCompetitors = () => {
  const names = ['Concesionario ABC', 'AutoVenta XYZ', 'MotorGroup 123', 'Cars Plus', 'AutoCenter Premium'];
  const types = ['concesionario', 'portal_vo', 'marketplace', 'otro'];
  const regions = ['Madrid', 'Barcelona', 'Valencia', 'Sevilla', 'Bilbao'];
  const brands = ['Toyota', 'Volkswagen', 'Ford', 'BMW', 'Mercedes-Benz'];
  
  return names.map((name, i) => ({
    _id: `mock-competitor-${i}`,
    name,
    website: `https://${name.toLowerCase().replace(/\s+/g, '')}.com`,
    type: types[Math.floor(Math.random() * types.length)],
    region: regions[Math.floor(Math.random() * regions.length)],
    brands_monitored: brands.slice(0, Math.floor(Math.random() * 3) + 2),
    is_active: Math.random() > 0.2,
    last_scraped_at: new Date(Date.now() - Math.floor(Math.random() * 7) * 24 * 60 * 60 * 1000).toISOString(),
  }));
};

export const generateMockNotifications = () => {
  const types = ['lead', 'deal', 'property', 'financing', 'reminder', 'alert', 'recommendation'];
  const titles = {
    lead: 'Nuevo lead recibido',
    deal: 'Oferta aceptada',
    property: 'Nueva propiedad disponible',
    financing: 'Solicitud de financiación',
    reminder: 'Recordatorio importante',
    alert: 'Alerta de mercado',
    recommendation: 'Nueva recomendación',
  };
  const messages = {
    lead: 'Has recibido un nuevo lead interesado en vehículos.',
    deal: 'Un cliente ha aceptado tu oferta de vehículo.',
    property: 'Se ha añadido una nueva propiedad a tu inventario.',
    financing: 'Nueva solicitud de financiación pendiente de revisión.',
    reminder: 'No olvides seguir con el seguimiento de leads pendientes.',
    alert: 'Se ha detectado un cambio importante en el mercado.',
    recommendation: 'Tienes una nueva recomendación de acción disponible.',
  };
  
  return Array.from({ length: 15 }, (_, i) => {
    const type = types[Math.floor(Math.random() * types.length)];
    const hoursAgo = Math.floor(Math.random() * 48);
    const isRead = Math.random() > 0.4;
    
    return {
      _id: `mock-notification-${i}`,
      id: `mock-notification-${i}`,
      type,
      title: titles[type as keyof typeof titles],
      message: messages[type as keyof typeof messages],
      read: isRead,
      link: type === 'lead' ? '/contacts' : type === 'deal' ? '/deals' : type === 'property' ? '/properties' : '/',
      createdAt: new Date(Date.now() - hoursAgo * 60 * 60 * 1000).toISOString(),
      created_at: new Date(Date.now() - hoursAgo * 60 * 60 * 1000).toISOString(),
    };
  });
};
