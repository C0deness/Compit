import { useEffect, useState, useMemo } from "react";
import { Link } from "react-router";
import PageMeta from "../../components/common/PageMeta";
import { newsAPI, alertsAPI, recommendationsAPI, kpisAPI } from "../../services/api";
import Badge from "../../components/ui/badge/Badge";
import Alert from "../../components/ui/alert/Alert";
import Chart from "react-apexcharts";
import { ApexOptions } from "apexcharts";
import {
  BoltIcon,
  ArrowUpIcon,
  ArrowDownIcon,
  FileIcon,
  PieChartIcon,
  ShootingStarIcon,
  ChatIcon,
  GridIcon,
} from "../../icons";

export default function Home() {
  const [stats, setStats] = useState({
    totalNews: 0,
    unreadAlerts: 0,
    activeRecommendations: 0,
    kpiCount: 0,
  });
  const [loading, setLoading] = useState(true);
  const [news, setNews] = useState<any[]>([]);
  const [alerts, setAlerts] = useState<any[]>([]);
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [kpis, setKpis] = useState<any[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [newsRes, alertsRes, recommendationsRes, kpisRes] = await Promise.all([
          newsAPI.getAll({ limit: 50 }),
          alertsAPI.getAll({ limit: 50 }),
          recommendationsAPI.getAll({ limit: 50 }),
          kpisAPI.getSummary({ period: 'monthly' }),
        ]);

        setNews(newsRes.news || []);
        setAlerts(alertsRes.alerts || []);
        setRecommendations(recommendationsRes.recommendations || []);
        setKpis(kpisRes.summary || []);

        setStats({
          totalNews: newsRes.news?.length || 0,
          unreadAlerts: alertsRes.unread_count || 0,
          activeRecommendations: recommendationsRes.recommendations?.length || 0,
          kpiCount: kpisRes.summary?.length || 0,
        });
      } catch (error) {
        console.error("Error cargando datos:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Datos para gráficas
  const newsByCategory = useMemo(() => {
    const categoryCount: Record<string, number> = {};
    news.forEach((item) => {
      const cat = item.category || 'general';
      categoryCount[cat] = (categoryCount[cat] || 0) + 1;
    });
    return categoryCount;
  }, [news]);

  const alertsBySeverity = useMemo(() => {
    const severityCount: Record<string, number> = {};
    alerts.forEach((alert) => {
      const sev = alert.severity || 'medium';
      severityCount[sev] = (severityCount[sev] || 0) + 1;
    });
    return severityCount;
  }, [alerts]);

  const recommendationsByStatus = useMemo(() => {
    const statusCount: Record<string, number> = {};
    recommendations.forEach((rec) => {
      const stat = rec.status || 'pending';
      statusCount[stat] = (statusCount[stat] || 0) + 1;
    });
    return statusCount;
  }, [recommendations]);

  const newsTimeline = useMemo(() => {
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (6 - i));
      date.setHours(0, 0, 0, 0);
      return date;
    });
    
    const labels = last7Days.map(date => 
      date.toLocaleDateString('es-ES', { day: 'numeric', month: 'short' })
    );
    
    const counts = last7Days.map((dayDate) => {
      return news.filter((item) => {
        const itemDate = new Date(item.published_at);
        itemDate.setHours(0, 0, 0, 0);
        return itemDate.getTime() === dayDate.getTime();
      }).length;
    });
    
    return { labels, data: counts };
  }, [news]);

  const metricCards = [
    {
      title: "Noticias Nuevas",
      value: stats.totalNews,
      change: "+12%",
      changeType: "increase" as const,
      icon: FileIcon,
      color: "bg-blue-100 dark:bg-blue-500/20",
      iconColor: "text-blue-600 dark:text-blue-400",
      path: "/news",
    },
    {
      title: "Alertas Pendientes",
      value: stats.unreadAlerts,
      change: stats.unreadAlerts > 0 ? "Revisar" : "0",
      changeType: stats.unreadAlerts > 0 ? ("increase" as const) : ("neutral" as const),
      icon: BoltIcon,
      color: "bg-red-100 dark:bg-red-500/20",
      iconColor: "text-red-600 dark:text-red-400",
      path: "/alerts",
    },
    {
      title: "Recomendaciones",
      value: stats.activeRecommendations,
      change: "Actuar",
      changeType: "increase" as const,
      icon: ShootingStarIcon,
      color: "bg-green-100 dark:bg-green-500/20",
      iconColor: "text-green-600 dark:text-green-400",
      path: "/recommendations",
    },
    {
      title: "KPIs Monitoreados",
      value: stats.kpiCount,
      change: "Ver",
      changeType: "neutral" as const,
      icon: PieChartIcon,
      color: "bg-purple-100 dark:bg-purple-500/20",
      iconColor: "text-purple-600 dark:text-purple-400",
      path: "/kpis",
    },
  ];

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'error';
      case 'high':
        return 'warning';
      case 'medium':
        return 'info';
      default:
        return 'info';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'precio':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-500/20 dark:text-blue-400';
      case 'stock':
        return 'bg-green-100 text-green-800 dark:bg-green-500/20 dark:text-green-400';
      case 'financiacion':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-500/20 dark:text-purple-400';
      case 'competencia':
        return 'bg-orange-100 text-orange-800 dark:bg-orange-500/20 dark:text-orange-400';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-500/20 dark:text-gray-400';
    }
  };

  return (
    <>
      <PageMeta
        title="Dashboard - AutoMarket Intelligence"
        description="Dashboard principal de AutoMarket Intelligence - Vigilancia competitiva para concesionarios"
      />
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
            Dashboard AutoMarket Intelligence
          </h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Vigilancia competitiva en tiempo real para tu concesionario
          </p>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-gray-500 dark:text-gray-400">Cargando datos...</div>
          </div>
        ) : (
          <>
            {/* Metrics Cards */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {metricCards.map((card, index) => {
                const IconComponent = card.icon;
                return (
                  <Link
                    key={index}
                    to={card.path}
                    className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] md:p-6 hover:shadow-lg transition-shadow"
                  >
                    <div className={`flex items-center justify-center w-12 h-12 rounded-xl ${card.color}`}>
                      <IconComponent className={`size-6 ${card.iconColor}`} />
                    </div>

                    <div className="flex items-end justify-between mt-5">
                      <div>
                        <span className="text-sm text-gray-500 dark:text-gray-400">
                          {card.title}
                        </span>
                        <h4 className="mt-2 font-bold text-gray-800 text-title-sm dark:text-white/90">
                          {card.value.toLocaleString()}
                        </h4>
                      </div>
                      {card.changeType === "increase" ? (
                        <Badge color="success" size="sm">
                          <ArrowUpIcon className="w-3 h-3" />
                          {card.change}
                        </Badge>
                      ) : card.changeType === "decrease" ? (
                        <Badge color="error" size="sm">
                          <ArrowDownIcon className="w-3 h-3" />
                          {card.change}
                        </Badge>
                      ) : (
                        <Badge color="info" size="sm">
                          {card.change}
                        </Badge>
                      )}
                    </div>
                  </Link>
                );
              })}
            </div>

            {/* Charts Section */}
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
              {/* News by Category Chart */}
              <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] sm:p-6">
                <h2 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">
                  Noticias por Categoría
                </h2>
                {Object.keys(newsByCategory).length > 0 ? (
                  <Chart
                    options={{
                      chart: {
                        type: 'donut',
                        fontFamily: 'Outfit, sans-serif',
                      },
                      labels: Object.keys(newsByCategory).map(cat => {
                        const labels: Record<string, string> = {
                          precio: 'Precio',
                          stock: 'Stock',
                          financiacion: 'Financiación',
                          competencia: 'Competencia',
                          general: 'General',
                        };
                        return labels[cat] || cat;
                      }),
                      colors: ['#3B82F6', '#10B981', '#8B5CF6', '#F59E0B', '#6B7280'],
                      legend: {
                        position: 'bottom',
                      },
                      dataLabels: {
                        enabled: true,
                        formatter: (val: number) => `${Math.round(val)}%`,
                      },
                      tooltip: {
                        y: {
                          formatter: (val: number) => `${val} noticias`,
                        },
                      },
                    } as ApexOptions}
                    series={Object.values(newsByCategory)}
                    type="donut"
                    height={300}
                  />
                ) : (
                  <p className="text-sm text-gray-500 dark:text-gray-400 text-center py-12">
                    No hay datos para mostrar
                  </p>
                )}
              </div>

              {/* Alerts by Severity Chart */}
              <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] sm:p-6">
                <h2 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">
                  Alertas por Severidad
                </h2>
                {Object.keys(alertsBySeverity).length > 0 ? (
                  <Chart
                    options={{
                      chart: {
                        type: 'bar',
                        fontFamily: 'Outfit, sans-serif',
                        toolbar: { show: false },
                      },
                      colors: ['#EF4444', '#F59E0B', '#3B82F6', '#10B981'],
                      plotOptions: {
                        bar: {
                          horizontal: false,
                          columnWidth: '60%',
                          borderRadius: 5,
                        },
                      },
                      dataLabels: {
                        enabled: true,
                      },
                      xaxis: {
                        categories: Object.keys(alertsBySeverity).map(sev => {
                          const labels: Record<string, string> = {
                            critical: 'Crítica',
                            high: 'Alta',
                            medium: 'Media',
                            low: 'Baja',
                          };
                          return labels[sev] || sev;
                        }),
                      },
                      yaxis: {
                        title: {
                          text: 'Cantidad',
                        },
                      },
                      tooltip: {
                        y: {
                          formatter: (val: number) => `${val} alertas`,
                        },
                      },
                    } as ApexOptions}
                    series={[{
                      name: 'Alertas',
                      data: Object.values(alertsBySeverity),
                    }]}
                    type="bar"
                    height={300}
                  />
                ) : (
                  <p className="text-sm text-gray-500 dark:text-gray-400 text-center py-12">
                    No hay datos para mostrar
                  </p>
                )}
              </div>
            </div>

            {/* Timeline and Status Charts */}
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
              {/* News Timeline Chart */}
              <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] sm:p-6">
                <h2 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">
                  Evolución de Noticias (Últimos 7 días)
                </h2>
                {newsTimeline.data.some(count => count > 0) ? (
                  <Chart
                    options={{
                      chart: {
                        type: 'area',
                        fontFamily: 'Outfit, sans-serif',
                        toolbar: { show: false },
                      },
                      colors: ['#3B82F6'],
                      stroke: {
                        curve: 'smooth',
                        width: 2,
                      },
                      fill: {
                        type: 'gradient',
                        gradient: {
                          opacityFrom: 0.6,
                          opacityTo: 0.1,
                        },
                      },
                      xaxis: {
                        categories: newsTimeline.labels,
                      },
                      yaxis: {
                        title: {
                          text: 'Cantidad de noticias',
                        },
                      },
                      tooltip: {
                        y: {
                          formatter: (val: number) => `${val} noticias`,
                        },
                      },
                    } as ApexOptions}
                    series={[{
                      name: 'Noticias',
                      data: newsTimeline.data,
                    }]}
                    type="area"
                    height={300}
                  />
                ) : (
                  <p className="text-sm text-gray-500 dark:text-gray-400 text-center py-12">
                    No hay datos para mostrar
                  </p>
                )}
              </div>

              {/* Recommendations by Status Chart */}
              <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] sm:p-6">
                <h2 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">
                  Recomendaciones por Estado
                </h2>
                {Object.keys(recommendationsByStatus).length > 0 ? (
                  <Chart
                    options={{
                      chart: {
                        type: 'bar',
                        fontFamily: 'Outfit, sans-serif',
                        toolbar: { show: false },
                      },
                      colors: ['#10B981', '#3B82F6', '#8B5CF6', '#6B7280'],
                      plotOptions: {
                        bar: {
                          horizontal: true,
                          borderRadius: 5,
                        },
                      },
                      dataLabels: {
                        enabled: true,
                      },
                      xaxis: {
                        categories: Object.keys(recommendationsByStatus).map(status => {
                          const labels: Record<string, string> = {
                            pending: 'Pendiente',
                            in_progress: 'En Progreso',
                            completed: 'Completada',
                            dismissed: 'Descartada',
                          };
                          return labels[status] || status;
                        }),
                      },
                      yaxis: {
                        title: {
                          text: 'Cantidad',
                        },
                      },
                      tooltip: {
                        y: {
                          formatter: (val: number) => `${val} recomendaciones`,
                        },
                      },
                    } as ApexOptions}
                    series={[{
                      name: 'Recomendaciones',
                      data: Object.values(recommendationsByStatus),
                    }]}
                    type="bar"
                    height={300}
                  />
                ) : (
                  <p className="text-sm text-gray-500 dark:text-gray-400 text-center py-12">
                    No hay datos para mostrar
                  </p>
                )}
              </div>
            </div>

            {/* KPIs Trend Chart */}
            {kpis.length > 0 && (
              <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] sm:p-6">
                <h2 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">
                  Tendencias de KPIs
                </h2>
                <Chart
                  options={{
                    chart: {
                      type: 'line',
                      fontFamily: 'Outfit, sans-serif',
                      toolbar: { show: false },
                    },
                    colors: ['#3B82F6', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444'],
                    stroke: {
                      curve: 'smooth',
                      width: 3,
                    },
                    markers: {
                      size: 5,
                    },
                    xaxis: {
                      categories: kpis.map((kpi: any) => {
                        const labels: Record<string, string> = {
                          precio_vo: 'Precio VO',
                          stock: 'Stock',
                          financiacion: 'Financiación',
                          competencia: 'Competencia',
                          ventas: 'Ventas',
                        };
                        return labels[kpi.category] || kpi.category;
                      }),
                    },
                    yaxis: {
                      title: {
                        text: 'Valor',
                      },
                    },
                    legend: {
                      position: 'top',
                    },
                    tooltip: {
                      y: {
                        formatter: (val: number) => val.toLocaleString(),
                      },
                    },
                  } as ApexOptions}
                  series={[
                    {
                      name: 'Actual',
                      data: kpis.map((kpi: any) => kpi.current || 0),
                    },
                    {
                      name: 'Promedio',
                      data: kpis.map((kpi: any) => kpi.average || 0),
                    },
                  ]}
                  type="line"
                  height={350}
                />
              </div>
            )}

            {/* Main Content Grid */}
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
              {/* News Feed */}
              <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] sm:p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold text-gray-800 dark:text-white">
                    Últimas Noticias
                  </h2>
                  <Link
                    to="/news"
                    className="text-sm text-brand-500 hover:text-brand-600 dark:text-brand-400"
                  >
                    Ver todas →
                  </Link>
                </div>
                <div className="space-y-4">
                  {news.length === 0 ? (
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      No hay noticias nuevas
                    </p>
                  ) : (
                    news.map((item) => (
                      <div
                        key={item._id}
                        className="p-4 border border-gray-200 rounded-lg dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors"
                      >
                        <div className="flex items-start justify-between mb-2">
                          <h3 className="font-medium text-gray-800 dark:text-white text-sm">
                            {item.title}
                          </h3>
                          <span className={`px-2 py-1 text-xs rounded ${getCategoryColor(item.category)}`}>
                            {item.category}
                          </span>
                        </div>
                        {item.summary && (
                          <p className="text-xs text-gray-600 dark:text-gray-400 line-clamp-2 mb-2">
                            {item.summary}
                          </p>
                        )}
                        <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
                          <span>{item.source}</span>
                          <span>{new Date(item.published_at).toLocaleDateString()}</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Alerts */}
              <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] sm:p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold text-gray-800 dark:text-white">
                    Alertas Recientes
                  </h2>
                  <Link
                    to="/alerts"
                    className="text-sm text-brand-500 hover:text-brand-600 dark:text-brand-400"
                  >
                    Ver todas →
                  </Link>
                </div>
                <div className="space-y-3">
                  {alerts.length === 0 ? (
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      No hay alertas pendientes
                    </p>
                  ) : (
                    alerts.map((alert) => (
                      <Alert
                        key={alert._id}
                        variant={getSeverityColor(alert.severity) as "success" | "error" | "warning" | "info"}
                        title={alert.title}
                        message={alert.message || alert.description || 'Sin descripción'}
                      />
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Recommendations */}
            <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] sm:p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-800 dark:text-white">
                  Recomendaciones de Acción
                </h2>
                <Link
                  to="/recommendations"
                  className="text-sm text-brand-500 hover:text-brand-600 dark:text-brand-400"
                >
                  Ver todas →
                </Link>
              </div>
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                {recommendations.length === 0 ? (
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    No hay recomendaciones pendientes
                  </p>
                ) : (
                  recommendations.map((rec) => (
                    <div
                      key={rec._id}
                      className="p-4 border border-gray-200 rounded-lg dark:border-gray-700 hover:shadow-md transition-shadow"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-medium text-gray-800 dark:text-white">
                          {rec.title}
                        </h3>
                        <Badge color="success" size="sm">
                          {rec.expected_impact}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                        {rec.description}
                      </p>
                      <Link
                        to={`/recommendations?action=${rec._id}`}
                        className="inline-flex items-center gap-2 px-4 py-2 bg-brand-500 text-white rounded-lg hover:bg-brand-600 transition-colors text-sm font-medium"
                      >
                        Actúa ahora
                        <ArrowUpIcon className="w-4 h-4 rotate-45" />
                      </Link>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* KPIs Summary */}
            {kpis.length > 0 && (
              <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] sm:p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold text-gray-800 dark:text-white">
                    Resumen de KPIs
                  </h2>
                  <Link
                    to="/kpis"
                    className="text-sm text-brand-500 hover:text-brand-600 dark:text-brand-400"
                  >
                    Ver detalle →
                  </Link>
                </div>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  {kpis.map((kpi: any, index: number) => (
                    <div
                      key={index}
                      className="p-4 border border-gray-200 rounded-lg dark:border-gray-700"
                    >
                      <div className="text-sm text-gray-500 dark:text-gray-400 mb-1">
                        {kpi.category}
                      </div>
                      <div className="text-2xl font-bold text-gray-800 dark:text-white mb-1">
                        {kpi.current?.toLocaleString() || '0'}
                      </div>
                      <div className="flex items-center gap-2">
                        {kpi.trend === 'up' ? (
                          <Badge color="success" size="sm">
                            <ArrowUpIcon className="w-3 h-3" />
                            ↑
                          </Badge>
                        ) : kpi.trend === 'down' ? (
                          <Badge color="error" size="sm">
                            <ArrowDownIcon className="w-3 h-3" />
                            ↓
                          </Badge>
                        ) : (
                          <Badge color="info" size="sm">→</Badge>
                        )}
                        <span className="text-xs text-gray-500 dark:text-gray-400">
                          Promedio: {kpi.average?.toFixed(0) || '0'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Quick Actions */}
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
              <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] sm:p-6">
                <div className="flex items-center gap-2 mb-4">
                  <GridIcon className="w-5 h-5 text-brand-500 dark:text-brand-400" />
                  <h2 className="text-lg font-semibold text-gray-800 dark:text-white">
                    Accesos Rápidos
                  </h2>
                </div>
                <div className="space-y-3">
                  <Link
                    to="/news"
                    className="block p-4 transition-colors bg-gray-50 rounded-lg hover:bg-gray-100 dark:bg-gray-700 dark:hover:bg-gray-600"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-gray-700 dark:text-gray-300">
                        Ver Noticias
                      </span>
                      <span className="text-gray-400">→</span>
                    </div>
                  </Link>
                  <Link
                    to="/competitors"
                    className="block p-4 transition-colors bg-gray-50 rounded-lg hover:bg-gray-100 dark:bg-gray-700 dark:hover:bg-gray-600"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-gray-700 dark:text-gray-300">
                        Gestionar Competencia
                      </span>
                      <span className="text-gray-400">→</span>
                    </div>
                  </Link>
                  <Link
                    to="/reports"
                    className="block p-4 transition-colors bg-gray-50 rounded-lg hover:bg-gray-100 dark:bg-gray-700 dark:hover:bg-gray-600"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-gray-700 dark:text-gray-300">
                        Generar Reportes
                      </span>
                      <span className="text-gray-400">→</span>
                    </div>
                  </Link>
                </div>
              </div>

              <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] sm:p-6">
                <div className="flex items-center gap-2 mb-4">
                  <BoltIcon className="w-5 h-5 text-brand-500 dark:text-brand-400" />
                  <h2 className="text-lg font-semibold text-gray-800 dark:text-white">
                    Funcionalidades IA
                  </h2>
                </div>
                <div className="space-y-3">
                  <div className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg dark:from-blue-900/20 dark:to-purple-900/20">
                    <div className="flex items-center gap-2">
                      <ChatIcon className="w-5 h-5 text-brand-500 dark:text-brand-400" />
                      <div>
                        <p className="font-medium text-gray-800 dark:text-white">
                          Resúmenes Automáticos
                        </p>
                        <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                          Análisis inteligente de noticias con IA
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="p-4 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg dark:from-green-900/20 dark:to-blue-900/20">
                    <div className="flex items-center gap-2">
                      <ShootingStarIcon className="w-5 h-5 text-brand-500 dark:text-brand-400" />
                      <div>
                        <p className="font-medium text-gray-800 dark:text-white">
                          Recomendaciones Inteligentes
                        </p>
                        <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                          Acciones sugeridas basadas en análisis de datos
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </>
  );
}
