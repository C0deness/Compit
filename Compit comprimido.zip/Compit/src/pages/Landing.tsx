import { Link } from "react-router";
import { 
  BoltIcon, 
  ShootingStarIcon, 
  PieChartIcon, 
  FileIcon, 
  CheckCircleIcon, 
  ArrowRightIcon,
  GridIcon,
  ChatIcon,
  ArrowUpIcon,
  AlertIcon,
  InfoIcon
} from "../icons";

export default function Landing() {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg border-b border-gray-200 dark:border-gray-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/" className="flex items-center gap-2">
              <img
                className="dark:hidden h-8"
                src="/images/logo/logo.svg"
                alt="RockIt Logo"
              />
              <img
                className="hidden dark:block h-8"
                src="/images/logo/logo-dark.svg"
                alt="RockIt Logo"
              />
            </Link>
            <div className="hidden md:flex items-center gap-6">
              <a href="#features" className="text-gray-700 dark:text-gray-300 hover:text-brand-500 transition-colors font-medium">
                Características
              </a>
              <a href="#pricing" className="text-gray-700 dark:text-gray-300 hover:text-brand-500 transition-colors font-medium">
                Precios
              </a>
              <a href="#testimonials" className="text-gray-700 dark:text-gray-300 hover:text-brand-500 transition-colors font-medium">
                Testimonios
              </a>
            </div>
            <div className="flex items-center gap-3">
              <Link
                to="/signin"
                className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:text-brand-500 transition-colors font-medium hidden sm:block"
              >
                Iniciar Sesión
              </Link>
              <Link
                to="/signup"
                className="px-6 py-2.5 bg-gradient-to-r from-brand-500 to-brand-600 text-white rounded-lg hover:from-brand-600 hover:to-brand-700 transition-all shadow-lg shadow-brand-500/25 font-medium"
              >
                Prueba Gratis
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        {/* Background Gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-brand-50 via-white to-blue-light-50 dark:from-gray-900 dark:via-gray-900 dark:to-gray-800"></div>
        <div className="absolute top-0 right-0 w-96 h-96 bg-brand-500/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-light-500/10 rounded-full blur-3xl"></div>
        
        <div className="container mx-auto relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-brand-50 dark:bg-brand-500/10 rounded-full mb-8">
              <BoltIcon className="w-4 h-4 text-brand-500" />
              <span className="text-sm font-medium text-brand-600 dark:text-brand-400">
                Plataforma #1 en Vigilancia Competitiva
              </span>
            </div>

            {/* Main Headline */}
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-gray-900 dark:text-white mb-6 leading-tight">
              Domina el Mercado con
              <span className="block bg-gradient-to-r from-brand-600 via-brand-500 to-blue-light-500 bg-clip-text text-transparent">
                Inteligencia Competitiva
              </span>
            </h1>

            {/* Subheadline */}
            <p className="text-xl sm:text-2xl text-gray-600 dark:text-gray-300 mb-10 max-w-2xl mx-auto leading-relaxed">
              Monitorea precios, stock y financiación en tiempo real. Recibe alertas inteligentes y recomendaciones de acción basadas en IA para tomar decisiones más rápidas y rentables.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
              <Link
                to="/signup"
                className="group px-8 py-4 bg-gradient-to-r from-brand-500 to-brand-600 text-white rounded-xl hover:from-brand-600 hover:to-brand-700 transition-all shadow-xl shadow-brand-500/25 hover:shadow-2xl hover:shadow-brand-500/40 font-semibold text-lg flex items-center gap-2 transform hover:scale-105"
              >
                Comenzar Gratis
                <ArrowRightIcon className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link
                to="#demo"
                className="px-8 py-4 bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white rounded-xl hover:border-brand-500 dark:hover:border-brand-500 transition-all font-semibold text-lg"
              >
                Ver Demo
              </Link>
            </div>

            {/* Social Proof */}
            <div className="flex flex-wrap items-center justify-center gap-8 text-sm text-gray-600 dark:text-gray-400">
              <div className="flex items-center gap-2">
                <CheckCircleIcon className="w-5 h-5 text-success-500" />
                <span>Sin tarjeta de crédito</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircleIcon className="w-5 h-5 text-success-500" />
                <span>14 días gratis</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircleIcon className="w-5 h-5 text-success-500" />
                <span>Cancelación en cualquier momento</span>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-20 max-w-4xl mx-auto">
            <div className="text-center p-6 bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm rounded-2xl border border-gray-200 dark:border-gray-700">
              <div className="text-3xl font-bold text-brand-600 dark:text-brand-400 mb-2">500+</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Concesionarios</div>
            </div>
            <div className="text-center p-6 bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm rounded-2xl border border-gray-200 dark:border-gray-700">
              <div className="text-3xl font-bold text-brand-600 dark:text-brand-400 mb-2">10K+</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Alertas Diarias</div>
            </div>
            <div className="text-center p-6 bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm rounded-2xl border border-gray-200 dark:border-gray-700">
              <div className="text-3xl font-bold text-brand-600 dark:text-brand-400 mb-2">98%</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Satisfacción</div>
            </div>
            <div className="text-center p-6 bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm rounded-2xl border border-gray-200 dark:border-gray-700">
              <div className="text-3xl font-bold text-brand-600 dark:text-brand-400 mb-2">24/7</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Monitoreo</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50 dark:bg-gray-800/50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 dark:text-white mb-4">
              Todo lo que necesitas para
              <span className="block text-brand-600 dark:text-brand-400">dominar el mercado</span>
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              Herramientas potentes diseñadas específicamente para concesionarios que quieren liderar
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Feature 1 */}
            <div className="group p-8 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700 hover:border-brand-500 dark:hover:border-brand-500 transition-all hover:shadow-xl hover:shadow-brand-500/10">
              <div className="w-14 h-14 bg-gradient-to-br from-brand-500 to-brand-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <BoltIcon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">
                Vigilancia en Tiempo Real
              </h3>
              <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                Monitoreo continuo de precios, stock y financiación de la competencia. Alertas instantáneas cuando detectamos cambios relevantes.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="group p-8 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700 hover:border-brand-500 dark:hover:border-brand-500 transition-all hover:shadow-xl hover:shadow-brand-500/10">
              <div className="w-14 h-14 bg-gradient-to-br from-success-500 to-success-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <FileIcon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">
                Resúmenes con IA
              </h3>
              <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                Procesamiento inteligente de noticias del sector. Resúmenes automáticos y extracción de palabras clave para ahorrar tiempo.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="group p-8 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700 hover:border-brand-500 dark:hover:border-brand-500 transition-all hover:shadow-xl hover:shadow-brand-500/10">
              <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <ShootingStarIcon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">
                Recomendaciones Inteligentes
              </h3>
              <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                Acciones sugeridas basadas en análisis de datos y tendencias. Optimiza precios, stock y estrategias de marketing automáticamente.
              </p>
            </div>

            {/* Feature 4 */}
            <div className="group p-8 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700 hover:border-brand-500 dark:hover:border-brand-500 transition-all hover:shadow-xl hover:shadow-brand-500/10">
              <div className="w-14 h-14 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <PieChartIcon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">
                Dashboard Personalizado
              </h3>
              <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                KPIs, gráficos interactivos y métricas clave en un solo lugar. Visualiza tendencias y toma decisiones basadas en datos.
              </p>
            </div>

            {/* Feature 5 */}
            <div className="group p-8 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700 hover:border-brand-500 dark:hover:border-brand-500 transition-all hover:shadow-xl hover:shadow-brand-500/10">
              <div className="w-14 h-14 bg-gradient-to-br from-blue-light-500 to-blue-light-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <AlertIcon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">
                Alertas Inteligentes
              </h3>
              <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                Notificaciones personalizables por email y WhatsApp. Recibe solo las alertas que realmente importan para tu negocio.
              </p>
            </div>

            {/* Feature 6 */}
            <div className="group p-8 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700 hover:border-brand-500 dark:hover:border-brand-500 transition-all hover:shadow-xl hover:shadow-brand-500/10">
              <div className="w-14 h-14 bg-gradient-to-br from-warning-500 to-warning-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <ArrowUpIcon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">
                Análisis Predictivo
              </h3>
              <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                Predicciones de tendencias del mercado basadas en machine learning. Anticípate a los movimientos de la competencia.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 dark:text-white mb-4">
              Cómo funciona
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              En 3 simples pasos, transforma tu estrategia competitiva
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-brand-500 to-brand-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-brand-500/25">
                <span className="text-3xl font-bold text-white">1</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">
                Configura tu Perfil
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                Define tus competidores, marcas y modelos de interés. Nuestro sistema comenzará a monitorear automáticamente.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-brand-500 to-brand-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-brand-500/25">
                <span className="text-3xl font-bold text-white">2</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">
                Recibe Alertas Inteligentes
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                Obtén notificaciones en tiempo real sobre cambios de precios, stock y movimientos de la competencia.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-brand-500 to-brand-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-brand-500/25">
                <span className="text-3xl font-bold text-white">3</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">
                Toma Acciones Rentables
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                Sigue las recomendaciones de IA para optimizar precios, rotar stock y aumentar tus ventas.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-900">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 dark:text-white mb-4">
              Planes que se adaptan a ti
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              Elige el plan perfecto para tu concesionario. Todos incluyen prueba gratuita de 14 días.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Basic Plan */}
            <div className="p-8 bg-white dark:bg-gray-900 rounded-2xl border-2 border-gray-200 dark:border-gray-700 hover:border-brand-500 dark:hover:border-brand-500 transition-all">
              <div className="mb-6">
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                  Básico
                </h3>
                <div className="text-5xl font-bold text-gray-900 dark:text-white mb-1">
                  €490
                  <span className="text-lg text-gray-600 dark:text-gray-400 font-normal">/mes</span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Ideal para concesionarios pequeños</p>
              </div>
              <ul className="space-y-4 mb-8">
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 text-success-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 dark:text-gray-300">Monitoreo de hasta 5 competidores</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 text-success-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 dark:text-gray-300">Alertas de precios y stock en tiempo real</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 text-success-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 dark:text-gray-300">Dashboard con KPIs básicos</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 text-success-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 dark:text-gray-300">Resúmenes automáticos de noticias del sector</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 text-success-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 dark:text-gray-300">Notificaciones por email</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 text-success-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 dark:text-gray-300">Soporte por email</span>
                </li>
              </ul>
              <Link
                to="/signup"
                className="block w-full text-center px-6 py-3 border-2 border-brand-500 text-brand-500 rounded-xl hover:bg-brand-50 dark:hover:bg-brand-500/10 transition-colors font-semibold"
              >
                Empezar Ahora
              </Link>
            </div>

            {/* Professional Plan - Featured */}
            <div className="p-8 bg-gradient-to-br from-brand-500 to-brand-600 text-white rounded-2xl border-2 border-brand-500 relative transform scale-105 shadow-2xl shadow-brand-500/25">
              <div className="absolute top-0 right-0 bg-yellow-400 text-yellow-900 px-4 py-1.5 rounded-bl-xl rounded-tr-2xl text-sm font-bold">
                MÁS POPULAR
              </div>
              <div className="mb-6">
                <h3 className="text-2xl font-bold mb-2">Profesional</h3>
                <div className="text-5xl font-bold mb-1">
                  €1,490
                  <span className="text-lg opacity-80 font-normal">/mes</span>
                </div>
                <p className="text-sm opacity-90">Para concesionarios en crecimiento</p>
              </div>
              <ul className="space-y-4 mb-8">
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 mt-0.5 flex-shrink-0" />
                  <span>Monitoreo ilimitado de competidores</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 mt-0.5 flex-shrink-0" />
                  <span>Alertas inteligentes de precios, stock y financiación</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 mt-0.5 flex-shrink-0" />
                  <span>Recomendaciones de IA para optimizar estrategias</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 mt-0.5 flex-shrink-0" />
                  <span>Análisis de tendencias del mercado automotriz</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 mt-0.5 flex-shrink-0" />
                  <span>Exportación de reportes en PDF y Excel</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 mt-0.5 flex-shrink-0" />
                  <span>Notificaciones por email y WhatsApp</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 mt-0.5 flex-shrink-0" />
                  <span>Dashboard avanzado con gráficas y métricas</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 mt-0.5 flex-shrink-0" />
                  <span>Análisis predictivo de movimientos del mercado</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 mt-0.5 flex-shrink-0" />
                  <span>Soporte prioritario por email y chat</span>
                </li>
              </ul>
              <Link
                to="/signup"
                className="block w-full text-center px-6 py-3 bg-white text-brand-500 rounded-xl hover:bg-gray-100 transition-colors font-semibold shadow-lg"
              >
                Empezar Ahora
              </Link>
            </div>

            {/* Enterprise Plan */}
            <div className="p-8 bg-white dark:bg-gray-900 rounded-2xl border-2 border-gray-200 dark:border-gray-700 hover:border-brand-500 dark:hover:border-brand-500 transition-all">
              <div className="mb-6">
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                  Enterprise
                </h3>
                <div className="text-5xl font-bold text-gray-900 dark:text-white mb-1">
                  Desde €4,900
                  <span className="text-lg text-gray-600 dark:text-gray-400 font-normal">/mes</span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Para grandes grupos y cadenas de concesionarios</p>
              </div>
              <ul className="space-y-4 mb-8">
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 text-success-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 dark:text-gray-300">Todo del plan Profesional</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 text-success-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 dark:text-gray-300">API personalizada para integraciones</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 text-success-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 dark:text-gray-300">Monitoreo multi-marca y multi-location</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 text-success-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 dark:text-gray-300">Soporte dedicado 24/7 con SLA garantizado</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 text-success-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 dark:text-gray-300">Integraciones con sistemas ERP y CRM</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 text-success-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 dark:text-gray-300">Capacitación y onboarding del equipo</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 text-success-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 dark:text-gray-300">Gestor de cuenta dedicado</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircleIcon className="w-5 h-5 text-success-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 dark:text-gray-300">Reportes personalizados y white-label</span>
                </li>
              </ul>
              <Link
                to="/signup"
                className="block w-full text-center px-6 py-3 border-2 border-brand-500 text-brand-500 rounded-xl hover:bg-brand-50 dark:hover:bg-brand-500/10 transition-colors font-semibold"
              >
                Contactar Ventas
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 dark:text-white mb-4">
              Confiado por cientos de concesionarios
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              Descubre cómo RockIt está transformando negocios
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <div className="p-8 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-lg">
              <div className="flex items-center gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <ShootingStarIcon key={i} className="w-5 h-5 text-warning-400" />
                ))}
              </div>
              <p className="text-gray-700 dark:text-gray-300 mb-6 leading-relaxed">
                "RockIt nos ha permitido estar siempre un paso por delante de la competencia. Las alertas inteligentes son increíbles y nos han ayudado a aumentar nuestras ventas en un 35%."
              </p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-brand-500 to-brand-600 rounded-full flex items-center justify-center text-white font-bold">
                  JP
                </div>
                <div>
                  <div className="font-semibold text-gray-900 dark:text-white">Juan Pérez</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Director, Concesionario ABC</div>
                </div>
              </div>
            </div>

            <div className="p-8 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-lg">
              <div className="flex items-center gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <ShootingStarIcon key={i} className="w-5 h-5 text-warning-400" />
                ))}
              </div>
              <p className="text-gray-700 dark:text-gray-300 mb-6 leading-relaxed">
                "Las recomendaciones de IA nos han ayudado a optimizar nuestros precios y aumentar las ventas en un 30%. El ROI ha sido increíble desde el primer mes."
              </p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-success-500 to-success-600 rounded-full flex items-center justify-center text-white font-bold">
                  MG
                </div>
                <div>
                  <div className="font-semibold text-gray-900 dark:text-white">María García</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Gerente, AutoVenta XYZ</div>
                </div>
              </div>
            </div>

            <div className="p-8 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-lg">
              <div className="flex items-center gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <ShootingStarIcon key={i} className="w-5 h-5 text-warning-400" />
                ))}
              </div>
              <p className="text-gray-700 dark:text-gray-300 mb-6 leading-relaxed">
                "El dashboard es intuitivo y las notificaciones en tiempo real nos mantienen informados de todo lo importante. Es como tener un equipo de analistas trabajando 24/7."
              </p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold">
                  CL
                </div>
                <div>
                  <div className="font-semibold text-gray-900 dark:text-white">Carlos López</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">CEO, MotorGroup 123</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-brand-500 via-brand-600 to-blue-light-600 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-white/[0.05] bg-[size:20px_20px]"></div>
        <div className="container mx-auto relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-4xl sm:text-5xl font-bold mb-6">
              ¿Listo para dominar el mercado?
            </h2>
            <p className="text-xl mb-10 opacity-90">
              Únete a más de 500 concesionarios que ya están usando RockIt para tomar decisiones más inteligentes y aumentar sus ventas.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/signup"
                className="px-8 py-4 bg-white text-brand-600 rounded-xl hover:bg-gray-100 transition-colors text-lg font-semibold shadow-xl"
              >
                Comenzar Prueba Gratis
              </Link>
              <Link
                to="#demo"
                className="px-8 py-4 bg-white/10 backdrop-blur-sm border-2 border-white/20 text-white rounded-xl hover:bg-white/20 transition-colors text-lg font-semibold"
              >
                Solicitar Demo
              </Link>
            </div>
            <p className="mt-6 text-sm opacity-80">
              Sin tarjeta de crédito • 14 días gratis • Cancelación en cualquier momento
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-12 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <Link to="/" className="flex items-center gap-2 mb-4">
                <img
                  className="dark:hidden h-8"
                  src="/images/logo/logo.svg"
                  alt="RockIt Logo"
                />
                <img
                  className="hidden dark:block h-8"
                  src="/images/logo/logo-dark.svg"
                  alt="RockIt Logo"
                />
              </Link>
              <p className="text-sm mb-4">
                Vigilancia competitiva en tiempo real para concesionarios. Domina el mercado con inteligencia artificial.
              </p>
              <div className="flex gap-4">
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-brand-500 transition-colors">
                  <span className="text-white text-sm">f</span>
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-brand-500 transition-colors">
                  <span className="text-white text-sm">in</span>
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-brand-500 transition-colors">
                  <span className="text-white text-sm">t</span>
                </a>
              </div>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Producto</h4>
              <ul className="space-y-2 text-sm">
                <li><Link to="/pricing" className="hover:text-white transition-colors">Precios</Link></li>
                <li><Link to="/signup" className="hover:text-white transition-colors">Registro</Link></li>
                <li><a href="#features" className="hover:text-white transition-colors">Características</a></li>
                <li><a href="#demo" className="hover:text-white transition-colors">Demo</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Soporte</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white transition-colors">Documentación</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Centro de Ayuda</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contacto</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Estado del Sistema</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white transition-colors">Privacidad</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Términos de Servicio</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Cookies</a></li>
                <li><a href="#" className="hover:text-white transition-colors">GDPR</a></li>
              </ul>
            </div>
          </div>
          <div className="pt-8 border-t border-gray-800 text-center text-sm">
            © 2024 RockIt. Todos los derechos reservados.
          </div>
        </div>
      </footer>
    </div>
  );
}
