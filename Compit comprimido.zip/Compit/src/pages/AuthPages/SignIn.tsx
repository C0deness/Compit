import PageMeta from "../../components/common/PageMeta";
import AuthLayout from "./AuthPageLayout";
import SignInForm from "../../components/auth/SignInForm";

export default function SignIn() {
  return (
    <>
      <PageMeta
        title="Iniciar Sesión - RockIt"
        description="Inicia sesión en RockIt - CRM Inmobiliario Potenciado por IA"
      />
      <AuthLayout>
        <SignInForm />
      </AuthLayout>
    </>
  );
}
