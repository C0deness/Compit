import PageMeta from "../../components/common/PageMeta";
import AuthLayout from "./AuthPageLayout";
import SignUpForm from "../../components/auth/SignUpForm";

export default function SignUp() {
  return (
    <>
      <PageMeta
        title="Registro - RockIt"
        description="Regístrate en RockIt - CRM Inmobiliario Potenciado por IA"
      />
      <AuthLayout>
        <SignUpForm />
      </AuthLayout>
    </>
  );
}
