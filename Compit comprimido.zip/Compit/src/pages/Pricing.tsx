import { useState } from "react";
import { useNavigate } from "react-router";
import PageMeta from "../components/common/PageMeta";
import Button from "../components/ui/button/Button";
import Badge from "../components/ui/badge/Badge";
import { CheckCircleIcon, BoltIcon, ArrowRightIcon, ShootingStarIcon } from "../icons";

export default function Pricing() {
  const navigate = useNavigate();
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly");

  const plans = [
    {
      name: "Básico",
      description: "Ideal para concesionarios pequeños",
      price: {
        monthly: 490,
        yearly: 4900,
      },
      features: [
        "Monitoreo de hasta 5 competidores",
        "Alertas de precios y stock en tiempo real",
        "Dashboard con KPIs básicos",
        "Resúmenes automáticos de noticias del sector",
        "Notificaciones por email",
        "Soporte por email",
      ],
      limitations: [
        "Sin recomendaciones de IA",
        "Sin análisis predictivo",
        "Sin exportación de reportes",
      ],
      popular: false,
      color: "info",
    },
    {
      name: "Profesional",
      description: "Para concesionarios en crecimiento",
      price: {
        monthly: 1490,
        yearly: 14900,
      },
      features: [
        "Monitoreo ilimitado de competidores",
        "Alertas inteligentes de precios, stock y financiación",
        "Recomendaciones de IA para optimizar estrategias",
        "Análisis de tendencias del mercado automotriz",
        "Exportación de reportes en PDF y Excel",
        "Notificaciones por email y WhatsApp",
        "Dashboard avanzado con gráficas y métricas",
        "Análisis predictivo de movimientos del mercado",
        "Soporte prioritario por email y chat",
      ],
      limitations: [],
      popular: true,
      color: "brand",
    },
    {
      name: "Enterprise",
      description: "Para grandes grupos y cadenas de concesionarios",
      price: {
        monthly: 4900,
        yearly: 49000,
      },
      features: [
        "Todo del plan Profesional",
        "API personalizada para integraciones",
        "Monitoreo multi-marca y multi-location",
        "Soporte dedicado 24/7 con SLA garantizado",
        "Integraciones con sistemas ERP y CRM",
        "Capacitación y onboarding del equipo",
        "Gestor de cuenta dedicado",
        "Reportes personalizados y white-label",
      ],
      limitations: [],
      popular: false,
      color: "success",
    },
  ];

  const handleSelectPlan = (planName: string) => {
    // Aquí puedes agregar la lógica para procesar el pago
    console.log(`Plan seleccionado: ${planName}`);
    // Ejemplo: redirigir a checkout o mostrar modal de pago
    alert(`¡Excelente elección! Has seleccionado el plan ${planName}. Redirigiendo al checkout...`);
  };

  const getYearlyDiscount = (monthlyPrice: number) => {
    const yearlyPrice = monthlyPrice * 12;
    const discountedPrice = monthlyPrice * 10;
    const savings = yearlyPrice - discountedPrice;
    return { savings, percentage: Math.round((savings / yearlyPrice) * 100) };
  };

  return (
    <>
      <PageMeta title="Planes y Precios - RockIt" description="Elige el plan perfecto para tu concesionario" />
      <div className="space-y-8">
        {/* Header */}
        <div className="text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <BoltIcon className="w-8 h-8 text-brand-500 dark:text-brand-400" />
            <h1 className="text-4xl font-bold text-gray-800 dark:text-white">
              Elige tu Plan
            </h1>
          </div>
          <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
            Potencia tu concesionario con vigilancia competitiva en tiempo real e inteligencia artificial
          </p>

          {/* Billing Toggle */}
          <div className="flex items-center justify-center gap-4 mt-6">
            <span className={`text-sm font-medium ${billingCycle === "monthly" ? "text-gray-900 dark:text-white" : "text-gray-500 dark:text-gray-400"}`}>
              Mensual
            </span>
            <button
              onClick={() => setBillingCycle(billingCycle === "monthly" ? "yearly" : "monthly")}
              className="relative inline-flex h-6 w-11 items-center rounded-full bg-brand-500 transition-colors focus:outline-none focus:ring-2 focus:ring-brand-500 focus:ring-offset-2"
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  billingCycle === "yearly" ? "translate-x-6" : "translate-x-1"
                }`}
              />
            </button>
            <span className={`text-sm font-medium ${billingCycle === "yearly" ? "text-gray-900 dark:text-white" : "text-gray-500 dark:text-gray-400"}`}>
              Anual
            </span>
            {billingCycle === "yearly" && (
              <Badge color="success" variant="light" size="sm">
                Ahorra hasta 17%
              </Badge>
            )}
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          {plans.map((plan, index) => {
            const price = billingCycle === "monthly" ? plan.price.monthly : plan.price.yearly;
            const discount = billingCycle === "yearly" ? getYearlyDiscount(plan.price.monthly) : null;

            return (
              <div
                key={index}
                className={`relative rounded-2xl border-2 p-8 transition-all ${
                  plan.popular
                    ? "border-brand-500 bg-brand-50/50 dark:bg-brand-900/20 shadow-xl scale-105 z-10"
                    : "border-gray-200 bg-white dark:bg-gray-800 dark:border-gray-700 shadow-sm hover:shadow-lg"
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-0 right-0 flex justify-center z-20">
                    <div className="relative">
                      <div className="absolute inset-0 bg-brand-500 blur-md opacity-50 rounded-full animate-pulse"></div>
                      <div className="relative bg-gradient-to-r from-brand-500 to-brand-600 text-white px-5 py-1.5 rounded-full font-semibold text-sm shadow-lg border-2 border-white dark:border-gray-800 flex items-center gap-1.5">
                        <ShootingStarIcon className="w-4 h-4" />
                        <span>Más Popular</span>
                      </div>
                    </div>
                  </div>
                )}

                <div className={`mb-6 ${plan.popular ? "mt-2" : ""}`}>
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                    {plan.name}
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {plan.description}
                  </p>
                </div>

                <div className="mb-6">
                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl font-bold text-gray-900 dark:text-white">
                      €{price}
                    </span>
                    <span className="text-gray-500 dark:text-gray-400">
                      /{billingCycle === "monthly" ? "mes" : "año"}
                    </span>
                  </div>
                  {discount && (
                    <p className="text-sm text-success-600 dark:text-success-400 mt-1">
                      Ahorras €{discount.savings} ({discount.percentage}% de descuento)
                    </p>
                  )}
                  {billingCycle === "yearly" && (
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                      Equivale a €{Math.round(price / 12)}/mes
                    </p>
                  )}
                </div>

                <Button
                  onClick={() => handleSelectPlan(plan.name)}
                  variant={plan.popular ? "primary" : "outline"}
                  className="w-full mb-6"
                  size="md"
                  endIcon={<ArrowRightIcon className="w-4 h-4" />}
                >
                  {plan.name === "Básico" ? "Comenzar" : "Elegir Plan"}
                </Button>

                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-semibold text-gray-900 dark:text-white mb-3">
                      Incluye:
                    </h4>
                    <ul className="space-y-2">
                      {plan.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-start gap-2">
                          <CheckCircleIcon className="w-5 h-5 text-success-500 dark:text-success-400 flex-shrink-0 mt-0.5" />
                          <span className="text-sm text-gray-700 dark:text-gray-300">
                            {feature}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {plan.limitations.length > 0 && (
                    <div>
                      <h4 className="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-3">
                        No incluye:
                      </h4>
                      <ul className="space-y-2">
                        {plan.limitations.map((limitation, limitationIndex) => (
                          <li key={limitationIndex} className="flex items-start gap-2">
                            <span className="w-5 h-5 flex items-center justify-center text-gray-400">
                              ×
                            </span>
                            <span className="text-sm text-gray-500 dark:text-gray-400">
                              {limitation}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* FAQ Section */}
        <div className="mt-12 max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 text-center">
            Preguntas Frecuentes
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-6 bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
              <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                ¿Puedo cambiar de plan más tarde?
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Sí, puedes actualizar o degradar tu plan en cualquier momento. Los cambios se aplicarán en el próximo ciclo de facturación.
              </p>
            </div>
            <div className="p-6 bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
              <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                ¿Hay período de prueba?
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Sí, ofrecemos 14 días de prueba gratuita en todos los planes. No se requiere tarjeta de crédito.
              </p>
            </div>
            <div className="p-6 bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
              <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                ¿Qué métodos de pago aceptan?
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Aceptamos todas las tarjetas de crédito principales, transferencia bancaria y PayPal.
              </p>
            </div>
            <div className="p-6 bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
              <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                ¿Ofrecen descuentos anuales?
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Sí, al pagar anualmente ahorras hasta un 17% comparado con el plan mensual.
              </p>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-12 text-center p-8 bg-gradient-to-r from-brand-50 to-brand-100 dark:from-brand-900/20 dark:to-brand-800/20 rounded-2xl border border-brand-200 dark:border-brand-700">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            ¿Necesitas un plan personalizado?
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            Contáctanos y crearemos un plan a medida para tu concesionario o grupo
          </p>
          <Button
            onClick={() => navigate("/signup")}
            variant="outline"
            size="md"
          >
            Contactar Ventas
          </Button>
        </div>
      </div>
    </>
  );
}

