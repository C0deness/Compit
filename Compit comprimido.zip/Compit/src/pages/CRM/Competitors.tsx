import { useEffect, useState } from "react";
import PageMeta from "../../components/common/PageMeta";
import { competitorsAPI } from "../../services/api";
import Badge from "../../components/ui/badge/Badge";

export default function Competitors() {
  const [competitors, setCompetitors] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingCompetitor, setEditingCompetitor] = useState<any>(null);
  const [formData, setFormData] = useState({
    name: '',
    website: '',
    type: 'concesionario',
    region: '',
    brands_monitored: [] as string[],
  });

  useEffect(() => {
    fetchCompetitors();
  }, []);

  const fetchCompetitors = async () => {
    try {
      const response = await competitorsAPI.getAll();
      setCompetitors(response.competitors || []);
    } catch (error) {
      console.error("Error cargando competidores:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingCompetitor) {
        await competitorsAPI.update(editingCompetitor._id, formData);
      } else {
        await competitorsAPI.create(formData);
      }
      setShowModal(false);
      setEditingCompetitor(null);
      setFormData({
        name: '',
        website: '',
        type: 'concesionario',
        region: '',
        brands_monitored: [],
      });
      fetchCompetitors();
    } catch (error) {
      console.error("Error guardando competidor:", error);
    }
  };

  const handleEdit = (competitor: any) => {
    setEditingCompetitor(competitor);
    setFormData({
      name: competitor.name,
      website: competitor.website || '',
      type: competitor.type,
      region: competitor.region || '',
      brands_monitored: competitor.brands_monitored || [],
    });
    setShowModal(true);
  };

  const handleDelete = async (id: string) => {
    if (confirm('¿Estás seguro de eliminar este competidor?')) {
      try {
        await competitorsAPI.delete(id);
        fetchCompetitors();
      } catch (error) {
        console.error("Error eliminando competidor:", error);
      }
    }
  };

  return (
    <>
      <PageMeta
        title="Competencia - AutoMarket Intelligence"
        description="Gestión de competidores monitoreados"
      />
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
              Competencia
            </h1>
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              Gestiona los competidores que monitoreas
            </p>
          </div>
          <button
            onClick={() => {
              setEditingCompetitor(null);
              setFormData({
                name: '',
                website: '',
                type: 'concesionario',
                region: '',
                brands_monitored: [],
              });
              setShowModal(true);
            }}
            className="px-4 py-2 bg-brand-500 text-white rounded-lg hover:bg-brand-600 transition-colors"
          >
            + Agregar Competidor
          </button>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-gray-500 dark:text-gray-400">Cargando competidores...</div>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
            {competitors.length === 0 ? (
              <div className="col-span-full text-center py-12">
                <p className="text-gray-500 dark:text-gray-400">
                  No hay competidores registrados
                </p>
              </div>
            ) : (
              competitors.map((competitor) => (
                <div
                  key={competitor._id}
                  className="p-6 border border-gray-200 rounded-lg dark:border-gray-700 bg-white dark:bg-white/[0.03] hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-semibold text-gray-800 dark:text-white mb-1">
                        {competitor.name}
                      </h3>
                      <Badge color="info" size="sm" className="mb-2">
                        {competitor.type}
                      </Badge>
                    </div>
                    <Badge
                      color={competitor.is_active ? 'success' : 'error'}
                      size="sm"
                    >
                      {competitor.is_active ? 'Activo' : 'Inactivo'}
                    </Badge>
                  </div>
                  {competitor.website && (
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                      <a
                        href={competitor.website}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-brand-500 hover:underline"
                      >
                        {competitor.website}
                      </a>
                    </p>
                  )}
                  {competitor.region && (
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                      Región: {competitor.region}
                    </p>
                  )}
                  {competitor.brands_monitored && competitor.brands_monitored.length > 0 && (
                    <div className="mb-3">
                      <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">
                        Marcas monitoreadas:
                      </p>
                      <div className="flex flex-wrap gap-1">
                        {competitor.brands_monitored.map((brand: string, idx: number) => (
                          <span
                            key={idx}
                            className="px-2 py-1 text-xs bg-gray-100 dark:bg-gray-700 rounded"
                          >
                            {brand}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                  <div className="flex gap-2 mt-4">
                    <button
                      onClick={() => handleEdit(competitor)}
                      className="flex-1 px-3 py-2 text-sm bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
                    >
                      Editar
                    </button>
                    <button
                      onClick={() => handleDelete(competitor._id)}
                      className="px-3 py-2 text-sm bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
                    >
                      Eliminar
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Modal */}
        {showModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md">
              <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-4">
                {editingCompetitor ? 'Editar Competidor' : 'Nuevo Competidor'}
              </h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Nombre
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg dark:border-gray-700 dark:bg-gray-700 dark:text-white"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Sitio Web
                  </label>
                  <input
                    type="url"
                    value={formData.website}
                    onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg dark:border-gray-700 dark:bg-gray-700 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Tipo
                  </label>
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg dark:border-gray-700 dark:bg-gray-700 dark:text-white"
                  >
                    <option value="concesionario">Concesionario</option>
                    <option value="portal_vo">Portal VO</option>
                    <option value="marketplace">Marketplace</option>
                    <option value="otro">Otro</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Región
                  </label>
                  <input
                    type="text"
                    value={formData.region}
                    onChange={(e) => setFormData({ ...formData, region: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg dark:border-gray-700 dark:bg-gray-700 dark:text-white"
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    type="submit"
                    className="flex-1 px-4 py-2 bg-brand-500 text-white rounded-lg hover:bg-brand-600 transition-colors"
                  >
                    {editingCompetitor ? 'Actualizar' : 'Crear'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowModal(false);
                      setEditingCompetitor(null);
                    }}
                    className="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
                  >
                    Cancelar
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
