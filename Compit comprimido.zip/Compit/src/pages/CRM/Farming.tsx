import { useState } from "react";
import PageMeta from "../../components/common/PageMeta";
import { farmingAPI } from "../../services/api";
import Button from "../../components/ui/button/Button";
import Badge from "../../components/ui/badge/Badge";
import Alert from "../../components/ui/alert/Alert";
import { ShootingStarIcon, BoltIcon, MailIcon, ChatIcon, CopyIcon } from "../../icons";

export default function Farming() {
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<any>(null);
  const [kit, setKit] = useState<any>(null);

  const handleAnalyze = async () => {
    setLoading(true);
    try {
      // Simular coordenadas (en producción usar geolocalización o selección en mapa)
      const result = await farmingAPI.analyzeZone(40.7128, -74.006, 5);
      setAnalysis(result);
      setKit(null); // Reset kit when new analysis
    } catch (error) {
      console.error("Error analizando zona:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateKit = async () => {
    if (!analysis) return;
    setLoading(true);
    try {
      const result = await farmingAPI.generateKit("Zona Analizada", analysis);
      setKit(result);
    } catch (error) {
      console.error("Error generando kit:", error);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    // You could add a toast notification here
  };

  return (
    <>
      <PageMeta title="Farming Predictivo - RockIt" />
      <div className="space-y-6">
        {/* Header */}
        <div>
          <div className="flex items-center gap-2 mb-2">
            <ShootingStarIcon className="w-6 h-6 text-brand-500 dark:text-brand-400" />
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
              Farming Predictivo Hiperlocal
            </h1>
          </div>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Identifica zonas con alto potencial de venta usando inteligencia artificial
          </p>
        </div>

        {/* AI Feature Alert */}
        <Alert
          variant="info"
          title="Análisis Predictivo con IA"
          message="Nuestra IA analiza datos demográficos, tendencias del mercado, crecimiento poblacional y actividad inmobiliaria para identificar zonas con mayor potencial de farming. Los resultados incluyen scores de potencial y recomendaciones personalizadas."
        />

        {/* Main Analysis Card */}
        <div className="p-6 bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-semibold text-gray-800 dark:text-white">
                Análisis de Zona
              </h2>
              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                Selecciona una zona geográfica para analizar su potencial
              </p>
            </div>
            <Badge color="info" variant="light" size="md" startIcon={<BoltIcon className="w-4 h-4" />}>
              Potenciado por IA
            </Badge>
          </div>

          <div className="mb-6 p-4 bg-gray-50 rounded-lg dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              <strong>Nota:</strong> Esta funcionalidad analiza zonas geográficas para identificar oportunidades de farming inmobiliario. En producción, se integraría con un mapa interactivo (Mapbox o Google Maps) para seleccionar áreas específicas.
            </p>
          </div>

          <Button onClick={handleAnalyze} disabled={loading} size="sm" startIcon={<ShootingStarIcon className="w-4 h-4" />}>
            {loading ? "Analizando con IA..." : "Iniciar Análisis Predictivo"}
          </Button>

          {/* Analysis Results */}
          {analysis && (
            <div className="mt-6 space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <BoltIcon className="w-5 h-5 text-brand-500 dark:text-brand-400" />
                <h3 className="text-lg font-semibold text-gray-800 dark:text-white">
                  Resultados del Análisis IA
                </h3>
              </div>

              <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
                <div className="p-4 bg-gradient-to-br from-brand-50 to-brand-100 dark:from-brand-900/20 dark:to-brand-800/20 rounded-lg border border-brand-200 dark:border-brand-800">
                  <div className="flex items-center gap-2 mb-2">
                    <ShootingStarIcon className="w-5 h-5 text-brand-500 dark:text-brand-400" />
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      Score de Potencial
                    </span>
                  </div>
                  <p className="text-2xl font-bold text-brand-600 dark:text-brand-400">
                    {analysis.potentialScore?.toFixed(1) || "0"}%
                  </p>
                </div>

                <div className="p-4 bg-gradient-to-br from-success-50 to-success-100 dark:from-success-900/20 dark:to-success-800/20 rounded-lg border border-success-200 dark:border-success-800">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      Crecimiento Poblacional
                    </span>
                  </div>
                  <p className="text-2xl font-bold text-success-600 dark:text-success-400">
                    {analysis.demographics?.populationGrowth || "0"}%
                  </p>
                </div>

                <div className="p-4 bg-gradient-to-br from-warning-50 to-warning-100 dark:from-warning-900/20 dark:to-warning-800/20 rounded-lg border border-warning-200 dark:border-warning-800">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      Actividad de Mercado
                    </span>
                  </div>
                  <p className="text-2xl font-bold text-warning-600 dark:text-warning-400">
                    {analysis.marketActivity || "Media"}
                  </p>
                </div>

                <div className="p-4 bg-gradient-to-br from-info-50 to-info-100 dark:from-info-900/20 dark:to-info-800/20 rounded-lg border border-info-200 dark:border-info-800">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      Tendencias
                    </span>
                  </div>
                  <p className="text-2xl font-bold text-info-600 dark:text-info-400">
                    {analysis.trends || "Positivas"}
                  </p>
                </div>
              </div>

              <div className="mt-6">
                <Button
                  onClick={handleGenerateKit}
                  disabled={loading}
                  size="sm"
                  startIcon={<BoltIcon className="w-4 h-4" />}
                >
                  {loading ? "Generando con IA..." : "Generar Kit de Marketing Digital con IA"}
                </Button>
              </div>
            </div>
          )}

          {/* Marketing Kit */}
          {kit && (
            <div className="mt-6 space-y-6">
              <div className="flex items-center gap-2 mb-4">
                <BoltIcon className="w-5 h-5 text-brand-500 dark:text-brand-400" />
                <h3 className="text-lg font-semibold text-gray-800 dark:text-white">
                  Kit de Marketing Generado por IA
                </h3>
                <Badge color="success" variant="light" size="sm">
                  Generado
                </Badge>
              </div>

              {/* Facebook/Instagram Ads */}
              <div className="p-4 bg-white rounded-lg border border-gray-200 dark:bg-gray-800 dark:border-gray-700">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <ChatIcon className="w-5 h-5 text-brand-500 dark:text-brand-400" />
                    <h4 className="font-medium text-gray-800 dark:text-white">
                      Anuncios Facebook/Instagram
                    </h4>
                  </div>
                  <Badge color="info" variant="light" size="sm">
                    {kit.facebookAds?.length || 0} anuncios
                  </Badge>
                </div>
                <div className="space-y-3">
                  {kit.facebookAds?.map((ad: string, i: number) => (
                    <div
                      key={i}
                      className="p-3 bg-gray-50 rounded-lg dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <p className="flex-1 text-sm text-gray-700 dark:text-gray-300">{ad}</p>
                        <button
                          onClick={() => copyToClipboard(ad)}
                          className="p-1.5 text-gray-500 transition-colors rounded hover:bg-gray-200 dark:hover:bg-gray-700"
                          title="Copiar"
                        >
                          <CopyIcon className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Email Marketing */}
              <div className="p-4 bg-white rounded-lg border border-gray-200 dark:bg-gray-800 dark:border-gray-700">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <MailIcon className="w-5 h-5 text-brand-500 dark:text-brand-400" />
                    <h4 className="font-medium text-gray-800 dark:text-white">
                      Emails de Marketing
                    </h4>
                  </div>
                  <Badge color="info" variant="light" size="sm">
                    {kit.emailMarketing?.length || 0} emails
                  </Badge>
                </div>
                <div className="space-y-3">
                  {kit.emailMarketing?.map((email: string, i: number) => (
                    <div
                      key={i}
                      className="p-3 bg-gray-50 rounded-lg dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <p className="flex-1 text-sm text-gray-700 dark:text-gray-300 whitespace-pre-line">
                          {email}
                        </p>
                        <button
                          onClick={() => copyToClipboard(email)}
                          className="p-1.5 text-gray-500 transition-colors rounded hover:bg-gray-200 dark:hover:bg-gray-700"
                          title="Copiar"
                        >
                          <CopyIcon className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Cold Call Script */}
              <div className="p-4 bg-white rounded-lg border border-gray-200 dark:bg-gray-800 dark:border-gray-700">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <ChatIcon className="w-5 h-5 text-brand-500 dark:text-brand-400" />
                    <h4 className="font-medium text-gray-800 dark:text-white">
                      Guion para Llamada en Frío
                    </h4>
                  </div>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700">
                  <div className="flex items-start justify-between gap-3">
                    <p className="flex-1 text-sm text-gray-700 dark:text-gray-300 whitespace-pre-line">
                      {kit.coldCallScript}
                    </p>
                    <button
                      onClick={() => copyToClipboard(kit.coldCallScript)}
                      className="p-1.5 text-gray-500 transition-colors rounded hover:bg-gray-200 dark:hover:bg-gray-700"
                      title="Copiar"
                    >
                      <CopyIcon className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
