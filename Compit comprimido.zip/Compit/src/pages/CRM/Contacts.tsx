import { useEffect, useState } from "react";
import { Link } from "react-router";
import PageMeta from "../../components/common/PageMeta";
import { contactsAPI } from "../../services/api";
import Button from "../../components/ui/button/Button";
import Badge from "../../components/ui/badge/Badge";
import Alert from "../../components/ui/alert/Alert";
import { Table, TableHeader, TableBody, TableRow, TableCell } from "../../components/ui/table";
import InputField from "../../components/form/input/InputField";
import { PlusIcon, PencilIcon, TrashBinIcon, BoltIcon, UserIcon, ShootingStarIcon } from "../../icons";
import { useModal } from "../../hooks/useModal";
import { Modal } from "../../components/ui/modal";

export default function Contacts() {
  const [contacts, setContacts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState({ status: "", search: "" });
  const { isOpen, openModal, closeModal } = useModal();
  const [editingContact, setEditingContact] = useState<any>(null);

  useEffect(() => {
    loadContacts();
  }, [filter]);

  const loadContacts = async () => {
    setLoading(true);
    try {
      const data = await contactsAPI.getAll(filter);
      setContacts(data);
    } catch (error) {
      console.error("Error cargando clientes:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string | number) => {
    if (confirm("¿Estás seguro de eliminar este cliente?")) {
      try {
        await contactsAPI.delete(id);
        loadContacts();
      } catch (error) {
        console.error("Error eliminando cliente:", error);
        alert("Error al eliminar el cliente. Por favor, intenta nuevamente.");
      }
    }
  };

  const getStatusBadge = (status: string) => {
    const badgeMap: Record<string, { color: "error" | "warning" | "info"; label: string }> = {
      caliente: { color: "error", label: "Caliente" },
      tibio: { color: "warning", label: "Tibio" },
      frio: { color: "info", label: "Frío" },
    };
    const config = badgeMap[status] || badgeMap.frio;
    return <Badge color={config.color} variant="light" size="sm">{config.label}</Badge>;
  };

  const getLeadScoreBadge = (score: number) => {
    if (score >= 80) return <Badge color="success" variant="light" size="sm" startIcon={<ShootingStarIcon className="w-3 h-3" />}>Alto</Badge>;
    if (score >= 50) return <Badge color="warning" variant="light" size="sm">Medio</Badge>;
    return <Badge color="info" variant="light" size="sm">Bajo</Badge>;
  };

  return (
    <>
      <PageMeta title="Clientes - RockIt" />
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
              Gestión de Clientes
            </h1>
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              Administra tus leads y clientes con inteligencia artificial
            </p>
          </div>
          <Button onClick={openModal} size="sm" startIcon={<PlusIcon className="w-4 h-4" />}>
            Nuevo Cliente
          </Button>
        </div>

        {/* AI Feature Alert */}
        <Alert
          variant="info"
          title="Lead Scoring Automático con IA"
          message="Cada cliente recibe una puntuación automática basada en su comportamiento, interacciones y datos. Los leads con puntuación alta tienen mayor probabilidad de conversión."
        />

        {/* Filters */}
        <div className="flex flex-col gap-4 sm:flex-row">
          <div className="flex-1">
            <InputField
              type="text"
              placeholder="Buscar por nombre, email o teléfono..."
              value={filter.search}
              onChange={(e) => setFilter({ ...filter, search: e.target.value })}
            />
          </div>
          <div className="sm:w-48">
            <select
              value={filter.status}
              onChange={(e) => setFilter({ ...filter, status: e.target.value })}
              className="h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-3 focus:border-brand-300 focus:ring-brand-500/20 dark:bg-gray-900 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800"
            >
              <option value="">Todos los estados</option>
              <option value="caliente">Caliente</option>
              <option value="tibio">Tibio</option>
              <option value="frio">Frío</option>
            </select>
          </div>
        </div>

        {/* Table */}
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-gray-500 dark:text-gray-400">Cargando clientes...</div>
          </div>
        ) : (
          <div className="overflow-hidden bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50 dark:bg-gray-900">
                    <TableCell isHeader className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-400">
                      Cliente
                    </TableCell>
                    <TableCell isHeader className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-400">
                      Información
                    </TableCell>
                    <TableCell isHeader className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-400">
                      Estado
                    </TableCell>
                    <TableCell isHeader className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-400">
                      ASNEF
                    </TableCell>
                    <TableCell isHeader className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-400">
                      <div className="flex items-center gap-2">
                        <BoltIcon className="w-4 h-4" />
                        <span>Lead Score IA</span>
                      </div>
                    </TableCell>
                    <TableCell isHeader className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-400">
                      Acciones
                    </TableCell>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {contacts.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="px-6 py-12 text-center">
                        <div className="flex flex-col items-center gap-2">
                          <UserIcon className="w-12 h-12 text-gray-400" />
                          <p className="text-gray-500 dark:text-gray-400">No hay clientes registrados</p>
                          <Button onClick={openModal} size="sm" variant="outline" className="mt-2">
                            <PlusIcon className="w-4 h-4" />
                            Crear primer cliente
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ) : (
                    contacts.map((contact) => (
                      <TableRow key={contact._id || contact.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                        <TableCell className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="flex items-center justify-center w-10 h-10 rounded-full bg-brand-100 text-brand-600 dark:bg-brand-500/20 dark:text-brand-400">
                              <UserIcon className="w-5 h-5" />
                            </div>
                            <div>
                              <div className="font-medium text-gray-900 dark:text-white">
                                {contact.first_name} {contact.last_name}
                              </div>
                              {contact.source && (
                                <div className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                                  Fuente: {contact.source}
                                </div>
                              )}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="px-6 py-4">
                          <div className="space-y-1 text-sm">
                            {contact.email && (
                              <div className="text-gray-600 dark:text-gray-400">{contact.email}</div>
                            )}
                            {contact.phone && (
                              <div className="text-gray-600 dark:text-gray-400">{contact.phone}</div>
                            )}
                            {!contact.email && !contact.phone && (
                              <span className="text-gray-400 italic">Sin información</span>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="px-6 py-4">
                          {getStatusBadge(contact.status)}
                        </TableCell>
                        <TableCell className="px-6 py-4">
                          {contact.asnef_check && contact.asnef_check.checked_at ? (
                            <div className="flex flex-col gap-1">
                              {contact.asnef_check.has_debt ? (
                                <Badge 
                                  color={contact.asnef_check.risk_level === 'very_high' ? 'error' : 
                                         contact.asnef_check.risk_level === 'high' ? 'error' : 'warning'} 
                                  variant="light" 
                                  size="sm"
                                >
                                  {contact.asnef_check.risk_level === 'very_high' ? '⚠️ Muy Alto' :
                                   contact.asnef_check.risk_level === 'high' ? '⚠️ Alto' :
                                   contact.asnef_check.risk_level === 'medium' ? '⚠️ Medio' : '⚠️ Deuda'}
                                </Badge>
                              ) : (
                                <Badge color="success" variant="light" size="sm">
                                  ✓ Sin deudas
                                </Badge>
                              )}
                              {contact.asnef_check.total_debt && contact.asnef_check.total_debt > 0 && (
                                <span className="text-xs text-gray-500 dark:text-gray-400">
                                  €{Number(contact.asnef_check.total_debt).toLocaleString()}
                                </span>
                              )}
                            </div>
                          ) : (
                            <span className="text-xs text-gray-400 italic">No consultado</span>
                          )}
                        </TableCell>
                        <TableCell className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="flex-1 min-w-[100px] bg-gray-200 rounded-full h-2.5 dark:bg-gray-700 overflow-hidden">
                              {(() => {
                                const score = Number(contact.lead_score) || 0;
                                const percentage = Math.min(Math.max(score, 0), 100);
                                const barColor = score >= 80 ? "bg-success-500" : score >= 50 ? "bg-warning-500" : "bg-blue-light-500";
                                if (percentage === 0) return null;
                                const widthPercent = Math.max(percentage, 2); // Mínimo 2% para que sea visible
                                return (
                                  <div
                                    className={`h-2.5 rounded-full transition-all ${barColor}`}
                                    style={{ 
                                      width: `${widthPercent}%`,
                                      display: 'block'
                                    }}
                                  ></div>
                                );
                              })()}
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-medium text-gray-700 dark:text-gray-300 min-w-[2.5rem] text-right">
                                {Number(contact.lead_score) || 0}
                              </span>
                              {getLeadScoreBadge(Number(contact.lead_score) || 0)}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="px-6 py-4">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => {
                                setEditingContact({ ...contact, id: contact._id || contact.id });
                                openModal();
                              }}
                              className="p-2 text-gray-600 transition-colors rounded-lg hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700"
                              title="Editar"
                            >
                              <PencilIcon className="w-5 h-5" />
                            </button>
                            <button
                              onClick={() => handleDelete(contact._id || contact.id)}
                              className="p-2 text-error-500 transition-colors rounded-lg hover:bg-error-50 dark:hover:bg-error-500/20"
                              title="Eliminar"
                            >
                              <TrashBinIcon className="w-5 h-5" />
                            </button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
        )}
      </div>

      <ContactModal
        isOpen={isOpen}
        onClose={() => {
          closeModal();
          setEditingContact(null);
        }}
        onSave={() => {
          loadContacts();
          closeModal();
          setEditingContact(null);
        }}
        contact={editingContact}
      />
    </>
  );
}

function ContactModal({
  isOpen,
  onClose,
  onSave,
  contact,
}: {
  isOpen: boolean;
  onClose: () => void;
  onSave: () => void;
  contact?: any;
}) {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    status: "frio",
    source: "",
    notes: "",
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (contact) {
      setFormData({
        firstName: contact.first_name || "",
        lastName: contact.last_name || "",
        email: contact.email || "",
        phone: contact.phone || "",
        status: contact.status || "frio",
        source: contact.source || "",
        notes: contact.notes || "",
      });
    } else {
      setFormData({
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        status: "frio",
        source: "",
        notes: "",
      });
    }
  }, [contact, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (contact) {
        const contactId = contact._id || contact.id;
        await contactsAPI.update(contactId, formData);
      } else {
        await contactsAPI.create(formData);
      }
      onSave();
    } catch (error) {
      console.error("Error guardando cliente:", error);
      alert("Error al guardar cliente");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <div className="p-6 sm:p-8">
        <h2 className="mb-6 text-2xl font-semibold text-gray-800 dark:text-white">
          {contact ? "Editar Cliente" : "Nuevo Cliente"}
        </h2>
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <div>
              <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                Nombre *
              </label>
              <InputField
                type="text"
                required
                value={formData.firstName}
                onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
              />
            </div>
            <div>
              <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                Apellido
              </label>
              <InputField
                type="text"
                value={formData.lastName}
                onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
              />
            </div>
          </div>
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <div>
              <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                Email
              </label>
              <InputField
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>
            <div>
              <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                Teléfono
              </label>
              <InputField
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              />
            </div>
          </div>
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <div>
              <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                Estado
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                className="h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-3 focus:border-brand-300 focus:ring-brand-500/20 dark:bg-gray-900 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800"
              >
                <option value="frio">Frío</option>
                <option value="tibio">Tibio</option>
                <option value="caliente">Caliente</option>
              </select>
            </div>
            <div>
              <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                Fuente
              </label>
              <InputField
                type="text"
                value={formData.source}
                onChange={(e) => setFormData({ ...formData, source: e.target.value })}
                placeholder="Web, Referido, etc."
              />
            </div>
          </div>
          <div>
            <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              Notas
            </label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={4}
              className="h-auto w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-3 focus:border-brand-300 focus:ring-brand-500/20 dark:bg-gray-900 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800"
            />
          </div>
          <div className="flex justify-end gap-3 pt-6 border-t border-gray-200 dark:border-gray-700">
            <Button type="button" onClick={onClose} variant="outline" size="md">
              Cancelar
            </Button>
            <Button type="submit" size="md" disabled={loading}>
              {loading ? "Guardando..." : "Guardar"}
            </Button>
          </div>
        </form>
      </div>
    </Modal>
  );
}
