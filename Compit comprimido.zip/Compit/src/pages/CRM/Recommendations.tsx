import { useEffect, useState } from "react";
import PageMeta from "../../components/common/PageMeta";
import { recommendationsAPI } from "../../services/api";
import Badge from "../../components/ui/badge/Badge";
import { ArrowUpIcon } from "../../icons";
import { Modal } from "../../components/ui/modal";
import { useModal } from "../../hooks/useModal";

export default function Recommendations() {
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedRecommendation, setSelectedRecommendation] = useState<any | null>(null);
  const { isOpen, openModal, closeModal } = useModal();
  const [filters, setFilters] = useState({
    type: '',
    status: '',
  });

  useEffect(() => {
    fetchRecommendations();
  }, [filters]);

  const fetchRecommendations = async () => {
    try {
      const params: any = { limit: 50 };
      if (filters.type) params.type = filters.type;
      if (filters.status) params.status = filters.status;
      
      const response = await recommendationsAPI.getAll(params);
      setRecommendations(response.recommendations || []);
    } catch (error) {
      console.error("Error cargando recomendaciones:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (id: string, status: string, event?: React.MouseEvent) => {
    event?.stopPropagation();
    try {
      await recommendationsAPI.updateStatus(id, status);
      fetchRecommendations();
      if (selectedRecommendation?._id === id) {
        setSelectedRecommendation({ ...selectedRecommendation, status });
      }
    } catch (error) {
      console.error("Error actualizando recomendación:", error);
    }
  };

  const handleRecommendationClick = (rec: any) => {
    setSelectedRecommendation(rec);
    openModal();
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high':
        return 'success';
      case 'medium':
        return 'warning';
      default:
        return 'info';
    }
  };

  return (
    <>
      <PageMeta
        title="Recomendaciones - AutoMarket Intelligence"
        description="Recomendaciones de acción comercial basadas en análisis de datos"
      />
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
            Recomendaciones de Acción
          </h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Acciones sugeridas basadas en análisis de datos e IA
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4">
          <select
            value={filters.type}
            onChange={(e) => setFilters({ ...filters, type: e.target.value })}
            className="px-4 py-2 border border-gray-300 rounded-lg dark:border-gray-700 dark:bg-gray-800 dark:text-white"
          >
            <option value="">Todos los tipos</option>
            <option value="rotacion_stock">Rotación de Stock</option>
            <option value="pricing_vo">Pricing de VO</option>
            <option value="estrategia_financiacion">Estrategia de Financiación</option>
            <option value="competencia">Competencia</option>
            <option value="marketing">Marketing</option>
          </select>
          <select
            value={filters.status}
            onChange={(e) => setFilters({ ...filters, status: e.target.value })}
            className="px-4 py-2 border border-gray-300 rounded-lg dark:border-gray-700 dark:bg-gray-800 dark:text-white"
          >
            <option value="">Todos los estados</option>
            <option value="pending">Pendiente</option>
            <option value="in_progress">En Progreso</option>
            <option value="completed">Completada</option>
            <option value="dismissed">Descartada</option>
          </select>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-gray-500 dark:text-gray-400">Cargando recomendaciones...</div>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            {recommendations.length === 0 ? (
              <div className="col-span-2 text-center py-12">
                <p className="text-gray-500 dark:text-gray-400">
                  No hay recomendaciones disponibles
                </p>
              </div>
            ) : (
              recommendations.map((rec) => (
                <div
                  key={rec._id}
                  onClick={() => handleRecommendationClick(rec)}
                  className="p-6 border border-gray-200 rounded-lg dark:border-gray-700 bg-white dark:bg-white/[0.03] hover:shadow-lg transition-shadow cursor-pointer"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold text-gray-800 dark:text-white">
                          {rec.title}
                        </h3>
                        <Badge color={getImpactColor(rec.expected_impact)} size="sm">
                          {rec.expected_impact}
                        </Badge>
                        <Badge color="info" size="sm">
                          {rec.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                        {rec.description}
                      </p>
                      {rec.action_items && rec.action_items.length > 0 && (
                        <div className="mb-4">
                          <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Acciones sugeridas:
                          </h4>
                          <ul className="space-y-2">
                            {rec.action_items.map((item: any, idx: number) => (
                              <li key={idx} className="text-sm text-gray-600 dark:text-gray-400">
                                <span className="font-medium">{idx + 1}.</span> {item.title}
                                {item.description && (
                                  <span className="block ml-5 text-xs text-gray-500">
                                    {item.description}
                                  </span>
                                )}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      Confianza: {rec.confidence_score}%
                    </div>
                    <div className="flex gap-2">
                      {rec.status === 'pending' && (
                        <>
                          <button
                            onClick={(e) => handleUpdateStatus(rec._id, 'in_progress', e)}
                            className="px-4 py-2 text-sm bg-brand-500 text-white rounded-lg hover:bg-brand-600 transition-colors flex items-center gap-2"
                          >
                            Actúa ahora
                            <ArrowUpIcon className="w-4 h-4 rotate-45" />
                          </button>
                          <button
                            onClick={(e) => handleUpdateStatus(rec._id, 'dismissed', e)}
                            className="px-4 py-2 text-sm bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
                          >
                            Descartar
                          </button>
                        </>
                      )}
                      {rec.status === 'in_progress' && (
                        <button
                          onClick={(e) => handleUpdateStatus(rec._id, 'completed', e)}
                          className="px-4 py-2 text-sm bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                        >
                          Marcar como completada
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>

      {/* Modal de Recomendación Detallada */}
      <Modal isOpen={isOpen} onClose={closeModal} className="max-w-4xl">
        {selectedRecommendation && (
          <div className="p-6">
            <div className="mb-6">
              <div className="flex items-center gap-3 mb-4">
                <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
                  {selectedRecommendation.title}
                </h2>
                <Badge color={getImpactColor(selectedRecommendation.expected_impact)} size="sm">
                  {selectedRecommendation.expected_impact}
                </Badge>
                <Badge color="info" size="sm">
                  {selectedRecommendation.status}
                </Badge>
              </div>

              <div className="flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400 mb-4">
                <span><strong>Tipo:</strong> {selectedRecommendation.type}</span>
                <span><strong>Confianza:</strong> {selectedRecommendation.confidence_score}%</span>
                <span><strong>Creada:</strong> {new Date(selectedRecommendation.created_at).toLocaleString('es-ES')}</span>
              </div>
            </div>

            <div className="mb-6">
              <h3 className="font-semibold text-gray-800 dark:text-white mb-3">Descripción</h3>
              <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
                  {selectedRecommendation.description}
                </p>
              </div>
            </div>

            {selectedRecommendation.action_items && selectedRecommendation.action_items.length > 0 && (
              <div className="mb-6">
                <h3 className="font-semibold text-gray-800 dark:text-white mb-3">Acciones Sugeridas</h3>
                <div className="space-y-3">
                  {selectedRecommendation.action_items.map((item: any, idx: number) => (
                    <div
                      key={idx}
                      className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg bg-white dark:bg-white/[0.03]"
                    >
                      <div className="flex items-start gap-3">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-brand-100 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 font-semibold">
                          {idx + 1}
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-800 dark:text-white mb-1">
                            {item.title}
                          </h4>
                          {item.description && (
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              {item.description}
                            </p>
                          )}
                          {item.priority && (
                            <Badge
                              color={item.priority === 'high' ? 'error' : item.priority === 'medium' ? 'warning' : 'info'}
                              size="sm"
                              className="mt-2"
                            >
                              Prioridad: {item.priority}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {selectedRecommendation.action_details && (
              <div className="mb-6">
                <h3 className="font-semibold text-gray-800 dark:text-white mb-3">Detalles de Acción</h3>
                <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  {selectedRecommendation.action_details.target_vehicles && (
                    <div className="mb-3">
                      <strong className="text-gray-700 dark:text-gray-300">Vehículos objetivo:</strong>
                      <div className="flex flex-wrap gap-2 mt-1">
                        {selectedRecommendation.action_details.target_vehicles.map((vehicle: string, idx: number) => (
                          <Badge key={idx} color="info" size="sm">{vehicle}</Badge>
                        ))}
                      </div>
                    </div>
                  )}
                  {selectedRecommendation.action_details.suggested_price && (
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                      <strong>Precio sugerido:</strong> €{selectedRecommendation.action_details.suggested_price.toLocaleString()}
                    </p>
                  )}
                  {selectedRecommendation.action_details.financing_offer && (
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                      <strong>Oferta de financiación:</strong> {selectedRecommendation.action_details.financing_offer}
                    </p>
                  )}
                  {selectedRecommendation.action_details.marketing_channel && (
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      <strong>Canal de marketing:</strong> {selectedRecommendation.action_details.marketing_channel}
                    </p>
                  )}
                </div>
              </div>
            )}

            {selectedRecommendation.results && (
              <div className="mb-6">
                <h3 className="font-semibold text-gray-800 dark:text-white mb-3">Resultados</h3>
                <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <p className="text-sm text-gray-700 dark:text-gray-300">
                    {selectedRecommendation.results}
                  </p>
                </div>
              </div>
            )}

            <div className="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-700">
              <div className="text-xs text-gray-500 dark:text-gray-400">
                Última actualización: {new Date(selectedRecommendation.updated_at || selectedRecommendation.created_at).toLocaleString('es-ES')}
              </div>
              <div className="flex gap-2">
                {selectedRecommendation.status === 'pending' && (
                  <>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleUpdateStatus(selectedRecommendation._id, 'in_progress', e);
                      }}
                      className="px-4 py-2 text-sm bg-brand-500 text-white rounded-lg hover:bg-brand-600 transition-colors flex items-center gap-2"
                    >
                      Actúa ahora
                      <ArrowUpIcon className="w-4 h-4 rotate-45" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleUpdateStatus(selectedRecommendation._id, 'dismissed', e);
                      }}
                      className="px-4 py-2 text-sm bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
                    >
                      Descartar
                    </button>
                  </>
                )}
                {selectedRecommendation.status === 'in_progress' && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleUpdateStatus(selectedRecommendation._id, 'completed', e);
                    }}
                    className="px-4 py-2 text-sm bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                  >
                    Marcar como completada
                  </button>
                )}
                <button
                  onClick={closeModal}
                  className="px-4 py-2 text-sm bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
                >
                  Cerrar
                </button>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </>
  );
}
