import { useEffect, useState } from "react";
import PageMeta from "../../components/common/PageMeta";
import { financingAPI, contactsAPI, dealsAPI, propertiesAPI } from "../../services/api";
import Button from "../../components/ui/button/Button";
import Badge from "../../components/ui/badge/Badge";
import Alert from "../../components/ui/alert/Alert";
import { Table, TableHeader, TableBody, TableRow, TableCell } from "../../components/ui/table";
import InputField from "../../components/form/input/InputField";
import { PlusIcon, PencilIcon, TrashBinIcon, DollarLineIcon, UserIcon, BoltIcon, FileIcon, CheckCircleIcon, TimeIcon } from "../../icons";
import { useModal } from "../../hooks/useModal";
import { Modal } from "../../components/ui/modal";

export default function Financing() {
  const [financings, setFinancings] = useState<any[]>([]);
  const [contacts, setContacts] = useState<any[]>([]);
  const [deals, setDeals] = useState<any[]>([]);
  const [properties, setProperties] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState({ search: "", status: "", loan_type: "" });
  const { isOpen, openModal, closeModal } = useModal();
  const [editingFinancing, setEditingFinancing] = useState<any>(null);
  const [showCalculator, setShowCalculator] = useState(false);

  useEffect(() => {
    loadData();
  }, [filter]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [financingsData, contactsData, dealsData, propertiesData] = await Promise.all([
        financingAPI.getAll(filter),
        contactsAPI.getAll(),
        dealsAPI.getAll(),
        propertiesAPI.getAll(),
      ]);
      
      let filtered = financingsData;
      
      if (filter.search) {
        filtered = filtered.filter((f: any) => {
          const contactName = f.contact_id 
            ? `${f.contact_id.first_name || ''} ${f.contact_id.last_name || ''}`.toLowerCase()
            : '';
          const lenderName = f.lender_name?.toLowerCase() || '';
          return contactName.includes(filter.search.toLowerCase()) || 
                 lenderName.includes(filter.search.toLowerCase());
        });
      }
      
      setFinancings(filtered);
      setContacts(contactsData);
      setDeals(dealsData);
      setProperties(propertiesData);
    } catch (error) {
      console.error("Error cargando datos:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string | number) => {
    if (confirm("¿Estás seguro de eliminar esta solicitud de financiación?")) {
      try {
        await financingAPI.delete(id);
        loadData();
      } catch (error) {
        console.error("Error eliminando financiación:", error);
        alert("Error al eliminar la financiación. Por favor, intenta nuevamente.");
      }
    }
  };

  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, { color: "info" | "success" | "warning" | "error" | "light"; label: string }> = {
      draft: { color: "light", label: "Borrador" },
      submitted: { color: "info", label: "Enviada" },
      under_review: { color: "warning", label: "En Revisión" },
      approved: { color: "success", label: "Aprobada" },
      rejected: { color: "error", label: "Rechazada" },
      closed: { color: "light", label: "Cerrada" },
    };
    const config = statusMap[status] || statusMap.draft;
    return (
      <Badge color={config.color} variant="light" size="sm">
        {config.label}
      </Badge>
    );
  };

  const getLoanTypeLabel = (type: string) => {
    const types: Record<string, string> = {
      conventional: "Convencional",
      fha: "FHA",
      va: "VA",
      usda: "USDA",
      jumbo: "Jumbo",
      other: "Otro",
    };
    return types[type] || type;
  };

  const stats = {
    total: financings.length,
    approved: financings.filter((f) => f.status === "approved").length,
    underReview: financings.filter((f) => f.status === "under_review").length,
    totalAmount: financings.reduce((sum, f) => sum + (Number(f.loan_amount) || 0), 0),
  };

  return (
    <>
      <PageMeta title="Financiación - RockIt" />
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <DollarLineIcon className="w-6 h-6 text-brand-500 dark:text-brand-400" />
              <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
                Gestión de Financiación
              </h1>
            </div>
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              Administra solicitudes de préstamos hipotecarios y financiación
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              onClick={() => setShowCalculator(!showCalculator)}
              size="sm"
              variant="outline"
              startIcon={<BoltIcon className="w-4 h-4" />}
            >
              Calculadora
            </Button>
            <Button onClick={openModal} size="sm" startIcon={<PlusIcon className="w-4 h-4" />}>
              Nueva Solicitud
            </Button>
          </div>
        </div>

        {/* AI Feature Alert */}
        <Alert
          variant="info"
          title="Gestión Inteligente de Financiación"
          message="Gestiona todas tus solicitudes de préstamos hipotecarios en un solo lugar. Calcula pagos mensuales, realiza seguimiento del estado de las aplicaciones y mantén toda la documentación organizada."
        />

        {/* Stats Cards */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="p-4 bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Total Solicitudes</p>
                <p className="mt-1 text-2xl font-bold text-gray-800 dark:text-white">
                  {stats.total}
                </p>
              </div>
              <div className="p-3 bg-brand-100 rounded-full dark:bg-brand-500/20">
                <FileIcon className="w-6 h-6 text-brand-500 dark:text-brand-400" />
              </div>
            </div>
          </div>

          <div className="p-4 bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Aprobadas</p>
                <p className="mt-1 text-2xl font-bold text-success-600 dark:text-success-400">
                  {stats.approved}
                </p>
              </div>
              <div className="p-3 bg-success-100 rounded-full dark:bg-success-500/20">
                <CheckCircleIcon className="w-6 h-6 text-success-500 dark:text-success-400" />
              </div>
            </div>
          </div>

          <div className="p-4 bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">En Revisión</p>
                <p className="mt-1 text-2xl font-bold text-warning-600 dark:text-warning-400">
                  {stats.underReview}
                </p>
              </div>
              <div className="p-3 bg-warning-100 rounded-full dark:bg-warning-500/20">
                <TimeIcon className="w-6 h-6 text-warning-500 dark:text-warning-400" />
              </div>
            </div>
          </div>

          <div className="p-4 bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Monto Total</p>
                <p className="mt-1 text-2xl font-bold text-gray-800 dark:text-white">
                  €{(stats.totalAmount / 1000000).toFixed(1)}M
                </p>
              </div>
              <div className="p-3 bg-info-100 rounded-full dark:bg-info-500/20">
                <DollarLineIcon className="w-6 h-6 text-info-500 dark:text-info-400" />
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col gap-4 p-4 bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700 sm:flex-row">
          <InputField
            type="text"
            placeholder="Buscar por cliente o prestamista..."
            value={filter.search}
            onChange={(e) => setFilter({ ...filter, search: e.target.value })}
            className="flex-1"
          />
          <select
            value={filter.status}
            onChange={(e) => setFilter({ ...filter, status: e.target.value })}
            className="h-11 rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-3 focus:border-brand-300 focus:ring-brand-500/20 dark:bg-gray-900 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800"
          >
            <option value="">Todos los estados</option>
            <option value="draft">Borrador</option>
            <option value="submitted">Enviada</option>
            <option value="under_review">En Revisión</option>
            <option value="approved">Aprobada</option>
            <option value="rejected">Rechazada</option>
            <option value="closed">Cerrada</option>
          </select>
          <select
            value={filter.loan_type}
            onChange={(e) => setFilter({ ...filter, loan_type: e.target.value })}
            className="h-11 rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-3 focus:border-brand-300 focus:ring-brand-500/20 dark:bg-gray-900 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800"
          >
            <option value="">Todos los tipos</option>
            <option value="conventional">Convencional</option>
            <option value="fha">FHA</option>
            <option value="va">VA</option>
            <option value="usda">USDA</option>
            <option value="jumbo">Jumbo</option>
            <option value="other">Otro</option>
          </select>
        </div>

        {/* Calculator Modal */}
        {showCalculator && (
          <LoanCalculatorModal
            isOpen={showCalculator}
            onClose={() => setShowCalculator(false)}
          />
        )}

        {/* Table */}
        {loading ? (
          <div className="flex items-center justify-center p-12 bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
            <div className="text-gray-500 dark:text-gray-400">Cargando financiaciones...</div>
          </div>
        ) : (
          <div className="overflow-hidden bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableCell isHeader className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-400">
                      Cliente
                    </TableCell>
                    <TableCell isHeader className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-400">
                      Tipo de Préstamo
                    </TableCell>
                    <TableCell isHeader className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-400">
                      Monto
                    </TableCell>
                    <TableCell isHeader className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-400">
                      Tasa de Interés
                    </TableCell>
                    <TableCell isHeader className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-400">
                      Plazo
                    </TableCell>
                    <TableCell isHeader className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-400">
                      Pago Mensual
                    </TableCell>
                    <TableCell isHeader className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-400">
                      Estado
                    </TableCell>
                    <TableCell isHeader className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-400">
                      Acciones
                    </TableCell>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {financings.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="px-6 py-12 text-center">
                        <div className="flex flex-col items-center gap-2">
                          <DollarLineIcon className="w-12 h-12 text-gray-400" />
                          <p className="text-gray-500 dark:text-gray-400">No hay solicitudes de financiación registradas</p>
                          <Button onClick={openModal} size="sm" variant="outline" className="mt-2">
                            <PlusIcon className="w-4 h-4" />
                            Crear primera solicitud
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ) : (
                    financings.map((financing) => (
                      <TableRow key={financing._id || financing.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                        <TableCell className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="flex items-center justify-center w-10 h-10 rounded-full bg-brand-100 text-brand-600 dark:bg-brand-500/20 dark:text-brand-400">
                              <UserIcon className="w-5 h-5" />
                            </div>
                            <div>
                              <div className="font-medium text-gray-900 dark:text-white">
                                {financing.contact_id
                                  ? `${financing.contact_id.first_name || ''} ${financing.contact_id.last_name || ''}`
                                  : 'Sin cliente'}
                              </div>
                              {financing.lender_name && (
                                <div className="text-sm text-gray-500 dark:text-gray-400">
                                  {financing.lender_name}
                                </div>
                              )}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="px-6 py-4">
                          <Badge color="info" variant="light" size="sm">
                            {getLoanTypeLabel(financing.loan_type)}
                          </Badge>
                        </TableCell>
                        <TableCell className="px-6 py-4 text-gray-900 dark:text-white">
                          €{Number(financing.loan_amount || 0).toLocaleString()}
                        </TableCell>
                        <TableCell className="px-6 py-4 text-gray-900 dark:text-white">
                          {financing.interest_rate ? `${financing.interest_rate}%` : 'N/A'}
                        </TableCell>
                        <TableCell className="px-6 py-4 text-gray-900 dark:text-white">
                          {financing.loan_term} años
                        </TableCell>
                        <TableCell className="px-6 py-4 text-gray-900 dark:text-white font-semibold">
                          {financing.monthly_payment 
                            ? `€${Number(financing.monthly_payment).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                            : 'N/A'}
                        </TableCell>
                        <TableCell className="px-6 py-4">
                          {getStatusBadge(financing.status)}
                        </TableCell>
                        <TableCell className="px-6 py-4">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => {
                                setEditingFinancing(financing);
                                openModal();
                              }}
                              className="p-2 text-gray-600 transition-colors rounded-lg hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700"
                              title="Editar"
                            >
                              <PencilIcon className="w-5 h-5" />
                            </button>
                            <button
                              onClick={() => handleDelete(financing._id || financing.id)}
                              className="p-2 text-error-500 transition-colors rounded-lg hover:bg-error-50 dark:hover:bg-error-500/20"
                              title="Eliminar"
                            >
                              <TrashBinIcon className="w-5 h-5" />
                            </button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
        )}

        <FinancingModal
          isOpen={isOpen}
          onClose={() => {
            closeModal();
            setEditingFinancing(null);
          }}
          onSave={() => {
            loadData();
            closeModal();
            setEditingFinancing(null);
          }}
          financing={editingFinancing}
          contacts={contacts}
          deals={deals}
          properties={properties}
        />
      </div>
    </>
  );
}

// Loan Calculator Component
function LoanCalculatorModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const [loanAmount, setLoanAmount] = useState("");
  const [interestRate, setInterestRate] = useState("");
  const [loanTerm, setLoanTerm] = useState("30");
  const [downPayment, setDownPayment] = useState("");
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const handleCalculate = async () => {
    if (!loanAmount || !interestRate || !loanTerm) {
      alert("Por favor completa todos los campos requeridos");
      return;
    }

    setLoading(true);
    try {
      const data = await financingAPI.calculate({
        loan_amount: Number(loanAmount),
        interest_rate: Number(interestRate),
        loan_term: Number(loanTerm),
        down_payment: Number(downPayment) || 0,
      });
      setResult(data);
    } catch (error) {
      console.error("Error calculando:", error);
      alert("Error al calcular el pago mensual");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <div className="p-6">
        <h2 className="mb-6 text-2xl font-semibold text-gray-800 dark:text-white">
          Calculadora de Préstamo
        </h2>

        <div className="space-y-4">
          <InputField
            label="Monto del Préstamo"
            type="number"
            value={loanAmount}
            onChange={(e) => setLoanAmount(e.target.value)}
            placeholder="Ej: 300000"
          />

          <InputField
            label="Tasa de Interés Anual (%)"
            type="number"
            step="0.01"
            value={interestRate}
            onChange={(e) => setInterestRate(e.target.value)}
            placeholder="Ej: 6.5"
          />

          <div>
            <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              Plazo del Préstamo (años)
            </label>
            <select
              value={loanTerm}
              onChange={(e) => setLoanTerm(e.target.value)}
              className="h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-3 focus:border-brand-300 focus:ring-brand-500/20 dark:bg-gray-900 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800"
            >
              <option value="15">15 años</option>
              <option value="20">20 años</option>
              <option value="30">30 años</option>
            </select>
          </div>

          <InputField
            label="Pago Inicial (opcional)"
            type="number"
            value={downPayment}
            onChange={(e) => setDownPayment(e.target.value)}
            placeholder="Ej: 60000"
          />

          <Button
            onClick={handleCalculate}
            disabled={loading}
            className="w-full"
            startIcon={loading ? undefined : <BoltIcon className="w-4 h-4" />}
          >
            {loading ? "Calculando..." : "Calcular"}
          </Button>

          {result && (
            <div className="p-4 mt-4 bg-brand-50 rounded-lg dark:bg-brand-900/20 border border-brand-200 dark:border-brand-800">
              <h3 className="mb-3 font-semibold text-brand-800 dark:text-brand-300">
                Resultados del Cálculo
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Pago Mensual:</span>
                  <span className="font-semibold text-brand-600 dark:text-brand-400">
                    €{Number(result.monthly_payment).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Pago Total:</span>
                  <span className="font-semibold text-gray-800 dark:text-white">
                    €{Number(result.total_payment).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Interés Total:</span>
                  <span className="font-semibold text-gray-800 dark:text-white">
                    €{Number(result.total_interest).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Principal:</span>
                  <span className="font-semibold text-gray-800 dark:text-white">
                    €{Number(result.principal).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </Modal>
  );
}

// Financing Modal Component
function FinancingModal({
  isOpen,
  onClose,
  onSave,
  financing,
  contacts,
  deals,
  properties,
}: {
  isOpen: boolean;
  onClose: () => void;
  onSave: () => void;
  financing?: any;
  contacts: any[];
  deals: any[];
  properties: any[];
}) {
  const [formData, setFormData] = useState({
    contact_id: "",
    deal_id: "",
    property_id: "",
    loan_type: "conventional",
    loan_amount: "",
    interest_rate: "",
    loan_term: "30",
    down_payment: "",
    down_payment_percentage: "",
    lender_name: "",
    lender_contact: "",
    notes: "",
    credit_score: "",
    debt_to_income_ratio: "",
    status: "draft",
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (financing) {
      setFormData({
        contact_id: financing.contact_id?._id || financing.contact_id || "",
        deal_id: financing.deal_id?._id || financing.deal_id || "",
        property_id: financing.property_id?._id || financing.property_id || "",
        loan_type: financing.loan_type || "conventional",
        loan_amount: financing.loan_amount?.toString() || "",
        interest_rate: financing.interest_rate?.toString() || "",
        loan_term: financing.loan_term?.toString() || "30",
        down_payment: financing.down_payment?.toString() || "",
        down_payment_percentage: financing.down_payment_percentage?.toString() || "",
        lender_name: financing.lender_name || "",
        lender_contact: financing.lender_contact || "",
        notes: financing.notes || "",
        credit_score: financing.credit_score?.toString() || "",
        debt_to_income_ratio: financing.debt_to_income_ratio?.toString() || "",
        status: financing.status || "draft",
      });
    } else {
      setFormData({
        contact_id: "",
        deal_id: "",
        property_id: "",
        loan_type: "conventional",
        loan_amount: "",
        interest_rate: "",
        loan_term: "30",
        down_payment: "",
        down_payment_percentage: "",
        lender_name: "",
        lender_contact: "",
        notes: "",
        credit_score: "",
        debt_to_income_ratio: "",
        status: "draft",
      });
    }
  }, [financing, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const data = {
        ...formData,
        loan_amount: Number(formData.loan_amount),
        interest_rate: formData.interest_rate ? Number(formData.interest_rate) : null,
        loan_term: Number(formData.loan_term),
        down_payment: formData.down_payment ? Number(formData.down_payment) : 0,
        down_payment_percentage: formData.down_payment_percentage ? Number(formData.down_payment_percentage) : 0,
        credit_score: formData.credit_score ? Number(formData.credit_score) : null,
        debt_to_income_ratio: formData.debt_to_income_ratio ? Number(formData.debt_to_income_ratio) : null,
        deal_id: formData.deal_id || null,
        property_id: formData.property_id || null,
      };

      if (financing) {
        const financingId = financing._id || financing.id;
        await financingAPI.update(financingId, data);
      } else {
        await financingAPI.create(data);
      }
      onSave();
    } catch (error) {
      console.error("Error guardando financiación:", error);
      alert("Error al guardar la financiación");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <div className="p-6">
        <h2 className="mb-6 text-2xl font-semibold text-gray-800 dark:text-white">
          {financing ? "Editar Financiación" : "Nueva Solicitud de Financiación"}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              Cliente *
            </label>
            <select
              value={formData.contact_id}
              onChange={(e) => setFormData({ ...formData, contact_id: e.target.value })}
              required
              className="h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-3 focus:border-brand-300 focus:ring-brand-500/20 dark:bg-gray-900 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800"
            >
              <option value="">Seleccionar cliente</option>
              {contacts.map((contact) => (
                <option key={contact._id || contact.id} value={contact._id || contact.id}>
                  {contact.first_name} {contact.last_name} {contact.email ? `(${contact.email})` : ''}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                Tipo de Préstamo *
              </label>
              <select
                value={formData.loan_type}
                onChange={(e) => setFormData({ ...formData, loan_type: e.target.value })}
                required
                className="h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-3 focus:border-brand-300 focus:ring-brand-500/20 dark:bg-gray-900 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800"
              >
                <option value="conventional">Convencional</option>
                <option value="fha">FHA</option>
                <option value="va">VA</option>
                <option value="usda">USDA</option>
                <option value="jumbo">Jumbo</option>
                <option value="other">Otro</option>
              </select>
            </div>

            <div>
              <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                Estado
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                className="h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-3 focus:border-brand-300 focus:ring-brand-500/20 dark:bg-gray-900 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800"
              >
                <option value="draft">Borrador</option>
                <option value="submitted">Enviada</option>
                <option value="under_review">En Revisión</option>
                <option value="approved">Aprobada</option>
                <option value="rejected">Rechazada</option>
                <option value="closed">Cerrada</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <InputField
              label="Monto del Préstamo *"
              type="number"
              value={formData.loan_amount}
              onChange={(e) => setFormData({ ...formData, loan_amount: e.target.value })}
              required
              placeholder="Ej: 300000"
            />

            <InputField
              label="Tasa de Interés (%)"
              type="number"
              step="0.01"
              value={formData.interest_rate}
              onChange={(e) => setFormData({ ...formData, interest_rate: e.target.value })}
              placeholder="Ej: 6.5"
            />
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                Plazo (años) *
              </label>
              <select
                value={formData.loan_term}
                onChange={(e) => setFormData({ ...formData, loan_term: e.target.value })}
                required
                className="h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-3 focus:border-brand-300 focus:ring-brand-500/20 dark:bg-gray-900 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800"
              >
                <option value="15">15 años</option>
                <option value="20">20 años</option>
                <option value="30">30 años</option>
              </select>
            </div>

            <InputField
              label="Pago Inicial"
              type="number"
              value={formData.down_payment}
              onChange={(e) => setFormData({ ...formData, down_payment: e.target.value })}
              placeholder="Ej: 60000"
            />
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <InputField
              label="Nombre del Prestamista"
              type="text"
              value={formData.lender_name}
              onChange={(e) => setFormData({ ...formData, lender_name: e.target.value })}
              placeholder="Ej: Banco Nacional"
            />

            <InputField
              label="Contacto del Prestamista"
              type="text"
              value={formData.lender_contact}
              onChange={(e) => setFormData({ ...formData, lender_contact: e.target.value })}
              placeholder="Ej: contacto@banco.com"
            />
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <InputField
              label="Score Crediticio"
              type="number"
              value={formData.credit_score}
              onChange={(e) => setFormData({ ...formData, credit_score: e.target.value })}
              placeholder="Ej: 750"
            />

            <InputField
              label="Ratio Deuda/Ingreso (%)"
              type="number"
              step="0.01"
              value={formData.debt_to_income_ratio}
              onChange={(e) => setFormData({ ...formData, debt_to_income_ratio: e.target.value })}
              placeholder="Ej: 36"
            />
          </div>

          <div>
            <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              Transacción (opcional)
            </label>
            <select
              value={formData.deal_id}
              onChange={(e) => setFormData({ ...formData, deal_id: e.target.value })}
              className="h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-3 focus:border-brand-300 focus:ring-brand-500/20 dark:bg-gray-900 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800"
            >
              <option value="">Sin transacción</option>
              {deals.map((deal) => (
                <option key={deal._id || deal.id} value={deal._id || deal.id}>
                  {deal.property_title || `Deal #${deal._id || deal.id}`}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              Propiedad (opcional)
            </label>
            <select
              value={formData.property_id}
              onChange={(e) => setFormData({ ...formData, property_id: e.target.value })}
              className="h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-3 focus:border-brand-300 focus:ring-brand-500/20 dark:bg-gray-900 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800"
            >
              <option value="">Sin propiedad</option>
              {properties.map((property) => (
                <option key={property._id || property.id} value={property._id || property.id}>
                  {property.title || property.address}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              Notas
            </label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={4}
              className="w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-3 focus:border-brand-300 focus:ring-brand-500/20 dark:bg-gray-900 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800"
              placeholder="Notas adicionales sobre la solicitud..."
            />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Guardando..." : financing ? "Actualizar" : "Crear"}
            </Button>
          </div>
        </form>
      </div>
    </Modal>
  );
}

