import { useEffect, useState } from "react";
import PageMeta from "../../components/common/PageMeta";
import { automationAPI } from "../../services/api";
import Button from "../../components/ui/button/Button";
import Badge from "../../components/ui/badge/Badge";
import Alert from "../../components/ui/alert/Alert";
import Switch from "../../components/form/switch/Switch";
import { BoltIcon, PlusIcon, CheckCircleIcon, InfoIcon } from "../../icons";

export default function Automation() {
  const [workflows, setWorkflows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadWorkflows();
  }, []);

  const loadWorkflows = async () => {
    setLoading(true);
    try {
      const data = await automationAPI.getWorkflows();
      setWorkflows(data);
    } catch (error) {
      console.error("Error cargando workflows:", error);
    } finally {
      setLoading(false);
    }
  };

  const toggleWorkflow = async (id: number, isActive: boolean) => {
    try {
      await automationAPI.updateWorkflow(id, { isActive: !isActive });
      loadWorkflows();
    } catch (error) {
      console.error("Error actualizando workflow:", error);
    }
  };

  const predefinedWorkflows = [
    {
      name: "Nutrición Nuevo Lead Web",
      description: "Envía emails automáticos de bienvenida y seguimiento a nuevos leads que llegan desde tu sitio web",
      trigger: "Nuevo lead registrado",
      actions: ["Email de bienvenida", "Seguimiento a los 3 días", "Lead scoring automático"],
      icon: "📧",
    },
    {
      name: "Seguimiento Post-Venta",
      description: "Mantiene contacto automático con clientes después del cierre de la transacción",
      trigger: "Deal cerrado",
      actions: ["Email de agradecimiento", "Encuesta de satisfacción", "Solicitud de referidos"],
      icon: "🎉",
    },
    {
      name: "Lead Scoring Automático",
      description: "Actualiza automáticamente las puntuaciones de leads basado en su actividad e interacciones",
      trigger: "Actividad del lead",
      actions: ["Análisis de comportamiento", "Actualización de score", "Clasificación automática"],
      icon: "🎯",
    },
    {
      name: "Notificaciones de Leads Calientes",
      description: "Te alerta inmediatamente cuando un lead alcanza un score alto o muestra señales de compra",
      trigger: "Lead score >= 80",
      actions: ["Notificación push", "Email al agente", "Priorización automática"],
      icon: "🔥",
    },
  ];

  return (
    <>
      <PageMeta title="Automatización - RockIt" />
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <BoltIcon className="w-6 h-6 text-brand-500 dark:text-brand-400" />
              <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
                Automatización del Ciclo de Vida
              </h1>
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Gestiona workflows y automatizaciones inteligentes
            </p>
          </div>
          <Button size="sm" startIcon={<PlusIcon className="w-4 h-4" />}>
            Nuevo Workflow
          </Button>
        </div>

        {/* AI Feature Alert */}
        <Alert
          variant="info"
          title="Automatización Inteligente con IA"
          message="Nuestros workflows utilizan inteligencia artificial para analizar el comportamiento de los leads, optimizar el timing de las comunicaciones y personalizar los mensajes según el perfil de cada cliente."
        />

        {/* Active Workflows */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-800 dark:text-white">
              Workflows Activos
            </h2>
            <Badge color="success" variant="light" size="sm">
              {workflows.filter((w) => w.is_active).length} activos
            </Badge>
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="text-gray-500 dark:text-gray-400">Cargando workflows...</div>
            </div>
          ) : workflows.length === 0 ? (
            <div className="p-12 text-center bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
              <BoltIcon className="w-16 h-16 mx-auto mb-4 text-gray-400" />
              <p className="text-gray-500 dark:text-gray-400 mb-4">
                No hay workflows configurados
              </p>
              <Button size="sm" variant="outline">
                <PlusIcon className="w-4 h-4" />
                Crear primer workflow
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {workflows.map((workflow) => (
                <div
                  key={workflow.id}
                  className="p-6 bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-lg font-semibold text-gray-800 dark:text-white">
                          {workflow.name}
                        </h3>
                        {workflow.is_active ? (
                          <Badge color="success" variant="light" size="sm" startIcon={<CheckCircleIcon className="w-3 h-3" />}>
                            Activo
                          </Badge>
                        ) : (
                          <Badge color="light" variant="light" size="sm">
                            Inactivo
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                        <strong>Trigger:</strong> {workflow.trigger_type}
                      </p>
                      {workflow.description && (
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          {workflow.description}
                        </p>
                      )}
                    </div>
                    <div className="ml-4">
                      <Switch
                        label=""
                        defaultChecked={workflow.is_active}
                        onChange={() => toggleWorkflow(workflow.id, workflow.is_active)}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Predefined Workflows */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <InfoIcon className="w-5 h-5 text-brand-500 dark:text-brand-400" />
            <h2 className="text-lg font-semibold text-gray-800 dark:text-white">
              Workflows Predefinidos Disponibles
            </h2>
          </div>

          <div className="p-6 bg-gradient-to-br from-brand-50 via-purple-50 to-blue-50 rounded-lg dark:from-brand-900/20 dark:via-purple-900/20 dark:to-blue-900/20 border border-brand-200 dark:border-brand-800">
            <div className="flex items-center gap-2 mb-4">
              <BoltIcon className="w-5 h-5 text-brand-500 dark:text-brand-400" />
              <p className="text-sm font-medium text-gray-800 dark:text-white">
                Estos workflows están optimizados con IA y listos para usar
              </p>
            </div>

            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              {predefinedWorkflows.map((workflow, index) => (
                <div
                  key={index}
                  className="p-4 bg-white/80 dark:bg-gray-800/80 rounded-lg border border-gray-200 dark:border-gray-700 backdrop-blur-sm"
                >
                  <div className="flex items-start gap-3 mb-3">
                    <div className="text-2xl">{workflow.icon}</div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-800 dark:text-white mb-1">
                        {workflow.name}
                      </h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {workflow.description}
                      </p>
                    </div>
                  </div>
                  <div className="mt-3 pt-3 border-t border-gray-200 dark:border-gray-700">
                    <p className="text-xs font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Trigger: <span className="font-normal">{workflow.trigger}</span>
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {workflow.actions.map((action, i) => (
                        <Badge key={i} color="info" variant="light" size="sm">
                          {action}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <Button size="sm" variant="outline" className="w-full mt-3">
                    <PlusIcon className="w-4 h-4" />
                    Activar Workflow
                  </Button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
