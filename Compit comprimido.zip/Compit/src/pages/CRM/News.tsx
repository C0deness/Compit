import { useEffect, useState } from "react";
import PageMeta from "../../components/common/PageMeta";
import { newsAPI } from "../../services/api";
import Badge from "../../components/ui/badge/Badge";
import { Modal } from "../../components/ui/modal";
import { useModal } from "../../hooks/useModal";

export default function News() {
  const [news, setNews] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedNews, setSelectedNews] = useState<any | null>(null);
  const { isOpen, openModal, closeModal } = useModal();
  const [filters, setFilters] = useState({
    category: '',
    brand: '',
    is_read: '',
  });

  useEffect(() => {
    fetchNews();
  }, [filters]);

  const fetchNews = async () => {
    try {
      const params: any = { limit: 50 };
      if (filters.category) params.category = filters.category;
      if (filters.brand) params.brand = filters.brand;
      if (filters.is_read !== '') params.is_read = filters.is_read === 'true';
      
      const response = await newsAPI.getAll(params);
      setNews(response.news || []);
    } catch (error) {
      console.error("Error cargando noticias:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleMarkAsRead = async (id: string, event?: React.MouseEvent) => {
    event?.stopPropagation();
    try {
      await newsAPI.markAsRead(id);
      fetchNews();
      if (selectedNews?._id === id) {
        setSelectedNews({ ...selectedNews, is_read: true });
      }
    } catch (error) {
      console.error("Error marcando noticia:", error);
    }
  };

  const handleNewsClick = (item: any) => {
    setSelectedNews(item);
    openModal();
    // Marcar como leída al abrir
    if (!item.is_read) {
      handleMarkAsRead(item._id);
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'precio':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-500/20 dark:text-blue-400';
      case 'stock':
        return 'bg-green-100 text-green-800 dark:bg-green-500/20 dark:text-green-400';
      case 'financiacion':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-500/20 dark:text-purple-400';
      case 'competencia':
        return 'bg-orange-100 text-orange-800 dark:bg-orange-500/20 dark:text-orange-400';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-500/20 dark:text-gray-400';
    }
  };

  return (
    <>
      <PageMeta
        title="Noticias - AutoMarket Intelligence"
        description="Feed de noticias sobre precios, stock y financiación de vehículos"
      />
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
            Noticias del Mercado
          </h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Vigilancia competitiva en tiempo real
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4">
          <select
            value={filters.category}
            onChange={(e) => setFilters({ ...filters, category: e.target.value })}
            className="px-4 py-2 border border-gray-300 rounded-lg dark:border-gray-700 dark:bg-gray-800 dark:text-white"
          >
            <option value="">Todas las categorías</option>
            <option value="precio">Precio</option>
            <option value="stock">Stock</option>
            <option value="financiacion">Financiación</option>
            <option value="competencia">Competencia</option>
            <option value="general">General</option>
          </select>
          <input
            type="text"
            placeholder="Filtrar por marca..."
            value={filters.brand}
            onChange={(e) => setFilters({ ...filters, brand: e.target.value })}
            className="px-4 py-2 border border-gray-300 rounded-lg dark:border-gray-700 dark:bg-gray-800 dark:text-white"
          />
          <select
            value={filters.is_read}
            onChange={(e) => setFilters({ ...filters, is_read: e.target.value })}
            className="px-4 py-2 border border-gray-300 rounded-lg dark:border-gray-700 dark:bg-gray-800 dark:text-white"
          >
            <option value="">Todas</option>
            <option value="false">No leídas</option>
            <option value="true">Leídas</option>
          </select>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-gray-500 dark:text-gray-400">Cargando noticias...</div>
          </div>
        ) : (
          <div className="space-y-4">
            {news.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-500 dark:text-gray-400">
                  No hay noticias disponibles
                </p>
              </div>
            ) : (
              news.map((item) => (
                <div
                  key={item._id}
                  onClick={() => handleNewsClick(item)}
                  className={`p-6 border rounded-lg dark:border-gray-700 cursor-pointer hover:shadow-lg transition-all ${
                    !item.is_read
                      ? 'border-brand-200 bg-brand-50/50 dark:bg-brand-500/10'
                      : 'border-gray-200 bg-white dark:bg-white/[0.03]'
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold text-gray-800 dark:text-white">
                          {item.title}
                        </h3>
                        <span className={`px-2 py-1 text-xs rounded ${getCategoryColor(item.category)}`}>
                          {item.category}
                        </span>
                        {!item.is_read && (
                          <Badge color="info" size="sm">Nueva</Badge>
                        )}
                      </div>
                      {item.summary && (
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                          {item.summary}
                        </p>
                      )}
                      <p className="text-sm text-gray-700 dark:text-gray-300">
                        {item.content}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                    <div className="flex items-center gap-4 text-xs text-gray-500 dark:text-gray-400">
                      <span>Fuente: {item.source}</span>
                      {item.brand && <span>Marca: {item.brand}</span>}
                      {item.model && <span>Modelo: {item.model}</span>}
                      {item.price && <span>Precio: €{item.price.toLocaleString()}</span>}
                      <span>{new Date(item.published_at).toLocaleDateString()}</span>
                    </div>
                    {!item.is_read && (
                      <button
                        onClick={(e) => handleMarkAsRead(item._id, e)}
                        className="px-4 py-2 text-sm bg-brand-500 text-white rounded-lg hover:bg-brand-600 transition-colors"
                      >
                        Marcar como leída
                      </button>
                    )}
                  </div>
                  {item.keywords && item.keywords.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-3">
                      {item.keywords.map((keyword: string, idx: number) => (
                        <span
                          key={idx}
                          className="px-2 py-1 text-xs bg-gray-100 dark:bg-gray-700 rounded"
                        >
                          {keyword}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </div>

      {/* Modal de Noticia Detallada */}
      <Modal isOpen={isOpen} onClose={closeModal} className="max-w-4xl">
        {selectedNews && (
          <div className="p-6">
            <div className="mb-6">
              <div className="flex items-center gap-3 mb-4">
                <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
                  {selectedNews.title}
                </h2>
                <span className={`px-3 py-1 text-sm rounded ${getCategoryColor(selectedNews.category)}`}>
                  {selectedNews.category}
                </span>
                {!selectedNews.is_read && (
                  <Badge color="info" size="sm">Nueva</Badge>
                )}
              </div>
              
              <div className="flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400 mb-4">
                <span className="font-medium">Fuente:</span>
                <span>{selectedNews.source}</span>
                {selectedNews.source_url && (
                  <a
                    href={selectedNews.source_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-brand-500 hover:text-brand-600 underline"
                  >
                    Ver original →
                  </a>
                )}
              </div>

              <div className="flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400 mb-6">
                {selectedNews.brand && <span><strong>Marca:</strong> {selectedNews.brand}</span>}
                {selectedNews.model && <span><strong>Modelo:</strong> {selectedNews.model}</span>}
                {selectedNews.price && <span><strong>Precio:</strong> €{selectedNews.price.toLocaleString()}</span>}
                <span><strong>Publicado:</strong> {new Date(selectedNews.published_at).toLocaleString('es-ES')}</span>
              </div>
            </div>

            {selectedNews.summary && (
              <div className="mb-6 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <h3 className="font-semibold text-gray-800 dark:text-white mb-2">Resumen</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {selectedNews.summary}
                </p>
              </div>
            )}

            <div className="mb-6">
              <h3 className="font-semibold text-gray-800 dark:text-white mb-3">Contenido Completo</h3>
              <div className="prose dark:prose-invert max-w-none">
                <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
                  {selectedNews.content}
                </p>
              </div>
            </div>

            {selectedNews.keywords && selectedNews.keywords.length > 0 && (
              <div className="mb-6">
                <h3 className="font-semibold text-gray-800 dark:text-white mb-3">Palabras Clave</h3>
                <div className="flex flex-wrap gap-2">
                  {selectedNews.keywords.map((keyword: string, idx: number) => (
                    <span
                      key={idx}
                      className="px-3 py-1 text-sm bg-brand-100 dark:bg-brand-900/30 text-brand-800 dark:text-brand-300 rounded-full"
                    >
                      {keyword}
                    </span>
                  ))}
                </div>
              </div>
            )}

            <div className="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-700">
              <div className="text-xs text-gray-500 dark:text-gray-400">
                {selectedNews.relevance_score && (
                  <span>Relevancia: {selectedNews.relevance_score}%</span>
                )}
              </div>
              <div className="flex gap-2">
                {selectedNews.source_url && (
                  <a
                    href={selectedNews.source_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 text-sm bg-brand-500 text-white rounded-lg hover:bg-brand-600 transition-colors"
                  >
                    Ver Noticia Original
                  </a>
                )}
                <button
                  onClick={closeModal}
                  className="px-4 py-2 text-sm bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
                >
                  Cerrar
                </button>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </>
  );
}
