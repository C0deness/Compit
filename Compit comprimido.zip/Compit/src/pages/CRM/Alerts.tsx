import { useEffect, useState } from "react";
import PageMeta from "../../components/common/PageMeta";
import { alertsAPI } from "../../services/api";
import Badge from "../../components/ui/badge/Badge";
import { Modal } from "../../components/ui/modal";
import { useModal } from "../../hooks/useModal";

export default function Alerts() {
  const [alerts, setAlerts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedAlert, setSelectedAlert] = useState<any | null>(null);
  const { isOpen, openModal, closeModal } = useModal();
  const [filters, setFilters] = useState({
    type: '',
    severity: '',
    is_read: '',
  });

  useEffect(() => {
    fetchAlerts();
  }, [filters]);

  const fetchAlerts = async () => {
    try {
      const params: any = { limit: 50 };
      if (filters.type) params.type = filters.type;
      if (filters.severity) params.severity = filters.severity;
      if (filters.is_read !== '') params.is_read = filters.is_read === 'true';
      
      const response = await alertsAPI.getAll(params);
      setAlerts(response.alerts || []);
    } catch (error) {
      console.error("Error cargando alertas:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleMarkAsRead = async (id: string, event?: React.MouseEvent) => {
    event?.stopPropagation();
    try {
      await alertsAPI.markAsRead(id);
      fetchAlerts();
      if (selectedAlert?._id === id) {
        setSelectedAlert({ ...selectedAlert, is_read: true });
      }
    } catch (error) {
      console.error("Error marcando alerta:", error);
    }
  };

  const handleActionTaken = async (id: string, event?: React.MouseEvent) => {
    event?.stopPropagation();
    try {
      await alertsAPI.markActionTaken(id, 'Acción tomada por el usuario');
      fetchAlerts();
      if (selectedAlert?._id === id) {
        setSelectedAlert({ ...selectedAlert, action_taken: true });
      }
    } catch (error) {
      console.error("Error marcando acción:", error);
    }
  };

  const handleAlertClick = (alert: any) => {
    setSelectedAlert(alert);
    openModal();
    // Marcar como leída al abrir
    if (!alert.is_read) {
      handleMarkAsRead(alert._id);
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'error';
      case 'high':
        return 'warning';
      case 'medium':
        return 'info';
      default:
        return 'info';
    }
  };

  return (
    <>
      <PageMeta
        title="Alertas - AutoMarket Intelligence"
        description="Alertas inteligentes sobre cambios en el mercado"
      />
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
            Alertas Inteligentes
          </h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Notificaciones sobre cambios relevantes en el mercado
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4">
          <select
            value={filters.type}
            onChange={(e) => setFilters({ ...filters, type: e.target.value })}
            className="px-4 py-2 border border-gray-300 rounded-lg dark:border-gray-700 dark:bg-gray-800 dark:text-white"
          >
            <option value="">Todos los tipos</option>
            <option value="precio">Precio</option>
            <option value="stock">Stock</option>
            <option value="financiacion">Financiación</option>
            <option value="competencia">Competencia</option>
            <option value="kpi">KPI</option>
            <option value="recomendacion">Recomendación</option>
          </select>
          <select
            value={filters.severity}
            onChange={(e) => setFilters({ ...filters, severity: e.target.value })}
            className="px-4 py-2 border border-gray-300 rounded-lg dark:border-gray-700 dark:bg-gray-800 dark:text-white"
          >
            <option value="">Todas las severidades</option>
            <option value="critical">Crítica</option>
            <option value="high">Alta</option>
            <option value="medium">Media</option>
            <option value="low">Baja</option>
          </select>
          <select
            value={filters.is_read}
            onChange={(e) => setFilters({ ...filters, is_read: e.target.value })}
            className="px-4 py-2 border border-gray-300 rounded-lg dark:border-gray-700 dark:bg-gray-800 dark:text-white"
          >
            <option value="">Todas</option>
            <option value="false">No leídas</option>
            <option value="true">Leídas</option>
          </select>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-gray-500 dark:text-gray-400">Cargando alertas...</div>
          </div>
        ) : (
          <div className="space-y-4">
            {alerts.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-500 dark:text-gray-400">
                  No hay alertas disponibles
                </p>
              </div>
            ) : (
              alerts.map((alert) => (
                <div
                  key={alert._id}
                  onClick={() => handleAlertClick(alert)}
                  className={`p-6 border rounded-lg dark:border-gray-700 cursor-pointer hover:shadow-lg transition-all ${
                    !alert.is_read
                      ? 'border-brand-200 bg-brand-50/50 dark:bg-brand-500/10'
                      : 'border-gray-200 bg-white dark:bg-white/[0.03]'
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold text-gray-800 dark:text-white">
                          {alert.title}
                        </h3>
                        <Badge color={getSeverityColor(alert.severity)} size="sm">
                          {alert.severity}
                        </Badge>
                        {!alert.is_read && (
                          <Badge color="info" size="sm">Nueva</Badge>
                        )}
                      </div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        {alert.message || alert.description}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                    <div className="flex items-center gap-4 text-xs text-gray-500 dark:text-gray-400">
                      <span>Tipo: {alert.type}</span>
                      {alert.brand && <span>Marca: {alert.brand}</span>}
                      {alert.model && <span>Modelo: {alert.model}</span>}
                      <span>{new Date(alert.created_at).toLocaleDateString()}</span>
                    </div>
                    <div className="flex gap-2">
                      {!alert.is_read && (
                        <button
                          onClick={(e) => handleMarkAsRead(alert._id, e)}
                          className="px-4 py-2 text-sm bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
                        >
                          Marcar como leída
                        </button>
                      )}
                      {!alert.action_taken && (
                        <button
                          onClick={(e) => handleActionTaken(alert._id, e)}
                          className="px-4 py-2 text-sm bg-brand-500 text-white rounded-lg hover:bg-brand-600 transition-colors"
                        >
                          Marcar acción tomada
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>

      {/* Modal de Alerta Detallada */}
      <Modal isOpen={isOpen} onClose={closeModal} className="max-w-4xl">
        {selectedAlert && (
          <div className="p-6">
            <div className="mb-6">
              <div className="flex items-center gap-3 mb-4">
                <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
                  {selectedAlert.title}
                </h2>
                <Badge color={getSeverityColor(selectedAlert.severity)} size="sm">
                  {selectedAlert.severity}
                </Badge>
                {!selectedAlert.is_read && (
                  <Badge color="info" size="sm">Nueva</Badge>
                )}
                {selectedAlert.action_taken && (
                  <Badge color="success" size="sm">Acción Tomada</Badge>
                )}
              </div>

              <div className="flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400 mb-4">
                <span><strong>Tipo:</strong> {selectedAlert.type}</span>
                {selectedAlert.brand && <span><strong>Marca:</strong> {selectedAlert.brand}</span>}
                {selectedAlert.model && <span><strong>Modelo:</strong> {selectedAlert.model}</span>}
                <span><strong>Creada:</strong> {new Date(selectedAlert.created_at).toLocaleString('es-ES')}</span>
              </div>
            </div>

            <div className="mb-6">
              <h3 className="font-semibold text-gray-800 dark:text-white mb-3">Descripción Completa</h3>
              <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
                  {selectedAlert.message || selectedAlert.description}
                </p>
              </div>
            </div>

            {selectedAlert.related_entity && (
              <div className="mb-6">
                <h3 className="font-semibold text-gray-800 dark:text-white mb-3">Entidad Relacionada</h3>
                <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Tipo: {selectedAlert.related_entity.type}
                  </p>
                  {selectedAlert.related_entity.id && (
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      ID: {selectedAlert.related_entity.id}
                    </p>
                  )}
                </div>
              </div>
            )}

            {selectedAlert.action_results && (
              <div className="mb-6">
                <h3 className="font-semibold text-gray-800 dark:text-white mb-3">Resultados de la Acción</h3>
                <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <p className="text-sm text-gray-700 dark:text-gray-300">
                    {selectedAlert.action_results}
                  </p>
                </div>
              </div>
            )}

            <div className="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-700">
              <div className="text-xs text-gray-500 dark:text-gray-400">
                Última actualización: {new Date(selectedAlert.updated_at || selectedAlert.created_at).toLocaleString('es-ES')}
              </div>
              <div className="flex gap-2">
                {!selectedAlert.action_taken && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleActionTaken(selectedAlert._id, e);
                    }}
                    className="px-4 py-2 text-sm bg-brand-500 text-white rounded-lg hover:bg-brand-600 transition-colors"
                  >
                    Marcar Acción Tomada
                  </button>
                )}
                <button
                  onClick={closeModal}
                  className="px-4 py-2 text-sm bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
                >
                  Cerrar
                </button>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </>
  );
}
