import { useEffect, useState } from "react";
import PageMeta from "../../components/common/PageMeta";
import { kpisAPI } from "../../services/api";
import Badge from "../../components/ui/badge/Badge";
import { ArrowUpIcon, ArrowDownIcon } from "../../icons";
import RevenueStatisticsChart from "../../components/charts/RevenueStatisticsChart";

export default function KPIs() {
  const [kpis, setKpis] = useState<any[]>([]);
  const [summary, setSummary] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    category: '',
    period: 'monthly',
  });

  useEffect(() => {
    fetchKPIs();
  }, [filters]);

  const fetchKPIs = async () => {
    try {
      const [kpisRes, summaryRes] = await Promise.all([
        kpisAPI.getAll({ ...filters, limit: 100 }),
        kpisAPI.getSummary(filters.period),
      ]);
      setKpis(kpisRes.kpis || []);
      setSummary(summaryRes.summary || []);
    } catch (error) {
      console.error("Error cargando KPIs:", error);
    } finally {
      setLoading(false);
    }
  };

  const getCategoryLabel = (category: string) => {
    const labels: Record<string, string> = {
      precio_vo: 'Precio VO',
      stock: 'Stock',
      financiacion: 'Financiación',
      competencia: 'Competencia',
      ventas: 'Ventas',
    };
    return labels[category] || category;
  };

  return (
    <>
      <PageMeta
        title="KPIs - AutoMarket Intelligence"
        description="Indicadores clave de rendimiento del mercado"
      />
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
            Indicadores Clave (KPIs)
          </h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Monitoreo de precios, stock y financiación
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4">
          <select
            value={filters.category}
            onChange={(e) => setFilters({ ...filters, category: e.target.value })}
            className="px-4 py-2 border border-gray-300 rounded-lg dark:border-gray-700 dark:bg-gray-800 dark:text-white"
          >
            <option value="">Todas las categorías</option>
            <option value="precio_vo">Precio VO</option>
            <option value="stock">Stock</option>
            <option value="financiacion">Financiación</option>
            <option value="competencia">Competencia</option>
            <option value="ventas">Ventas</option>
          </select>
          <select
            value={filters.period}
            onChange={(e) => setFilters({ ...filters, period: e.target.value })}
            className="px-4 py-2 border border-gray-300 rounded-lg dark:border-gray-700 dark:bg-gray-800 dark:text-white"
          >
            <option value="daily">Diario</option>
            <option value="weekly">Semanal</option>
            <option value="monthly">Mensual</option>
            <option value="quarterly">Trimestral</option>
            <option value="yearly">Anual</option>
          </select>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-gray-500 dark:text-gray-400">Cargando KPIs...</div>
          </div>
        ) : (
          <>
            {/* Summary Cards */}
            {summary.length > 0 && (
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
                {summary.map((item: any, index: number) => (
                  <div
                    key={index}
                    className="p-6 border border-gray-200 rounded-lg dark:border-gray-700 bg-white dark:bg-white/[0.03]"
                  >
                    <div className="text-sm text-gray-500 dark:text-gray-400 mb-2">
                      {getCategoryLabel(item.category)}
                    </div>
                    <div className="text-3xl font-bold text-gray-800 dark:text-white mb-2">
                      {item.current?.toLocaleString() || '0'}
                    </div>
                    <div className="flex items-center gap-2">
                      {item.trend === 'up' ? (
                        <Badge color="success" size="sm">
                          <ArrowUpIcon className="w-3 h-3" />
                          ↑
                        </Badge>
                      ) : item.trend === 'down' ? (
                        <Badge color="error" size="sm">
                          <ArrowDownIcon className="w-3 h-3" />
                          ↓
                        </Badge>
                      ) : (
                        <Badge color="info" size="sm">→</Badge>
                      )}
                      <span className="text-xs text-gray-500 dark:text-gray-400">
                        Promedio: {item.average?.toFixed(0) || '0'}
                      </span>
                    </div>
                    <div className="mt-2 text-xs text-gray-500 dark:text-gray-400">
                      Min: {item.min?.toLocaleString() || '0'} | Max: {item.max?.toLocaleString() || '0'}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Detailed KPIs Table */}
            <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] sm:p-6">
              <h2 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">
                Detalle de KPIs
              </h2>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200 dark:border-gray-700">
                      <th className="text-left py-3 px-4 text-sm font-medium text-gray-700 dark:text-gray-300">
                        Nombre
                      </th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-gray-700 dark:text-gray-300">
                        Categoría
                      </th>
                      <th className="text-right py-3 px-4 text-sm font-medium text-gray-700 dark:text-gray-300">
                        Valor
                      </th>
                      <th className="text-right py-3 px-4 text-sm font-medium text-gray-700 dark:text-gray-300">
                        Anterior
                      </th>
                      <th className="text-center py-3 px-4 text-sm font-medium text-gray-700 dark:text-gray-300">
                        Tendencia
                      </th>
                      <th className="text-right py-3 px-4 text-sm font-medium text-gray-700 dark:text-gray-300">
                        Cambio %
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {kpis.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="text-center py-8 text-gray-500 dark:text-gray-400">
                          No hay KPIs disponibles
                        </td>
                      </tr>
                    ) : (
                      kpis.map((kpi) => (
                        <tr
                          key={kpi._id}
                          className="border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800/50"
                        >
                          <td className="py-3 px-4 text-sm text-gray-800 dark:text-white">
                            {kpi.name}
                          </td>
                          <td className="py-3 px-4 text-sm text-gray-600 dark:text-gray-400">
                            {getCategoryLabel(kpi.category)}
                          </td>
                          <td className="py-3 px-4 text-sm text-right font-medium text-gray-800 dark:text-white">
                            {kpi.value?.toLocaleString() || '0'} {kpi.unit}
                          </td>
                          <td className="py-3 px-4 text-sm text-right text-gray-600 dark:text-gray-400">
                            {kpi.previous_value?.toLocaleString() || '-'}
                          </td>
                          <td className="py-3 px-4 text-center">
                            {kpi.trend === 'up' ? (
                              <Badge color="success" size="sm">
                                <ArrowUpIcon className="w-3 h-3" />
                              </Badge>
                            ) : kpi.trend === 'down' ? (
                              <Badge color="error" size="sm">
                                <ArrowDownIcon className="w-3 h-3" />
                              </Badge>
                            ) : (
                              <Badge color="info" size="sm">→</Badge>
                            )}
                          </td>
                          <td className="py-3 px-4 text-sm text-right">
                            {kpi.change_percentage !== undefined
                              ? `${kpi.change_percentage > 0 ? '+' : ''}${kpi.change_percentage.toFixed(2)}%`
                              : '-'}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </div>
    </>
  );
}
