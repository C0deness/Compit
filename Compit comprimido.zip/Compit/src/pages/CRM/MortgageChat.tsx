import { useState, useRef, useEffect } from "react";
import PageMeta from "../../components/common/PageMeta";
import { aiAPI } from "../../services/api";
import Button from "../../components/ui/button/Button";
import Badge from "../../components/ui/badge/Badge";
import Alert from "../../components/ui/alert/Alert";
import { ChatIcon, PaperPlaneIcon, BoltIcon, UserCircleIcon } from "../../icons";

export default function MortgageChat() {
  const [messages, setMessages] = useState<Array<{ role: string; content: string }>>([
    {
      role: "assistant",
      content:
        "¡Hola! 👋 Soy tu Asistente Rockit, potenciado por inteligencia artificial. Puedo ayudarte con información sobre préstamos hipotecarios, tasas de interés, documentación requerida, procesos de cierre y mucho más. ¿En qué puedo asistirte hoy?",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMessage = input.trim();
    setInput("");
    setMessages((prev) => [...prev, { role: "user", content: userMessage }]);
    setLoading(true);

    try {
      const conversationHistory = messages.map((m) => ({
        role: m.role === "user" ? "user" : "assistant",
        content: m.content,
      }));

      const response = await aiAPI.mortgageChat(userMessage, conversationHistory);
      setMessages((prev) => [...prev, { role: "assistant", content: response.response }]);
    } catch (error) {
      console.error("Error en chat:", error);
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: "Lo siento, hubo un error al procesar tu mensaje. Por favor intenta de nuevo.",
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const suggestedQuestions = [
    "¿Qué documentos necesito para una hipoteca?",
    "¿Cuál es la diferencia entre tasa fija y variable?",
    "¿Cuánto tiempo tarda el proceso de aprobación?",
    "¿Qué es un pre-aprobación?",
  ];

  return (
    <>
      <PageMeta title="Asistente Rockit - RockIt" />
      <div className="space-y-6">
        {/* Header */}
        <div>
          <div className="flex items-center gap-2 mb-2">
            <ChatIcon className="w-6 h-6 text-brand-500 dark:text-brand-400" />
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
              Asistente Rockit
            </h1>
            <Badge color="info" variant="light" size="sm" startIcon={<BoltIcon className="w-3 h-3" />}>
              Potenciado por IA
            </Badge>
          </div>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Asistente inteligente especializado en asesoramiento hipotecario
          </p>
        </div>

        {/* AI Feature Alert */}
        <Alert
          variant="info"
          title="Asistente Inteligente con IA"
          message="Este chatbot utiliza inteligencia artificial avanzada para proporcionar respuestas precisas y personalizadas sobre temas hipotecarios. Puede ayudarte con tasas de interés, documentación, procesos de aprobación y más."
        />

        {/* Chat Container */}
        <div className="flex flex-col h-[calc(100vh-300px)] min-h-[600px] bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
          {/* Chat Header */}
          <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-10 h-10 rounded-full bg-brand-100 dark:bg-brand-500/20">
                <ChatIcon className="w-5 h-5 text-brand-500 dark:text-brand-400" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-800 dark:text-white">
                  Asistente Rockit
                </h3>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  Asistente IA • En línea
                </p>
              </div>
            </div>
            <Badge color="success" variant="light" size="sm">
              En línea
            </Badge>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50/50 dark:bg-gray-900/30">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div className={`flex gap-3 max-w-[80%] ${message.role === "user" ? "flex-row-reverse" : "flex-row"}`}>
                  {/* Avatar */}
                  <div className={`flex-shrink-0 ${message.role === "user" ? "order-2" : ""}`}>
                    {message.role === "user" ? (
                      <div className="flex items-center justify-center w-8 h-8 rounded-full bg-brand-500">
                        <UserCircleIcon className="w-5 h-5 text-white" />
                      </div>
                    ) : (
                      <div className="flex items-center justify-center w-8 h-8 rounded-full bg-brand-100 dark:bg-brand-500/20">
                        <BoltIcon className="w-5 h-5 text-brand-500 dark:text-brand-400" />
                      </div>
                    )}
                  </div>

                  {/* Message Bubble */}
                  <div
                    className={`rounded-lg p-4 ${
                      message.role === "user"
                        ? "bg-brand-500 text-white rounded-tr-none"
                        : "bg-white text-gray-800 dark:bg-gray-700 dark:text-white rounded-tl-none border border-gray-200 dark:border-gray-600"
                    }`}
                  >
                    <p className="text-sm whitespace-pre-wrap leading-relaxed">{message.content}</p>
                  </div>
                </div>
              </div>
            ))}

            {/* Loading Indicator */}
            {loading && (
              <div className="flex justify-start">
                <div className="flex gap-3">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-brand-100 dark:bg-brand-500/20">
                    <BoltIcon className="w-5 h-5 text-brand-500 dark:text-brand-400" />
                  </div>
                  <div className="bg-white rounded-lg p-4 border border-gray-200 dark:bg-gray-700 dark:border-gray-600">
                    <div className="flex space-x-2">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div
                        className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                        style={{ animationDelay: "0.2s" }}
                      ></div>
                      <div
                        className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                        style={{ animationDelay: "0.4s" }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Suggested Questions (only show when no messages or first interaction) */}
            {messages.length === 1 && !loading && (
              <div className="mt-4">
                <p className="text-xs font-medium text-gray-500 dark:text-gray-400 mb-2">
                  Preguntas sugeridas:
                </p>
                <div className="flex flex-wrap gap-2">
                  {suggestedQuestions.map((question, index) => (
                    <button
                      key={index}
                      onClick={() => setInput(question)}
                      className="px-3 py-1.5 text-xs font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700 dark:hover:bg-gray-700 transition-colors"
                    >
                      {question}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <form onSubmit={handleSend} className="p-4 border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Escribe tu pregunta sobre hipotecas..."
                className="flex-1 h-11 rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-3 focus:border-brand-300 focus:ring-brand-500/20 dark:bg-gray-900 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800"
                disabled={loading}
              />
              <Button
                type="submit"
                disabled={loading || !input.trim()}
                size="sm"
                startIcon={<PaperPlaneIcon className="w-4 h-4" />}
              >
                Enviar
              </Button>
            </div>
            <p className="mt-2 text-xs text-gray-500 dark:text-gray-400 text-center">
              Respuestas generadas por IA • Puede contener errores
            </p>
          </form>
        </div>
      </div>
    </>
  );
}
