import { useEffect, useState } from "react";
import PageMeta from "../../components/common/PageMeta";
import { propertiesAPI } from "../../services/api";
import Button from "../../components/ui/button/Button";
import Badge from "../../components/ui/badge/Badge";
import { PlusIcon, PencilIcon, TrashBinIcon, BoxIcon, DollarLineIcon } from "../../icons";
import { useModal } from "../../hooks/useModal";
import { Modal } from "../../components/ui/modal";
import InputField from "../../components/form/input/InputField";

export default function Properties() {
  const [properties, setProperties] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState({ search: "", type: "", status: "" });
  const { isOpen, openModal, closeModal } = useModal();
  const [editingProperty, setEditingProperty] = useState<any>(null);

  useEffect(() => {
    loadProperties();
  }, [filter]);

  const loadProperties = async () => {
    setLoading(true);
    try {
      const data = await propertiesAPI.getAll();
      let filtered = data;
      
      if (filter.search) {
        filtered = filtered.filter((p: any) =>
          p.title?.toLowerCase().includes(filter.search.toLowerCase()) ||
          p.address?.toLowerCase().includes(filter.search.toLowerCase()) ||
          p.city?.toLowerCase().includes(filter.search.toLowerCase())
        );
      }
      if (filter.type) {
        filtered = filtered.filter((p: any) => p.type === filter.type);
      }
      if (filter.status) {
        filtered = filtered.filter((p: any) => p.status === filter.status);
      }
      
      setProperties(filtered);
    } catch (error) {
      console.error("Error cargando propiedades:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("¿Estás seguro de eliminar esta propiedad?")) {
      try {
        await propertiesAPI.delete(id);
        loadProperties();
      } catch (error) {
        console.error("Error eliminando propiedad:", error);
      }
    }
  };

  const getTypeLabel = (type: string) => {
    const types: Record<string, string> = {
      house: "Casa",
      apartment: "Apartamento",
      condo: "Condominio",
      land: "Terreno",
    };
    return types[type] || type;
  };

  return (
    <>
      <PageMeta title="Propiedades - RockIt" />
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
              Gestión de Propiedades
            </h1>
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              Administra tus listings inmobiliarios
            </p>
          </div>
          <Button onClick={openModal} size="sm" startIcon={<PlusIcon className="w-4 h-4" />}>
            Nueva Propiedad
          </Button>
        </div>

        {/* Filters */}
        <div className="flex flex-col gap-4 sm:flex-row">
          <div className="flex-1">
            <InputField
              type="text"
              placeholder="Buscar por título, dirección o ciudad..."
              value={filter.search}
              onChange={(e) => setFilter({ ...filter, search: e.target.value })}
            />
          </div>
          <div className="sm:w-48">
            <select
              value={filter.type}
              onChange={(e) => setFilter({ ...filter, type: e.target.value })}
              className="h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-3 focus:border-brand-300 focus:ring-brand-500/20 dark:bg-gray-900 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800"
            >
              <option value="">Todos los tipos</option>
              <option value="house">Casa</option>
              <option value="apartment">Apartamento</option>
              <option value="condo">Condominio</option>
              <option value="land">Terreno</option>
            </select>
          </div>
          <div className="sm:w-48">
            <select
              value={filter.status}
              onChange={(e) => setFilter({ ...filter, status: e.target.value })}
              className="h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-3 focus:border-brand-300 focus:ring-brand-500/20 dark:bg-gray-900 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800"
            >
              <option value="">Todos los estados</option>
              <option value="available">Disponible</option>
              <option value="pending">Pendiente</option>
              <option value="sold">Vendida</option>
            </select>
          </div>
        </div>

        {/* Properties Grid */}
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-gray-500 dark:text-gray-400">Cargando propiedades...</div>
          </div>
        ) : properties.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
            <BoxIcon className="w-16 h-16 text-gray-400 mb-4" />
            <p className="text-gray-500 dark:text-gray-400 mb-4">No hay propiedades registradas</p>
            <Button onClick={openModal} size="sm" variant="outline">
              <PlusIcon className="w-4 h-4" />
              Crear primera propiedad
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            {properties.map((property) => (
              <div
                key={property.id}
                className="overflow-hidden bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow"
              >
                {/* Image Placeholder */}
                <div className="h-48 bg-gradient-to-br from-brand-100 to-brand-200 dark:from-brand-900/30 dark:to-brand-800/30 flex items-center justify-center">
                  <BoxIcon className="w-16 h-16 text-brand-500 dark:text-brand-400" />
                </div>

                <div className="p-6">
                  {/* Header */}
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-gray-800 dark:text-white line-clamp-1">
                        {property.title}
                      </h3>
                      <p className="mt-1 text-sm text-gray-500 dark:text-gray-400 line-clamp-1">
                        {property.address}, {property.city}
                      </p>
                    </div>
                  </div>

                  {/* Price */}
                  <div className="flex items-center gap-2 mb-4">
                    <DollarLineIcon className="w-5 h-5 text-brand-500 dark:text-brand-400" />
                    <p className="text-2xl font-bold text-brand-500 dark:text-brand-400">
                      €{Number(property.price).toLocaleString()}
                    </p>
                  </div>

                  {/* Details */}
                  <div className="flex items-center gap-4 mb-4 text-sm text-gray-600 dark:text-gray-400">
                    <div className="flex items-center gap-1">
                      <span>🛏️</span>
                      <span>{property.bedrooms || "-"} hab</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span>🚿</span>
                      <span>{property.bathrooms || "-"} baños</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span>📐</span>
                      <span>{property.area_sqft ? `${property.area_sqft} sqft` : "-"}</span>
                    </div>
                  </div>

                  {/* Badges */}
                  <div className="flex items-center justify-between mb-4">
                    <Badge
                      color={property.status === "available" ? "success" : property.status === "pending" ? "warning" : "info"}
                      variant="light"
                      size="sm"
                    >
                      {property.status === "available" ? "Disponible" : property.status === "pending" ? "Pendiente" : "Vendida"}
                    </Badge>
                    <Badge color="info" variant="light" size="sm">
                      {getTypeLabel(property.type)}
                    </Badge>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center justify-end gap-2 pt-4 border-t border-gray-200 dark:border-gray-700">
                    <button
                      onClick={() => {
                        setEditingProperty(property);
                        openModal();
                      }}
                      className="p-2 text-gray-600 transition-colors rounded-lg hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700"
                      title="Editar"
                    >
                      <PencilIcon className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => handleDelete(property.id)}
                      className="p-2 text-error-500 transition-colors rounded-lg hover:bg-error-50 dark:hover:bg-error-500/20"
                      title="Eliminar"
                    >
                      <TrashBinIcon className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <PropertyModal
        isOpen={isOpen}
        onClose={() => {
          closeModal();
          setEditingProperty(null);
        }}
        onSave={() => {
          loadProperties();
          closeModal();
          setEditingProperty(null);
        }}
        property={editingProperty}
      />
    </>
  );
}

function PropertyModal({
  isOpen,
  onClose,
  onSave,
  property,
}: {
  isOpen: boolean;
  onClose: () => void;
  onSave: () => void;
  property?: any;
}) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    type: "house",
    price: "",
    address: "",
    city: "",
    bedrooms: "",
    bathrooms: "",
    areaSqft: "",
    status: "available",
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (property) {
      setFormData({
        title: property.title || "",
        description: property.description || "",
        type: property.type || "house",
        price: property.price || "",
        address: property.address || "",
        city: property.city || "",
        bedrooms: property.bedrooms || "",
        bathrooms: property.bathrooms || "",
        areaSqft: property.area_sqft || "",
        status: property.status || "available",
      });
    } else {
      setFormData({
        title: "",
        description: "",
        type: "house",
        price: "",
        address: "",
        city: "",
        bedrooms: "",
        bathrooms: "",
        areaSqft: "",
        status: "available",
      });
    }
  }, [property, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (property) {
        await propertiesAPI.update(property.id, formData);
      } else {
        await propertiesAPI.create(formData);
      }
      onSave();
    } catch (error) {
      console.error("Error guardando propiedad:", error);
      alert("Error al guardar propiedad");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <div className="p-6 sm:p-8">
        <h2 className="mb-6 text-2xl font-semibold text-gray-800 dark:text-white">
          {property ? "Editar Propiedad" : "Nueva Propiedad"}
        </h2>
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              Título *
            </label>
            <InputField
              type="text"
              required
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            />
          </div>
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <div>
              <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                Tipo *
              </label>
              <select
                required
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                className="h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-3 focus:border-brand-300 focus:ring-brand-500/20 dark:bg-gray-900 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800"
              >
                <option value="house">Casa</option>
                <option value="apartment">Apartamento</option>
                <option value="condo">Condominio</option>
                <option value="land">Terreno</option>
              </select>
            </div>
            <div>
              <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                Precio *
              </label>
              <InputField
                type="number"
                required
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: e.target.value })}
              />
            </div>
          </div>
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <div>
              <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                Dirección
              </label>
              <InputField
                type="text"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              />
            </div>
            <div>
              <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                Ciudad
              </label>
              <InputField
                type="text"
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
              />
            </div>
          </div>
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-3">
            <div>
              <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                Habitaciones
              </label>
              <InputField
                type="number"
                value={formData.bedrooms}
                onChange={(e) => setFormData({ ...formData, bedrooms: e.target.value })}
              />
            </div>
            <div>
              <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                Baños
              </label>
              <InputField
                type="number"
                step="0.5"
                value={formData.bathrooms}
                onChange={(e) => setFormData({ ...formData, bathrooms: e.target.value })}
              />
            </div>
            <div>
              <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                Área (sqft)
              </label>
              <InputField
                type="number"
                value={formData.areaSqft}
                onChange={(e) => setFormData({ ...formData, areaSqft: e.target.value })}
              />
            </div>
          </div>
          <div>
            <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              Estado
            </label>
            <select
              value={formData.status}
              onChange={(e) => setFormData({ ...formData, status: e.target.value })}
              className="h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-3 focus:border-brand-300 focus:ring-brand-500/20 dark:bg-gray-900 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800"
            >
              <option value="available">Disponible</option>
              <option value="pending">Pendiente</option>
              <option value="sold">Vendida</option>
            </select>
          </div>
          <div>
            <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              Descripción
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={4}
              className="h-auto w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-3 focus:border-brand-300 focus:ring-brand-500/20 dark:bg-gray-900 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800"
            />
          </div>
          <div className="flex justify-end gap-3 pt-6 border-t border-gray-200 dark:border-gray-700">
            <Button type="button" onClick={onClose} variant="outline" size="md">
              Cancelar
            </Button>
            <Button type="submit" size="md" disabled={loading}>
              {loading ? "Guardando..." : "Guardar"}
            </Button>
          </div>
        </form>
      </div>
    </Modal>
  );
}
