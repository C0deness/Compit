import { useState } from "react";
import PageMeta from "../../components/common/PageMeta";
import Button from "../../components/ui/button/Button";
import Badge from "../../components/ui/badge/Badge";
import Alert from "../../components/ui/alert/Alert";
import { FileIcon, DownloadIcon, BoltIcon, UserIcon, BoxIcon, DollarLineIcon, TableIcon } from "../../icons";
import { reportsAPI } from "../../services/api";
import InputField from "../../components/form/input/InputField";

export default function Reports() {
  const [loading, setLoading] = useState(false);
  const [reportType, setReportType] = useState<string>("");
  const [filters, setFilters] = useState({
    status: "",
    type: "",
    startDate: "",
    endDate: "",
  });

  const exportToCSV = (data: any[], filename: string) => {
    if (!data || data.length === 0) {
      alert("No hay datos para exportar");
      return;
    }

    // Obtener headers
    const headers = Object.keys(data[0]);
    
    // Crear CSV
    const csvContent = [
      headers.join(","),
      ...data.map(row => 
        headers.map(header => {
          const value = row[header] || "";
          // Escapar comillas y envolver en comillas si contiene comas
          return value.toString().includes(",") || value.toString().includes('"')
            ? `"${value.toString().replace(/"/g, '""')}"`
            : value;
        }).join(",")
      )
    ].join("\n");

    // Crear blob y descargar
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `${filename}_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportToJSON = (data: any, filename: string) => {
    const jsonContent = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonContent], { type: "application/json" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `${filename}_${new Date().toISOString().split('T')[0]}.json`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleGenerateReport = async (type: string, format: "csv" | "json" | "pdf") => {
    setLoading(true);
    try {
      // Generar PDFs profesionales
      if (format === "pdf") {
        if (type === "monthly") {
          const currentDate = new Date();
          const month = currentDate.getMonth() + 1;
          const year = currentDate.getFullYear();
          await reportsAPI.generateMonthlyPDF(month, year);
        } else if (type === "consolidated") {
          await reportsAPI.generateConsolidatedPDF(filters.startDate, filters.endDate);
        }
        setLoading(false);
        return;
      }

      // Generar CSV/JSON para otros tipos
      let reportData;
      
      switch (type) {
        case "contacts":
          reportData = await reportsAPI.getContactsReport(filters);
          break;
        case "deals":
          reportData = await reportsAPI.getDealsReport(filters);
          break;
        case "properties":
          reportData = await reportsAPI.getPropertiesReport(filters);
          break;
        case "financing":
          reportData = await reportsAPI.getFinancingReport(filters);
          break;
        default:
          throw new Error("Tipo de reporte no válido");
      }

      if (format === "csv" && reportData.data) {
        exportToCSV(reportData.data, type);
      } else {
        exportToJSON(reportData, type);
      }
    } catch (error) {
      console.error("Error generando reporte:", error);
      alert("Error al generar el reporte. Por favor, intenta nuevamente.");
    } finally {
      setLoading(false);
    }
  };

  const reportTypes = [
    {
      id: "monthly",
      name: "Reporte Mensual",
      description: "PDF profesional con estadísticas, KPIs y métricas del mes",
      icon: FileIcon,
      color: "primary",
      pdfOnly: true,
    },
    {
      id: "consolidated",
      name: "Reporte Consolidado",
      description: "PDF profesional con resumen ejecutivo y estadísticas del período",
      icon: TableIcon,
      color: "brand",
      pdfOnly: true,
    },
    {
      id: "contacts",
      name: "Contactos/Leads",
      description: "Exportar datos de contactos (CSV/JSON)",
      icon: UserIcon,
      color: "info",
    },
    {
      id: "deals",
      name: "Transacciones",
      description: "Exportar datos de transacciones (CSV/JSON)",
      icon: FileIcon,
      color: "success",
    },
    {
      id: "properties",
      name: "Propiedades",
      description: "Exportar datos de propiedades (CSV/JSON)",
      icon: BoxIcon,
      color: "warning",
    },
    {
      id: "financing",
      name: "Financiación",
      description: "Exportar datos de financiación (CSV/JSON)",
      icon: DollarLineIcon,
      color: "brand",
    },
  ];

  return (
    <>
      <PageMeta title="Reportes y Exportación - RockIt" />
      <div className="space-y-6">
        {/* Header */}
        <div>
          <div className="flex items-center gap-2 mb-2">
            <FileIcon className="w-6 h-6 text-brand-500 dark:text-brand-400" />
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
              Reportes y Exportación
            </h1>
          </div>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Genera y exporta reportes de tus datos en diferentes formatos
          </p>
        </div>

        {/* AI Feature Alert */}
        <Alert
          variant="info"
          title="Reportes Profesionales para Presentaciones"
          message="Genera PDFs profesionales listos para presentar en reuniones de final de mes. Incluyen estadísticas, KPIs, métricas y análisis detallados de tu negocio inmobiliario. También puedes exportar datos en CSV o JSON para análisis avanzado."
        />

        {/* Filters */}
        <div className="p-6 bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
          <h2 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">
            Filtros de Período (Para Reportes Consolidados)
          </h2>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
            <div>
              <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                Estado
              </label>
              <InputField
                type="text"
                value={filters.status}
                onChange={(e) => setFilters({ ...filters, status: e.target.value })}
                placeholder="Ej: caliente, closed"
              />
            </div>
            <div>
              <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                Tipo
              </label>
              <InputField
                type="text"
                value={filters.type}
                onChange={(e) => setFilters({ ...filters, type: e.target.value })}
                placeholder="Ej: house, conventional"
              />
            </div>
            <div>
              <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                Fecha Inicio
              </label>
              <InputField
                type="date"
                value={filters.startDate}
                onChange={(e) => setFilters({ ...filters, startDate: e.target.value })}
              />
            </div>
            <div>
              <label className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                Fecha Fin
              </label>
              <InputField
                type="date"
                value={filters.endDate}
                onChange={(e) => setFilters({ ...filters, endDate: e.target.value })}
              />
            </div>
          </div>
        </div>

        {/* Report Types */}
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {reportTypes.map((report) => {
            const IconComponent = report.icon;
            return (
              <div
                key={report.id}
                className="p-6 bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className={`flex items-center justify-center w-12 h-12 rounded-lg bg-${report.color}-100 dark:bg-${report.color}-500/20`}>
                    <IconComponent className={`w-6 h-6 text-${report.color}-500 dark:text-${report.color}-400`} />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-1">
                      {report.name}
                    </h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {report.description}
                    </p>
                  </div>
                </div>

                {report.pdfOnly ? (
                  <Button
                    onClick={() => handleGenerateReport(report.id, "pdf")}
                    disabled={loading}
                    size="sm"
                    className="w-full"
                    startIcon={<DownloadIcon className="w-4 h-4" />}
                  >
                    {loading ? "Generando PDF..." : "Generar PDF Profesional"}
                  </Button>
                ) : (
                  <div className="flex gap-2">
                    <Button
                      onClick={() => handleGenerateReport(report.id, "csv")}
                      disabled={loading}
                      size="sm"
                      variant="outline"
                      className="flex-1"
                      startIcon={<DownloadIcon className="w-4 h-4" />}
                    >
                      CSV
                    </Button>
                    <Button
                      onClick={() => handleGenerateReport(report.id, "json")}
                      disabled={loading}
                      size="sm"
                      variant="outline"
                      className="flex-1"
                      startIcon={<DownloadIcon className="w-4 h-4" />}
                    >
                      JSON
                    </Button>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {loading && (
          <div className="flex items-center justify-center py-8">
            <div className="text-gray-500 dark:text-gray-400">Generando reporte...</div>
          </div>
        )}
      </div>
    </>
  );
}

