import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router";
import PageMeta from "../../components/common/PageMeta";
import { dealsAPI, contactsAPI } from "../../services/api";
import Button from "../../components/ui/button/Button";
import Badge from "../../components/ui/badge/Badge";
import Alert from "../../components/ui/alert/Alert";
import DocumentDropZone from "../../components/CRM/DocumentDropZone";
import { PlusIcon, FileIcon, DollarLineIcon, UserIcon, CheckCircleIcon, BoltIcon } from "../../icons";
import InputField from "../../components/form/input/InputField";

export default function Deals() {
  const [deals, setDeals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState({ search: "", status: "" });
  const [showDropZone, setShowDropZone] = useState(false);
  const [createdContacts, setCreatedContacts] = useState<any[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    loadDeals();
  }, [filter]);

  const loadDeals = async () => {
    setLoading(true);
    try {
      const data = await dealsAPI.getAll();
      let filtered = data;
      
      if (filter.search) {
        filtered = filtered.filter((d: any) =>
          d.property_title?.toLowerCase().includes(filter.search.toLowerCase()) ||
          d.contact_first_name?.toLowerCase().includes(filter.search.toLowerCase()) ||
          d.contact_last_name?.toLowerCase().includes(filter.search.toLowerCase())
        );
      }
      if (filter.status) {
        filtered = filtered.filter((d: any) => d.status === filter.status);
      }
      
      setDeals(filtered);
    } catch (error) {
      console.error("Error cargando deals:", error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, { color: "info" | "success" | "warning" | "light"; label: string }> = {
      in_progress: { color: "info", label: "En Progreso" },
      closed: { color: "success", label: "Cerrado" },
      pending: { color: "warning", label: "Pendiente" },
      cancelled: { color: "light", label: "Cancelado" },
    };
    const config = statusMap[status] || statusMap.pending;
    return (
      <Badge color={config.color} variant="light" size="sm">
        {config.label}
      </Badge>
    );
  };

  const stats = {
    total: deals.length,
    inProgress: deals.filter((d) => d.status === "in_progress").length,
    closed: deals.filter((d) => d.status === "closed").length,
    totalValue: deals.reduce((sum, d) => sum + (Number(d.offer_price) || 0), 0),
  };

  return (
    <>
      <PageMeta title="Transacciones - RockIt" />
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <FileIcon className="w-6 h-6 text-brand-500 dark:text-brand-400" />
              <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
                Deal Room Inteligente
              </h1>
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Gestiona tus transacciones y documentación con validación automática
            </p>
          </div>
          <Button size="sm" startIcon={<PlusIcon className="w-4 h-4" />}>
            Nueva Transacción
          </Button>
        </div>

        {/* AI Feature Alert */}
        <Alert
          variant="info"
          title="Extracción Automática de Datos con IA"
          message="Arrastra documentos (DNI, estados de cuenta, comprobantes) y la IA extraerá automáticamente los datos del cliente, consultará ASNEF para verificar si es deudor en mora, creará su ficha completa y lo agregará al sistema como cliente."
        />

        {/* Document Drop Zone Section */}
        <div className="p-6 bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-lg font-semibold text-gray-800 dark:text-white">
                Extracción Automática de Datos
              </h2>
              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                Arrastra documentos para extraer datos y crear clientes automáticamente
              </p>
            </div>
            <Button
              size="sm"
              variant={showDropZone ? "outline" : "primary"}
              onClick={() => setShowDropZone(!showDropZone)}
              startIcon={<FileIcon className="w-4 h-4" />}
            >
              {showDropZone ? "Ocultar" : "Subir Documentos"}
            </Button>
          </div>

          {showDropZone && (
            <DocumentDropZone
              onDocumentProcessed={(result) => {
                if (result.contactCreated) {
                  setCreatedContacts((prev) => [...prev, result.contactCreated]);
                  // Opcional: redirigir después de 3 segundos
                  setTimeout(() => {
                    // No redirigir automáticamente, solo mostrar el resultado
                  }, 3000);
                }
              }}
              onError={(error) => {
                console.error("Error procesando documento:", error);
                alert(`Error al procesar documento: ${error}`);
              }}
            />
          )}

          {/* Mostrar clientes creados recientemente */}
          {createdContacts.length > 0 && (
            <div className="mt-4 p-4 bg-success-50 dark:bg-success-900/20 rounded-lg border border-success-200 dark:border-success-800">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircleIcon className="w-5 h-5 text-success-500 dark:text-success-400" />
                <h3 className="font-semibold text-success-800 dark:text-success-300">
                  Clientes Creados Automáticamente ({createdContacts.length})
                </h3>
              </div>
              <div className="space-y-2">
                {createdContacts.map((contact, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-2 bg-white dark:bg-gray-800 rounded"
                  >
                    <div>
                      <p className="font-medium text-gray-800 dark:text-white">
                        {contact.name}
                      </p>
                      {contact.email && (
                        <p className="text-sm text-gray-600 dark:text-gray-400">{contact.email}</p>
                      )}
                    </div>
                    <div className="flex flex-col gap-2 items-end">
                      <div className="flex items-center gap-2">
                        <Badge color="success" variant="light" size="sm">
                          Score: {contact.leadScore}
                        </Badge>
                        {contact.asnef && contact.asnef.checked && (
                          <Badge 
                            color={contact.asnef.has_debt 
                              ? (contact.asnef.risk_level === 'very_high' || contact.asnef.risk_level === 'high' ? 'error' : 'warning')
                              : 'success'} 
                            variant="light" 
                            size="sm"
                          >
                            {contact.asnef.has_debt 
                              ? `⚠️ ASNEF: ${contact.asnef.total_debt ? `€${Number(contact.asnef.total_debt).toLocaleString()}` : 'Deuda'}`
                              : '✓ ASNEF: Sin deudas'}
                          </Badge>
                        )}
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => navigate("/contacts")}
                      >
                        Ver Cliente
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
          <div className="p-4 bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                  Total Transacciones
                </p>
                <p className="mt-1 text-2xl font-bold text-gray-900 dark:text-white">
                  {stats.total}
                </p>
              </div>
              <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-brand-100 dark:bg-brand-500/20">
                <FileIcon className="w-6 h-6 text-brand-500 dark:text-brand-400" />
              </div>
            </div>
          </div>

          <div className="p-4 bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                  En Progreso
                </p>
                <p className="mt-1 text-2xl font-bold text-info-600 dark:text-info-400">
                  {stats.inProgress}
                </p>
              </div>
              <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-info-100 dark:bg-info-500/20">
                <BoltIcon className="w-6 h-6 text-info-500 dark:text-info-400" />
              </div>
            </div>
          </div>

          <div className="p-4 bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                  Cerradas
                </p>
                <p className="mt-1 text-2xl font-bold text-success-600 dark:text-success-400">
                  {stats.closed}
                </p>
              </div>
              <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-success-100 dark:bg-success-500/20">
                <CheckCircleIcon className="w-6 h-6 text-success-500 dark:text-success-400" />
              </div>
            </div>
          </div>

          <div className="p-4 bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                  Valor Total
                </p>
                <p className="mt-1 text-xl font-bold text-brand-600 dark:text-brand-400">
                  €{stats.totalValue.toLocaleString()}
                </p>
              </div>
              <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-brand-100 dark:bg-brand-500/20">
                <DollarLineIcon className="w-6 h-6 text-brand-500 dark:text-brand-400" />
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col gap-4 sm:flex-row">
          <div className="flex-1">
            <InputField
              type="text"
              placeholder="Buscar por propiedad, cliente o ID de transacción..."
              value={filter.search}
              onChange={(e) => setFilter({ ...filter, search: e.target.value })}
            />
          </div>
          <div className="sm:w-48">
            <select
              value={filter.status}
              onChange={(e) => setFilter({ ...filter, status: e.target.value })}
              className="h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-3 focus:border-brand-300 focus:ring-brand-500/20 dark:bg-gray-900 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800"
            >
              <option value="">Todos los estados</option>
              <option value="in_progress">En Progreso</option>
              <option value="pending">Pendiente</option>
              <option value="closed">Cerrado</option>
              <option value="cancelled">Cancelado</option>
            </select>
          </div>
        </div>

        {/* Deals Grid */}
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-gray-500 dark:text-gray-400">Cargando transacciones...</div>
          </div>
        ) : deals.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
            <FileIcon className="w-16 h-16 text-gray-400 mb-4" />
            <p className="text-gray-500 dark:text-gray-400 mb-4">No hay transacciones registradas</p>
            <Button size="sm" variant="outline">
              <PlusIcon className="w-4 h-4" />
              Crear primera transacción
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
            {deals.map((deal) => (
              <Link
                key={deal.id}
                to={`/deals/${deal.id}`}
                className="block p-6 bg-white rounded-lg shadow-sm dark:bg-gray-800 border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all hover:border-brand-300 dark:hover:border-brand-700"
              >
                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-800 dark:text-white line-clamp-1 mb-1">
                      {deal.property_title || "Sin propiedad asignada"}
                    </h3>
                    <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                      <UserIcon className="w-4 h-4" />
                      <span>
                        {deal.contact_first_name} {deal.contact_last_name}
                      </span>
                    </div>
                  </div>
                  {getStatusBadge(deal.status)}
                </div>

                {/* Price */}
                {deal.offer_price && (
                  <div className="flex items-center gap-2 mb-4 p-3 bg-brand-50 dark:bg-brand-900/20 rounded-lg">
                    <DollarLineIcon className="w-5 h-5 text-brand-500 dark:text-brand-400" />
                    <p className="text-xl font-bold text-brand-600 dark:text-brand-400">
                      €{Number(deal.offer_price).toLocaleString()}
                    </p>
                  </div>
                )}

                {/* Documents */}
                <div className="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-700">
                  <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                    <FileIcon className="w-4 h-4" />
                    <span>
                      {deal.documents?.length || 0} documento{deal.documents?.length !== 1 ? "s" : ""}
                    </span>
                  </div>
                  {deal.documents && deal.documents.length > 0 && (
                    <Badge color="success" variant="light" size="sm">
                      Documentos
                    </Badge>
                  )}
                </div>

                {/* AI Validation Badge */}
                {deal.status === "in_progress" && (
                  <div className="mt-3 pt-3 border-t border-gray-200 dark:border-gray-700">
                    <div className="flex items-center gap-2">
                      <BoltIcon className="w-4 h-4 text-brand-500 dark:text-brand-400" />
                      <span className="text-xs text-gray-600 dark:text-gray-400">
                        Validación IA activa
                      </span>
                    </div>
                  </div>
                )}
              </Link>
            ))}
          </div>
        )}
      </div>
    </>
  );
}
