
import type React from "react";
import { createContext, useState, useContext, useEffect } from "react";

type MockDataContextType = {
  useMockData: boolean;
  toggleMockData: () => void;
};

const MockDataContext = createContext<MockDataContextType | undefined>(undefined);

export const MockDataProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [useMockData, setUseMockData] = useState<boolean>(false);
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    // Cargar preferencia desde localStorage
    const savedMockData = localStorage.getItem("useMockData");
    const initialMockData = savedMockData === "true";

    setUseMockData(initialMockData);
    setIsInitialized(true);
  }, []);

  useEffect(() => {
    if (isInitialized) {
      localStorage.setItem("useMockData", useMockData.toString());
    }
  }, [useMockData, isInitialized]);

  const toggleMockData = () => {
    setUseMockData((prev) => !prev);
  };

  return (
    <MockDataContext.Provider value={{ useMockData, toggleMockData }}>
      {children}
    </MockDataContext.Provider>
  );
};

export const useMockData = () => {
  const context = useContext(MockDataContext);
  if (context === undefined) {
    throw new Error("useMockData must be used within a MockDataProvider");
  }
  return context;
};
