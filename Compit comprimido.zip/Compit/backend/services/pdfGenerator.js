import PDFDocument from 'pdfkit';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Genera un PDF profesional de reporte mensual
 */
export const generateMonthlyReportPDF = async (data, options = {}) => {
  const {
    month,
    year,
    contacts,
    deals,
    properties,
    financings,
    stats,
    userInfo,
  } = data;

  const doc = new PDFDocument({
    size: 'A4',
    margin: 50,
    info: {
      Title: `Reporte Mensual - ${month}/${year}`,
      Author: 'RockIt CRM',
      Subject: 'Reporte de Actividad Inmobiliaria',
    },
  });

  // Contador de páginas manual
  let pageCount = 0;
  
  // Función helper para agregar nueva página con footer
  const addPageWithFooter = () => {
    doc.addPage();
    pageCount++;
    // Agregar footer en la parte inferior
    doc.fontSize(8)
      .fillColor('#9CA3AF')
      .text(
        `Página ${pageCount} | RockIt CRM - Reporte Mensual`,
        50,
        doc.page.height - 30,
        { align: 'center', width: 500 }
      );
  };
  
  // Función helper para agregar pie de página a la página actual
  const addFooter = () => {
    pageCount++;
    doc.fontSize(8)
      .fillColor('#9CA3AF')
      .text(
        `Página ${pageCount} | RockIt CRM - Reporte Mensual`,
        50,
        doc.page.height - 30,
        { align: 'center', width: 500 }
      );
  };

  // Colores corporativos
  const colors = {
    primary: '#465FFF',
    secondary: '#10B981',
    accent: '#F59E0B',
    dark: '#1F2937',
    light: '#F3F4F6',
    text: '#374151',
  };

  // Helper para agregar espacio
  const addSpace = (y) => {
    doc.y += y;
  };

  // Helper para dibujar línea
  const drawLine = (y, width = 500) => {
    doc.moveTo(50, y).lineTo(50 + width, y).stroke(colors.light);
  };

  // Helper para formatear moneda
  const formatCurrency = (amount) => {
    return `€${Number(amount).toLocaleString('es-ES', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  // Helper para formatear porcentaje
  const formatPercent = (value) => {
    return `${Number(value).toFixed(1)}%`;
  };

  // Portada
  doc.fillColor(colors.primary)
    .fontSize(32)
    .font('Helvetica-Bold')
    .text('RockIt CRM', 50, 50, { align: 'center' });

  doc.fillColor(colors.text)
    .fontSize(20)
    .font('Helvetica')
    .text('Reporte Mensual de Actividad', 50, 100, { align: 'center' });

  doc.fillColor(colors.dark)
    .fontSize(16)
    .text(`${month} ${year}`, 50, 130, { align: 'center' });

  if (userInfo) {
    doc.fontSize(12)
      .fillColor(colors.text)
      .text(`Generado para: ${userInfo.first_name || ''} ${userInfo.last_name || ''}`, 50, 160, { align: 'center' });
  }

  doc.fontSize(10)
    .fillColor('#9CA3AF')
    .text(`Generado el ${new Date().toLocaleDateString('es-ES', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })}`, 50, 180, { align: 'center' });
  
  // Agregar footer a la portada
  addFooter();
  
  // Nueva página para contenido
  addPageWithFooter();
  addPageWithFooter();

  // Resumen Ejecutivo
  doc.fillColor(colors.primary)
    .fontSize(18)
    .font('Helvetica-Bold')
    .text('Resumen Ejecutivo', 50, 50);

  drawLine(75);

  addSpace(10);

  // KPIs principales en cuadrícula
  const kpis = [
    { label: 'Total Contactos', value: stats.totalContacts || contacts.length, icon: '👥' },
    { label: 'Transacciones', value: stats.totalDeals || deals.length, icon: '📋' },
    { label: 'Transacciones Cerradas', value: stats.closedDeals || deals.filter(d => d.status === 'closed').length, icon: '✅' },
    { label: 'Propiedades', value: stats.totalProperties || properties.length, icon: '🏠' },
    { label: 'Ingresos Totales', value: formatCurrency(stats.totalRevenue || deals.filter(d => d.status === 'closed').reduce((sum, d) => sum + (Number(d.offer_price) || 0), 0)), icon: '💰' },
    { label: 'Financiaciones', value: stats.totalFinancings || financings.length, icon: '💳' },
  ];

  let kpiY = 90;
  const kpiWidth = 150;
  const kpiHeight = 60;
  const kpiSpacing = 20;

  kpis.forEach((kpi, index) => {
    const col = index % 3;
    const row = Math.floor(index / 3);
    const x = 50 + col * (kpiWidth + kpiSpacing);
    const y = kpiY + row * (kpiHeight + kpiSpacing);

    // Fondo del KPI
    doc.roundedRect(x, y, kpiWidth, kpiHeight, 5)
      .fill(colors.light);

    // Icono
    doc.fontSize(24)
      .text(kpi.icon, x + 10, y + 5);

    // Valor
    doc.fillColor(colors.primary)
      .fontSize(16)
      .font('Helvetica-Bold')
      .text(kpi.value.toString(), x + 10, y + 30, { width: kpiWidth - 20 });

    // Label
    doc.fillColor(colors.text)
      .fontSize(9)
      .font('Helvetica')
      .text(kpi.label, x + 10, y + 48, { width: kpiWidth - 20 });
  });

  // Nueva página para estadísticas detalladas
  addPageWithFooter();

  // Estadísticas de Contactos
  doc.fillColor(colors.primary)
    .fontSize(16)
    .font('Helvetica-Bold')
    .text('Estadísticas de Contactos', 50, 50);

  drawLine(75);

  addSpace(10);

  const contactStats = {
    total: contacts.length,
    calientes: contacts.filter(c => c.status === 'caliente').length,
    tibios: contacts.filter(c => c.status === 'tibio').length,
    frios: contacts.filter(c => c.status === 'frio').length,
    promedioScore: contacts.length > 0 
      ? (contacts.reduce((sum, c) => sum + (Number(c.lead_score) || 0), 0) / contacts.length).toFixed(1)
      : 0,
  };

  doc.fontSize(11)
    .fillColor(colors.text)
    .font('Helvetica')
    .text(`Total de Contactos: ${contactStats.total}`, 50, 95)
    .text(`Leads Calientes: ${contactStats.calientes}`, 50, 115)
    .text(`Leads Tibios: ${contactStats.tibios}`, 50, 135)
    .text(`Leads Fríos: ${contactStats.frios}`, 50, 155)
    .text(`Lead Score Promedio: ${contactStats.promedioScore}`, 50, 175);

  // Estadísticas de Transacciones
  addSpace(30);

  doc.fillColor(colors.primary)
    .fontSize(16)
    .font('Helvetica-Bold')
    .text('Estadísticas de Transacciones', 50, doc.y);

  drawLine(doc.y + 25);

  addSpace(10);

  const dealStats = {
    total: deals.length,
    enProgreso: deals.filter(d => d.status === 'in_progress').length,
    cerradas: deals.filter(d => d.status === 'closed').length,
    canceladas: deals.filter(d => d.status === 'cancelled').length,
    valorTotal: deals.reduce((sum, d) => sum + (Number(d.offer_price) || 0), 0),
    valorCerradas: deals.filter(d => d.status === 'closed').reduce((sum, d) => sum + (Number(d.offer_price) || 0), 0),
    tasaCierre: deals.length > 0 ? ((deals.filter(d => d.status === 'closed').length / deals.length) * 100).toFixed(1) : 0,
  };

  doc.fontSize(11)
    .fillColor(colors.text)
    .font('Helvetica')
    .text(`Total de Transacciones: ${dealStats.total}`, 50, doc.y)
    .text(`En Progreso: ${dealStats.enProgreso}`, 50, doc.y + 20)
    .text(`Cerradas: ${dealStats.cerradas}`, 50, doc.y + 40)
    .text(`Canceladas: ${dealStats.canceladas}`, 50, doc.y + 60)
    .text(`Valor Total: ${formatCurrency(dealStats.valorTotal)}`, 50, doc.y + 80)
    .text(`Valor Cerradas: ${formatCurrency(dealStats.valorCerradas)}`, 50, doc.y + 100)
    .text(`Tasa de Cierre: ${formatPercent(dealStats.tasaCierre)}`, 50, doc.y + 120);

  // Nueva página para métricas de conversión
  addPageWithFooter();

  doc.fillColor(colors.primary)
    .fontSize(16)
    .font('Helvetica-Bold')
    .text('Métricas de Conversión y Eficiencia', 50, 50);

  drawLine(75);

  addSpace(10);

  const closedDeals = deals.filter(d => d.status === 'closed');
  
  const conversionMetrics = {
    'Tasa de Conversión de Leads': contacts.length > 0 
      ? formatPercent((deals.length / contacts.length) * 100)
      : '0%',
    'Tasa de Cierre de Deals': deals.length > 0
      ? formatPercent((closedDeals.length / deals.length) * 100)
      : '0%',
    'Valor Promedio por Deal': deals.length > 0
      ? formatCurrency(dealStats.valorTotal / deals.length)
      : formatCurrency(0),
    'Tiempo Promedio de Cierre': 'N/A', // Se puede calcular con fechas
    'ROI Estimado': dealStats.cerradas > 0
      ? formatPercent((dealStats.valorCerradas / (contacts.length * 100)) * 100) // Simplificado
      : '0%',
  };

  let metricY = 95;
  Object.entries(conversionMetrics).forEach(([metric, value]) => {
    doc.fontSize(10)
      .fillColor(colors.text)
      .font('Helvetica')
      .text(metric + ':', 50, metricY, { width: 250 })
      .font('Helvetica-Bold')
      .fillColor(colors.primary)
      .text(value, 300, metricY);
    metricY += 20;
  });

  // Nueva página para propiedades y financiación
  addPageWithFooter();

  // Estadísticas de Propiedades
  doc.fillColor(colors.primary)
    .fontSize(16)
    .font('Helvetica-Bold')
    .text('Estadísticas de Propiedades', 50, 50);

  drawLine(75);

  addSpace(10);

  const propertyStats = {
    total: properties.length,
    disponibles: properties.filter(p => p.status === 'available').length,
    pendientes: properties.filter(p => p.status === 'pending').length,
    vendidas: properties.filter(p => p.status === 'sold').length,
    valorTotal: properties.reduce((sum, p) => sum + (Number(p.price) || 0), 0),
    precioPromedio: properties.length > 0 
      ? properties.reduce((sum, p) => sum + (Number(p.price) || 0), 0) / properties.length
      : 0,
  };

  doc.fontSize(11)
    .fillColor(colors.text)
    .font('Helvetica')
    .text(`Total de Propiedades: ${propertyStats.total}`, 50, 95)
    .text(`Disponibles: ${propertyStats.disponibles}`, 50, 115)
    .text(`Pendientes: ${propertyStats.pendientes}`, 50, 135)
    .text(`Vendidas: ${propertyStats.vendidas}`, 50, 155)
    .text(`Valor Total: ${formatCurrency(propertyStats.valorTotal)}`, 50, 175)
    .text(`Precio Promedio: ${formatCurrency(propertyStats.precioPromedio)}`, 50, 195);

  // Estadísticas de Financiación
  addSpace(30);

  doc.fillColor(colors.primary)
    .fontSize(16)
    .font('Helvetica-Bold')
    .text('Estadísticas de Financiación', 50, doc.y);

  drawLine(doc.y + 25);

  addSpace(10);

  const financingStats = {
    total: financings.length,
    aprobadas: financings.filter(f => f.status === 'approved').length,
    enRevision: financings.filter(f => f.status === 'under_review').length,
    montoTotal: financings.reduce((sum, f) => sum + (Number(f.loan_amount) || 0), 0),
    montoAprobado: financings.filter(f => f.status === 'approved').reduce((sum, f) => sum + (Number(f.loan_amount) || 0), 0),
    tasaAprobacion: financings.length > 0 
      ? ((financings.filter(f => f.status === 'approved').length / financings.length) * 100).toFixed(1)
      : 0,
  };

  doc.fontSize(11)
    .fillColor(colors.text)
    .font('Helvetica')
    .text(`Total de Solicitudes: ${financingStats.total}`, 50, doc.y)
    .text(`Aprobadas: ${financingStats.aprobadas}`, 50, doc.y + 20)
    .text(`En Revisión: ${financingStats.enRevision}`, 50, doc.y + 40)
    .text(`Monto Total: ${formatCurrency(financingStats.montoTotal)}`, 50, doc.y + 60)
    .text(`Monto Aprobado: ${formatCurrency(financingStats.montoAprobado)}`, 50, doc.y + 80)
    .text(`Tasa de Aprobación: ${formatPercent(financingStats.tasaAprobacion)}`, 50, doc.y + 100);

  // Nueva página para análisis y gráficos
  addPageWithFooter();

  doc.fillColor(colors.primary)
    .fontSize(16)
    .font('Helvetica-Bold')
    .text('Análisis de Rendimiento', 50, 50);

  drawLine(75);

  addSpace(10);

  // Gráfico de barras simple para estados de deals
  doc.fontSize(12)
    .fillColor(colors.text)
    .font('Helvetica-Bold')
    .text('Distribución de Transacciones por Estado', 50, 95);

  const dealStatusData = {
    'En Progreso': deals.filter(d => d.status === 'in_progress').length,
    'Cerradas': deals.filter(d => d.status === 'closed').length,
    'Pendientes': deals.filter(d => d.status === 'pending').length,
    'Canceladas': deals.filter(d => d.status === 'cancelled').length,
  };

  const maxDeals = Math.max(...Object.values(dealStatusData), 1);
  const barWidth = 100;
  const barHeight = 15;
  const barSpacing = 25;
  let barY = 120;

  Object.entries(dealStatusData).forEach(([status, count], index) => {
    const barLength = (count / maxDeals) * 300;
    const barColor = index === 1 ? colors.secondary : index === 0 ? colors.primary : colors.accent;

    // Barra
    doc.rect(50, barY, barLength, barHeight)
      .fill(barColor);

    // Etiqueta y valor
    doc.fontSize(9)
      .fillColor(colors.text)
      .font('Helvetica')
      .text(status, 50, barY + 18, { width: 100 })
      .font('Helvetica-Bold')
      .text(count.toString(), 360, barY + 2);

    barY += barSpacing;
  });

  // Gráfico de distribución de contactos por estado
  addSpace(30);

  doc.fontSize(12)
    .fillColor(colors.text)
    .font('Helvetica-Bold')
    .text('Distribución de Leads por Estado', 50, doc.y);

  const contactStatusData = {
    'Calientes': contacts.filter(c => c.status === 'caliente').length,
    'Tibios': contacts.filter(c => c.status === 'tibio').length,
    'Fríos': contacts.filter(c => c.status === 'frio').length,
  };

  const maxContacts = Math.max(...Object.values(contactStatusData), 1);
  barY = doc.y + 25;

  Object.entries(contactStatusData).forEach(([status, count], index) => {
    const barLength = (count / maxContacts) * 300;
    const barColor = index === 0 ? '#EF4444' : index === 1 ? colors.accent : '#6B7280';

    doc.rect(50, barY, barLength, barHeight)
      .fill(barColor);

    doc.fontSize(9)
      .fillColor(colors.text)
      .font('Helvetica')
      .text(status, 50, barY + 18, { width: 100 })
      .font('Helvetica-Bold')
      .text(count.toString(), 360, barY + 2);

    barY += barSpacing;
  });

  // Nueva página para top performers
  addPageWithFooter();

  doc.fillColor(colors.primary)
    .fontSize(16)
    .font('Helvetica-Bold')
    .text('Top Transacciones del Mes', 50, 50);

  drawLine(75);

  addSpace(10);

  // Top 5 deals por valor
  const topDeals = deals
    .filter(d => d.offer_price)
    .sort((a, b) => (Number(b.offer_price) || 0) - (Number(a.offer_price) || 0))
    .slice(0, 5);

  if (topDeals.length > 0) {
    let tableY = 95;
    doc.fontSize(10)
      .fillColor(colors.dark)
      .font('Helvetica-Bold')
      .text('Propiedad', 50, tableY)
      .text('Cliente', 200, tableY)
      .text('Valor', 350, tableY)
      .text('Estado', 450, tableY);

    drawLine(tableY + 15);

    topDeals.forEach((deal, index) => {
      tableY += 25;
      doc.fontSize(9)
        .fillColor(colors.text)
        .font('Helvetica')
        .text(deal.property_id?.title || 'Sin propiedad', 50, tableY, { width: 140 })
        .text(
          deal.contact_id 
            ? `${deal.contact_id.first_name || ''} ${deal.contact_id.last_name || ''}`.trim() || 'Sin cliente'
            : 'Sin cliente',
          200,
          tableY,
          { width: 140 }
        )
        .text(formatCurrency(deal.offer_price || 0), 350, tableY, { width: 90 })
        .text(deal.status === 'closed' ? 'Cerrada' : deal.status === 'in_progress' ? 'En Progreso' : 'Pendiente', 450, tableY, { width: 60 });

      if (index < topDeals.length - 1) {
        drawLine(tableY + 15);
      }
    });
  } else {
    doc.fontSize(11)
      .fillColor(colors.text)
      .text('No hay transacciones registradas este mes', 50, 95);
  }

  // Agregar pie de página a la primera página
  addFooter();
  
  return doc;
};

/**
 * Genera un PDF de reporte consolidado
 */
export const generateConsolidatedReportPDF = async (data, options = {}) => {
  const {
    period,
    summary,
    contacts,
    deals,
    properties,
    financings,
    userInfo,
  } = data;

  const doc = new PDFDocument({
    size: 'A4',
    margin: 50,
    info: {
      Title: `Reporte Consolidado - ${period?.start || 'Inicio'} a ${period?.end || 'Fin'}`,
      Author: 'RockIt CRM',
      Subject: 'Reporte Consolidado de Actividad',
    },
  });

  // Contador de páginas manual
  let pageCount = 0;
  
  // Función helper para agregar nueva página con footer
  const addPageWithFooter = () => {
    doc.addPage();
    pageCount++;
    // Agregar footer en la parte inferior
    doc.fontSize(8)
      .fillColor('#9CA3AF')
      .text(
        `Página ${pageCount} | RockIt CRM - Reporte Consolidado`,
        50,
        doc.page.height - 30,
        { align: 'center', width: 500 }
      );
  };
  
  // Función helper para agregar pie de página a la página actual
  const addFooter = () => {
    pageCount++;
    doc.fontSize(8)
      .fillColor('#9CA3AF')
      .text(
        `Página ${pageCount} | RockIt CRM - Reporte Consolidado`,
        50,
        doc.page.height - 30,
        { align: 'center', width: 500 }
      );
  };

  const colors = {
    primary: '#465FFF',
    secondary: '#10B981',
    accent: '#F59E0B',
    dark: '#1F2937',
    light: '#F3F4F6',
    text: '#374151',
  };

  const formatCurrency = (amount) => {
    return `€${Number(amount).toLocaleString('es-ES', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const formatPercent = (value) => {
    return `${Number(value).toFixed(1)}%`;
  };

  // Helper para agregar espacio
  const addSpace = (y) => {
    doc.y += y;
  };

  // Helper para dibujar línea
  const drawLine = (y, width = 500) => {
    doc.moveTo(50, y).lineTo(50 + width, y).stroke(colors.light);
  };

  // Portada similar pero con título diferente
  doc.fillColor(colors.primary)
    .fontSize(32)
    .font('Helvetica-Bold')
    .text('RockIt CRM', 50, 50, { align: 'center' });

  doc.fillColor(colors.text)
    .fontSize(20)
    .font('Helvetica')
    .text('Reporte Consolidado', 50, 100, { align: 'center' });

  if (period?.start && period?.end) {
    doc.fillColor(colors.dark)
      .fontSize(14)
      .text(
        `${new Date(period.start).toLocaleDateString('es-ES')} - ${new Date(period.end).toLocaleDateString('es-ES')}`,
        50,
        130,
        { align: 'center' }
      );
  } else {
    doc.fillColor(colors.dark)
      .fontSize(14)
      .text('Período completo', 50, 130, { align: 'center' });
  }

  if (userInfo) {
    doc.fontSize(12)
      .fillColor(colors.text)
      .text(`Generado para: ${userInfo.first_name || ''} ${userInfo.last_name || ''}`, 50, 160, { align: 'center' });
  }

  doc.fontSize(10)
    .fillColor('#9CA3AF')
    .text(`Generado el ${new Date().toLocaleDateString('es-ES', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })}`, 50, 180, { align: 'center' });

  // Agregar footer a la portada
  addFooter();

  addPageWithFooter();

  // Resumen ejecutivo con más detalle
  doc.fillColor(colors.primary)
    .fontSize(18)
    .font('Helvetica-Bold')
    .text('Resumen Ejecutivo', 50, 50);

  doc.moveTo(50, 75).lineTo(550, 75).stroke(colors.light);

  const summaryData = [
    { label: 'Contactos Totales', value: summary.contacts || 0 },
    { label: 'Transacciones Totales', value: summary.deals || 0 },
    { label: 'Transacciones Cerradas', value: summary.closedDeals || 0 },
    { label: 'Propiedades', value: summary.properties || 0 },
    { label: 'Ingresos Totales', value: formatCurrency(summary.totalRevenue || 0) },
    { label: 'Valor Total Propiedades', value: formatCurrency(summary.totalPropertiesValue || 0) },
    { label: 'Financiaciones', value: summary.financings || 0 },
    { label: 'Monto Total Financiación', value: formatCurrency(summary.totalFinancingAmount || 0) },
  ];

  let yPos = 90;
  summaryData.forEach((item) => {
    doc.fontSize(11)
      .fillColor(colors.text)
      .font('Helvetica')
      .text(item.label + ':', 50, yPos, { width: 200 })
      .font('Helvetica-Bold')
      .fillColor(colors.primary)
      .text(item.value.toString(), 250, yPos);
    yPos += 25;
  });

  // Estadísticas de Contactos
  addSpace(30);

  doc.fillColor(colors.primary)
    .fontSize(16)
    .font('Helvetica-Bold')
    .text('Estadísticas de Contactos', 50, doc.y);

  drawLine(doc.y + 25);

  addSpace(10);

  const contactStats = {
    total: contacts.length,
    calientes: contacts.filter(c => c.status === 'caliente').length,
    tibios: contacts.filter(c => c.status === 'tibio').length,
    frios: contacts.filter(c => c.status === 'frio').length,
    promedioScore: contacts.length > 0 
      ? (contacts.reduce((sum, c) => sum + (Number(c.lead_score) || 0), 0) / contacts.length).toFixed(1)
      : 0,
  };

  doc.fontSize(11)
    .fillColor(colors.text)
    .font('Helvetica')
    .text(`Total de Contactos: ${contactStats.total}`, 50, doc.y)
    .text(`Leads Calientes: ${contactStats.calientes}`, 50, doc.y + 20)
    .text(`Leads Tibios: ${contactStats.tibios}`, 50, doc.y + 40)
    .text(`Leads Fríos: ${contactStats.frios}`, 50, doc.y + 60)
    .text(`Lead Score Promedio: ${contactStats.promedioScore}`, 50, doc.y + 80);

  // Estadísticas de Transacciones
  addSpace(30);

  doc.fillColor(colors.primary)
    .fontSize(16)
    .font('Helvetica-Bold')
    .text('Estadísticas de Transacciones', 50, doc.y);

  drawLine(doc.y + 25);

  addSpace(10);

  const closedDeals = deals.filter(d => d.status === 'closed');
  const dealStats = {
    total: deals.length,
    enProgreso: deals.filter(d => d.status === 'in_progress').length,
    cerradas: closedDeals.length,
    canceladas: deals.filter(d => d.status === 'cancelled').length,
    valorTotal: deals.reduce((sum, d) => sum + (Number(d.offer_price) || 0), 0),
    valorCerradas: closedDeals.reduce((sum, d) => sum + (Number(d.offer_price) || 0), 0),
    tasaCierre: deals.length > 0 ? ((closedDeals.length / deals.length) * 100).toFixed(1) : 0,
  };

  doc.fontSize(11)
    .fillColor(colors.text)
    .font('Helvetica')
    .text(`Total de Transacciones: ${dealStats.total}`, 50, doc.y)
    .text(`En Progreso: ${dealStats.enProgreso}`, 50, doc.y + 20)
    .text(`Cerradas: ${dealStats.cerradas}`, 50, doc.y + 40)
    .text(`Canceladas: ${dealStats.canceladas}`, 50, doc.y + 60)
    .text(`Valor Total: ${formatCurrency(dealStats.valorTotal)}`, 50, doc.y + 80)
    .text(`Valor Cerradas: ${formatCurrency(dealStats.valorCerradas)}`, 50, doc.y + 100)
    .text(`Tasa de Cierre: ${formatPercent(dealStats.tasaCierre)}`, 50, doc.y + 120);

  // Nueva página para propiedades y financiación
  addPageWithFooter();

  // Estadísticas de Propiedades
  doc.fillColor(colors.primary)
    .fontSize(16)
    .font('Helvetica-Bold')
    .text('Estadísticas de Propiedades', 50, 50);

  drawLine(75);

  addSpace(10);

  const propertyStats = {
    total: properties.length,
    disponibles: properties.filter(p => p.status === 'available').length,
    pendientes: properties.filter(p => p.status === 'pending').length,
    vendidas: properties.filter(p => p.status === 'sold').length,
    valorTotal: properties.reduce((sum, p) => sum + (Number(p.price) || 0), 0),
    precioPromedio: properties.length > 0 
      ? properties.reduce((sum, p) => sum + (Number(p.price) || 0), 0) / properties.length
      : 0,
  };

  doc.fontSize(11)
    .fillColor(colors.text)
    .font('Helvetica')
    .text(`Total de Propiedades: ${propertyStats.total}`, 50, 95)
    .text(`Disponibles: ${propertyStats.disponibles}`, 50, 115)
    .text(`Pendientes: ${propertyStats.pendientes}`, 50, 135)
    .text(`Vendidas: ${propertyStats.vendidas}`, 50, 155)
    .text(`Valor Total: ${formatCurrency(propertyStats.valorTotal)}`, 50, 175)
    .text(`Precio Promedio: ${formatCurrency(propertyStats.precioPromedio)}`, 50, 195);

  // Estadísticas de Financiación
  addSpace(30);

  doc.fillColor(colors.primary)
    .fontSize(16)
    .font('Helvetica-Bold')
    .text('Estadísticas de Financiación', 50, doc.y);

  drawLine(doc.y + 25);

  addSpace(10);

  const financingStats = {
    total: financings.length,
    aprobadas: financings.filter(f => f.status === 'approved').length,
    enRevision: financings.filter(f => f.status === 'under_review').length,
    montoTotal: financings.reduce((sum, f) => sum + (Number(f.loan_amount) || 0), 0),
    montoAprobado: financings.filter(f => f.status === 'approved').reduce((sum, f) => sum + (Number(f.loan_amount) || 0), 0),
    tasaAprobacion: financings.length > 0 
      ? ((financings.filter(f => f.status === 'approved').length / financings.length) * 100).toFixed(1)
      : 0,
  };

  doc.fontSize(11)
    .fillColor(colors.text)
    .font('Helvetica')
    .text(`Total de Solicitudes: ${financingStats.total}`, 50, doc.y)
    .text(`Aprobadas: ${financingStats.aprobadas}`, 50, doc.y + 20)
    .text(`En Revisión: ${financingStats.enRevision}`, 50, doc.y + 40)
    .text(`Monto Total: ${formatCurrency(financingStats.montoTotal)}`, 50, doc.y + 60)
    .text(`Monto Aprobado: ${formatCurrency(financingStats.montoAprobado)}`, 50, doc.y + 80)
    .text(`Tasa de Aprobación: ${formatPercent(financingStats.tasaAprobacion)}`, 50, doc.y + 100);

  // El footer ya se agregó automáticamente en cada página
  return doc;
};

