# 📝 Crear Archivo .env

## Instrucciones Rápidas

1. **Copia el archivo template:**
   ```cmd
   cd backend
   copy .env.template .env
   ```

2. **Edita el archivo `.env`** y reemplaza:
   - `<db_password>` con tu contraseña real de MongoDB Atlas
   - Verifica que el nombre de la base de datos esté en la URI (antes del `?`)

3. **Ejemplo de URI completa:**
   ```
   MONGODB_URI=mongodb+srv://njmartin96_db_user:miPassword123@cluster0.x0sw3xh.mongodb.net/crm_inmobiliario?retryWrites=true&w=majority&appName=Cluster0
   ```

## Estructura de la URI

```
mongodb+srv://[usuario]:[contraseña]@[cluster]/[base_de_datos]?[parámetros]
```

**Tu URI actual:**
- Usuario: `njmartin96_db_user`
- Contraseña: `<db_password>` ← **REEMPLAZAR**
- Cluster: `cluster0.x0sw3xh.mongodb.net`
- Base de datos: Agregar antes del `?` (ej: `/crm_inmobiliario` o `/make-agent`)

## Verificar

Después de crear el `.env`, ejecuta:

```cmd
node test-connection.js
```

O:

```cmd
npm run check-db
```

## ⚠️ Importante

- El archivo debe llamarse exactamente `.env` (sin extensión)
- Debe estar en la carpeta `backend/`
- No subas el archivo `.env` a Git (debe estar en `.gitignore`)


