import dotenv from 'dotenv';
import mongoose from 'mongoose';

dotenv.config();

console.log('🔍 Verificando configuración...\n');

const mongoUri = process.env.MONGODB_URI;

if (!mongoUri) {
  console.error('❌ ERROR: MONGODB_URI no está configurado en el archivo .env');
  console.log('\nPor favor crea el archivo backend/.env con:');
  console.log('MONGODB_URI=mongodb+srv://njmartin96_db_user:TU_CONTRASEÑA@cluster0.x0sw3xh.mongodb.net/crm_inmobiliario?retryWrites=true&w=majority&appName=Cluster0\n');
  process.exit(1);
}

const maskedUri = mongoUri.replace(/\/\/[^:]+:[^@]+@/, '//***:***@');
console.log(`URI configurada: ${maskedUri}\n`);

console.log('Intentando conectar a MongoDB Atlas...\n');

mongoose.connect(mongoUri)
  .then(() => {
    console.log('✅ Conexión exitosa a MongoDB!');
    console.log(`   Host: ${mongoose.connection.host}`);
    console.log(`   Database: ${mongoose.connection.name}`);
    console.log(`   Estado: Conectado\n`);
    process.exit(0);
  })
  .catch((error) => {
    console.error('❌ Error de conexión:', error.message);
    console.log('\n🔧 Posibles soluciones:');
    console.log('1. Verifica que la contraseña sea correcta');
    console.log('2. Verifica que tu IP esté en la whitelist de MongoDB Atlas');
    console.log('3. Verifica que el nombre de usuario sea correcto: njmartin96_db_user');
    console.log('4. Verifica que el cluster esté activo\n');
    process.exit(1);
  });


