import connectDB from '../config/database.js';
import dotenv from 'dotenv';

dotenv.config();

const checkDatabase = async () => {
  console.log('🔍 Verificando conexión a MongoDB...');
  console.log('');
  console.log('Configuración actual:');
  const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/crm_inmobiliario';
  const maskedUri = mongoUri.replace(/\/\/[^:]+:[^@]+@/, '//***:***@');
  console.log(`  URI: ${maskedUri}`);
  console.log('');

  try {
    const conn = await connectDB();
    console.log('✅ Conexión exitosa a MongoDB!');
    console.log('');
    console.log('Información del servidor:');
    console.log(`  Host: ${conn.connection.host}`);
    console.log(`  Database: ${conn.connection.name}`);
    console.log(`  Estado: ${conn.connection.readyState === 1 ? 'Conectado' : 'Desconectado'}`);
    console.log('');
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Error de conexión:', error.message);
    console.log('');
    console.log('🔧 Soluciones posibles:');
    console.log('');
    console.log('1. Verifica que MONGODB_URI esté configurado en backend/.env');
    console.log('2. Verifica que la URI de MongoDB Atlas sea correcta');
    console.log('3. Verifica que tu IP esté en la whitelist de MongoDB Atlas');
    console.log('4. Verifica que las credenciales sean correctas');
    console.log('');
    process.exit(1);
  }
};

checkDatabase();
