import connectDB from '../config/database.js';
import User from '../models/User.js';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';

dotenv.config();

const createAdminUser = async () => {
  try {
    await connectDB();

    const adminEmail = process.env.ADMIN_EMAIL || 'admin@crm.com';
    const adminPassword = process.env.ADMIN_PASSWORD || 'admin123';
    const adminFirstName = process.env.ADMIN_FIRST_NAME || 'Admin';
    const adminLastName = process.env.ADMIN_LAST_NAME || 'Usuario';

    // Verificar si el usuario admin ya existe
    const existingUser = await User.findOne({ email: adminEmail });

    if (existingUser) {
      console.log('⚠️  El usuario admin ya existe');
      console.log(`   Email: ${adminEmail}`);
      process.exit(0);
      return;
    }

    // Hash de la contraseña
    const passwordHash = await bcrypt.hash(adminPassword, 10);

    // Crear usuario admin
    const admin = await User.create({
      email: adminEmail,
      password_hash: passwordHash,
      first_name: adminFirstName,
      last_name: adminLastName,
      role: 'admin',
    });

    console.log('✅ Usuario admin creado exitosamente');
    console.log('');
    console.log('📋 Credenciales de acceso:');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log(`   Email:    ${admin.email}`);
    console.log(`   Password: ${adminPassword}`);
    console.log(`   Role:     ${admin.role}`);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('');
    console.log('⚠️  IMPORTANTE: Cambia la contraseña después del primer inicio de sesión');
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Error creando usuario admin:', error);
    process.exit(1);
  }
};

createAdminUser();
