# ✅ Configuración Completa de MongoDB Atlas

## Credenciales Configuradas

- **Usuario:** njmartin96_db_user
- **Contraseña:** fjZTf2WMUfxcOBaa
- **Cluster:** cluster0.divtmsn.mongodb.net
- **Base de datos:** crm_inmobiliario

## URI de Conexión Completa

```
mongodb+srv://njmartin96_db_user:fjZTf2WMUfxcOBaa@cluster0.divtmsn.mongodb.net/crm_inmobiliario?retryWrites=true&w=majority&appName=Cluster0
```

## Archivo .env

El archivo `backend/.env` debe contener:

```env
# Server Configuration
PORT=5000
NODE_ENV=development

# MongoDB Atlas Connection String
MONGODB_URI=mongodb+srv://njmartin96_db_user:fjZTf2WMUfxcOBaa@cluster0.divtmsn.mongodb.net/crm_inmobiliario?retryWrites=true&w=majority&appName=Cluster0

# JWT Configuration
JWT_SECRET=tu_secreto_jwt_super_seguro_cambiar_en_produccion
JWT_EXPIRES_IN=7d

# OpenAI API Key
OPENAI_API_KEY=sk-tu-api-key-de-openai-aqui

# Make.com API Key (opcional)
MAKE_API_KEY=tu-make-api-key-aqui

# Admin User
ADMIN_EMAIL=admin@crm.com
ADMIN_PASSWORD=admin123
ADMIN_FIRST_NAME=Admin
ADMIN_LAST_NAME=Usuario
```

## Verificar Conexión

Ejecuta:

```cmd
cd backend
node test-connection.js
```

O:

```cmd
npm run check-db
```

## Próximos Pasos

1. ✅ Verificar conexión a MongoDB
2. ✅ Crear usuario admin: `npm run seed`
3. ✅ Iniciar servidor: `npm run dev`
4. ✅ Iniciar frontend: `npm run dev` (desde la raíz)

## Credenciales de Acceso Admin

- **Email:** admin@crm.com
- **Password:** admin123


