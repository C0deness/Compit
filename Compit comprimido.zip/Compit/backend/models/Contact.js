import mongoose from 'mongoose';

const contactSchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  first_name: {
    type: String,
    required: true,
    trim: true,
  },
  last_name: {
    type: String,
    trim: true,
  },
  email: {
    type: String,
    trim: true,
    lowercase: true,
  },
  phone: {
    type: String,
    trim: true,
  },
  status: {
    type: String,
    default: 'frio',
    enum: ['frio', 'tibio', 'caliente'],
  },
  lead_score: {
    type: Number,
    default: 0,
    min: 0,
    max: 100,
  },
  source: {
    type: String,
    trim: true,
  },
  notes: {
    type: String,
  },
  asnef_check: {
    has_debt: {
      type: Boolean,
      default: false,
    },
    checked_at: {
      type: Date,
      default: null,
    },
    total_debt: {
      type: Number,
      default: null,
    },
    debt_details: [{
      creditor: String,
      amount: Number,
      status: String,
      date: Date,
    }],
    risk_level: {
      type: String,
      enum: ['low', 'medium', 'high', 'very_high', null],
      default: null,
    },
  },
}, {
  timestamps: true,
});

contactSchema.index({ user_id: 1, status: 1 });

export default mongoose.model('Contact', contactSchema);

