import mongoose from 'mongoose';

const FinancingSchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  contact_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Contact',
    required: true,
  },
  deal_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Deal',
    default: null,
  },
  property_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Property',
    default: null,
  },
  loan_type: {
    type: String,
    enum: ['conventional', 'fha', 'va', 'usda', 'jumbo', 'other'],
    required: true,
  },
  loan_amount: {
    type: Number,
    required: true,
  },
  interest_rate: {
    type: Number,
    default: null,
  },
  loan_term: {
    type: Number, // en años
    required: true,
  },
  down_payment: {
    type: Number,
    default: 0,
  },
  down_payment_percentage: {
    type: Number,
    default: 0,
  },
  monthly_payment: {
    type: Number,
    default: null,
  },
  status: {
    type: String,
    enum: ['draft', 'submitted', 'under_review', 'approved', 'rejected', 'closed'],
    default: 'draft',
  },
  lender_name: {
    type: String,
    default: null,
  },
  lender_contact: {
    type: String,
    default: null,
  },
  application_date: {
    type: Date,
    default: Date.now,
  },
  approval_date: {
    type: Date,
    default: null,
  },
  closing_date: {
    type: Date,
    default: null,
  },
  notes: {
    type: String,
    default: null,
  },
  documents: [{
    name: String,
    type: String,
    url: String,
    uploaded_at: {
      type: Date,
      default: Date.now,
    },
  }],
  credit_score: {
    type: Number,
    default: null,
  },
  debt_to_income_ratio: {
    type: Number,
    default: null,
  },
}, {
  timestamps: true,
});

export default mongoose.model('Financing', FinancingSchema);


