import mongoose from 'mongoose';

const propertySchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  title: {
    type: String,
    required: true,
    trim: true,
  },
  description: {
    type: String,
  },
  type: {
    type: String,
    required: true,
    enum: ['house', 'apartment', 'condo', 'land'],
  },
  price: {
    type: Number,
    required: true,
    min: 0,
  },
  address: {
    type: String,
    trim: true,
  },
  city: {
    type: String,
    trim: true,
  },
  state: {
    type: String,
    trim: true,
  },
  zip_code: {
    type: String,
    trim: true,
  },
  latitude: {
    type: Number,
  },
  longitude: {
    type: Number,
  },
  bedrooms: {
    type: Number,
    min: 0,
  },
  bathrooms: {
    type: Number,
    min: 0,
  },
  area_sqft: {
    type: Number,
    min: 0,
  },
  year_built: {
    type: Number,
  },
  status: {
    type: String,
    default: 'available',
    enum: ['available', 'sold', 'pending', 'off_market'],
  },
  images: {
    type: [String],
    default: [],
  },
  features: {
    type: [String],
    default: [],
  },
}, {
  timestamps: true,
});

propertySchema.index({ user_id: 1, status: 1 });
propertySchema.index({ type: 1 });
propertySchema.index({ price: 1 });

export default mongoose.model('Property', propertySchema);


