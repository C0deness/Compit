import mongoose from 'mongoose';

const workflowSchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  name: {
    type: String,
    required: true,
  },
  trigger_type: {
    type: String,
    required: true,
  },
  trigger_condition: {
    type: mongoose.Schema.Types.Mixed,
  },
  actions: {
    type: mongoose.Schema.Types.Mixed,
    required: true,
  },
  is_active: {
    type: Boolean,
    default: true,
  },
}, {
  timestamps: true,
});

export default mongoose.model('Workflow', workflowSchema);


