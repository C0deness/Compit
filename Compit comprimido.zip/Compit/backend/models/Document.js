import mongoose from 'mongoose';

const documentSchema = new mongoose.Schema({
  deal_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Deal',
    required: true,
  },
  name: {
    type: String,
    required: true,
  },
  type: {
    type: String,
    required: true,
  },
  file_path: {
    type: String,
    required: true,
  },
  status: {
    type: String,
    default: 'pending',
    enum: ['pending', 'en_revision', 'validated', 'error'],
  },
  validation_data: {
    type: mongoose.Schema.Types.Mixed,
  },
  validated_at: {
    type: Date,
  },
}, {
  timestamps: { createdAt: 'uploaded_at', updatedAt: false },
});

documentSchema.index({ deal_id: 1 });

export default mongoose.model('Document', documentSchema);


