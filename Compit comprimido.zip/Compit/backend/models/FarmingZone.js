import mongoose from 'mongoose';

const farmingZoneSchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  name: {
    type: String,
    required: true,
  },
  coordinates: {
    type: mongoose.Schema.Types.Mixed,
    required: true,
  },
  potential_score: {
    type: Number,
  },
  analysis_data: {
    type: mongoose.Schema.Types.Mixed,
  },
}, {
  timestamps: true,
});

export default mongoose.model('FarmingZone', farmingZoneSchema);


