import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true,
  },
  password_hash: {
    type: String,
    required: true,
  },
  first_name: {
    type: String,
    trim: true,
  },
  last_name: {
    type: String,
    trim: true,
  },
  phone: {
    type: String,
    trim: true,
  },
  role: {
    type: String,
    default: 'concesionario',
    enum: ['admin', 'concesionario'],
  },
  dealership_name: {
    type: String,
    trim: true,
  },
  subscription_plan: {
    type: String,
    enum: ['free', 'basic', 'professional', 'enterprise'],
    default: 'free',
  },
  subscription_expires_at: {
    type: Date,
  },
}, {
  timestamps: true,
});

export default mongoose.model('User', userSchema);


