import mongoose from 'mongoose';

const dealSchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  contact_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Contact',
  },
  property_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Property',
  },
  type: {
    type: String,
    required: true,
    enum: ['sale', 'rent', 'purchase'],
  },
  status: {
    type: String,
    default: 'in_progress',
    enum: ['in_progress', 'closed', 'cancelled'],
  },
  offer_price: {
    type: Number,
    min: 0,
  },
  closing_date: {
    type: Date,
  },
  commission: {
    type: Number,
    min: 0,
  },
  notes: {
    type: String,
  },
}, {
  timestamps: true,
});

dealSchema.index({ user_id: 1, status: 1 });

export default mongoose.model('Deal', dealSchema);


