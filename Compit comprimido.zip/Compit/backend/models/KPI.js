import mongoose from 'mongoose';

const kpiSchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  name: {
    type: String,
    required: true,
    trim: true,
  },
  category: {
    type: String,
    enum: ['precio_vo', 'stock', 'financiacion', 'competencia', 'ventas'],
    required: true,
  },
  value: {
    type: Number,
    required: true,
  },
  previous_value: {
    type: Number,
  },
  unit: {
    type: String,
    default: 'unidad',
  },
  trend: {
    type: String,
    enum: ['up', 'down', 'stable'],
  },
  change_percentage: {
    type: Number,
  },
  target_value: {
    type: Number,
  },
  period: {
    type: String,
    enum: ['daily', 'weekly', 'monthly', 'quarterly', 'yearly'],
    default: 'daily',
  },
  period_date: {
    type: Date,
    default: Date.now,
  },
  metadata: {
    brand: String,
    model: String,
    competitor_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Competitor',
    },
    region: String,
  },
}, {
  timestamps: true,
});

kpiSchema.index({ user_id: 1, period_date: -1 });
kpiSchema.index({ user_id: 1, category: 1, period_date: -1 });
kpiSchema.index({ user_id: 1, name: 1 });

export default mongoose.model('KPI', kpiSchema);
