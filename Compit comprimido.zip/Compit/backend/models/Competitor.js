import mongoose from 'mongoose';

const competitorSchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  name: {
    type: String,
    required: true,
    trim: true,
  },
  website: {
    type: String,
    trim: true,
  },
  type: {
    type: String,
    enum: ['concesionario', 'portal_vo', 'marketplace', 'otro'],
    default: 'concesionario',
  },
  region: {
    type: String,
    trim: true,
  },
  brands_monitored: [{
    type: String,
    trim: true,
  }],
  is_active: {
    type: Boolean,
    default: true,
  },
  last_scraped_at: {
    type: Date,
  },
  metadata: {
    contact_info: {
      email: String,
      phone: String,
      address: String,
    },
    notes: String,
  },
}, {
  timestamps: true,
});

competitorSchema.index({ user_id: 1, name: 1 });
competitorSchema.index({ user_id: 1, is_active: 1 });

export default mongoose.model('Competitor', competitorSchema);
