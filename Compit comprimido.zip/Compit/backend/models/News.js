import mongoose from 'mongoose';

const newsSchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  title: {
    type: String,
    required: true,
    trim: true,
  },
  content: {
    type: String,
    required: true,
  },
  summary: {
    type: String,
    trim: true,
  },
  source: {
    type: String,
    required: true,
    trim: true,
  },
  source_url: {
    type: String,
    trim: true,
  },
  category: {
    type: String,
    enum: ['precio', 'stock', 'financiacion', 'competencia', 'general'],
    default: 'general',
  },
  keywords: [{
    type: String,
    trim: true,
  }],
  competitor_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Competitor',
  },
  brand: {
    type: String,
    trim: true,
  },
  model: {
    type: String,
    trim: true,
  },
  price: {
    type: Number,
  },
  relevance_score: {
    type: Number,
    min: 0,
    max: 100,
    default: 50,
  },
  published_at: {
    type: Date,
    default: Date.now,
  },
  processed_at: {
    type: Date,
    default: Date.now,
  },
  is_read: {
    type: Boolean,
    default: false,
  },
}, {
  timestamps: true,
});

newsSchema.index({ user_id: 1, published_at: -1 });
newsSchema.index({ user_id: 1, category: 1 });
newsSchema.index({ user_id: 1, brand: 1, model: 1 });
newsSchema.index({ user_id: 1, is_read: 1 });

export default mongoose.model('News', newsSchema);
