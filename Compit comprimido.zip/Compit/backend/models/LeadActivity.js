import mongoose from 'mongoose';

const leadActivitySchema = new mongoose.Schema({
  contact_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Contact',
    required: true,
  },
  activity_type: {
    type: String,
    required: true,
  },
  activity_data: {
    type: mongoose.Schema.Types.Mixed,
  },
  score_change: {
    type: Number,
    default: 0,
  },
}, {
  timestamps: true,
});

leadActivitySchema.index({ contact_id: 1 });

export default mongoose.model('LeadActivity', leadActivitySchema);


