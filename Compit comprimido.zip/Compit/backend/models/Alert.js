import mongoose from 'mongoose';

const alertSchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  type: {
    type: String,
    required: true,
    enum: ['precio', 'stock', 'financiacion', 'competencia', 'kpi', 'recomendacion'],
  },
  severity: {
    type: String,
    enum: ['low', 'medium', 'high', 'critical'],
    default: 'medium',
  },
  title: {
    type: String,
    required: true,
    trim: true,
  },
  message: {
    type: String,
    required: true,
  },
  related_news_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'News',
  },
  related_kpi_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'KPI',
  },
  brand: {
    type: String,
    trim: true,
  },
  model: {
    type: String,
    trim: true,
  },
  competitor_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Competitor',
  },
  is_read: {
    type: Boolean,
    default: false,
  },
  action_taken: {
    type: Boolean,
    default: false,
  },
  action_taken_at: {
    type: Date,
  },
  metadata: {
    type: mongoose.Schema.Types.Mixed,
  },
}, {
  timestamps: true,
});

alertSchema.index({ user_id: 1, created_at: -1 });
alertSchema.index({ user_id: 1, type: 1, is_read: 1 });
alertSchema.index({ user_id: 1, severity: 1 });

export default mongoose.model('Alert', alertSchema);
