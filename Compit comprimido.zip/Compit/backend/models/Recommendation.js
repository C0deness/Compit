import mongoose from 'mongoose';

const recommendationSchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  type: {
    type: String,
    required: true,
    enum: ['rotacion_stock', 'pricing_vo', 'estrategia_financiacion', 'competencia', 'marketing'],
  },
  title: {
    type: String,
    required: true,
    trim: true,
  },
  description: {
    type: String,
    required: true,
  },
  action_items: [{
    title: String,
    description: String,
    priority: {
      type: String,
      enum: ['low', 'medium', 'high'],
      default: 'medium',
    },
  }],
  expected_impact: {
    type: String,
    enum: ['low', 'medium', 'high'],
  },
  confidence_score: {
    type: Number,
    min: 0,
    max: 100,
    default: 50,
  },
  related_data: {
    brand: String,
    model: String,
    competitor_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Competitor',
    },
    kpi_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'KPI',
    },
  },
  status: {
    type: String,
    enum: ['pending', 'in_progress', 'completed', 'dismissed'],
    default: 'pending',
  },
  acted_upon_at: {
    type: Date,
  },
  results: {
    type: String,
  },
}, {
  timestamps: true,
});

recommendationSchema.index({ user_id: 1, created_at: -1 });
recommendationSchema.index({ user_id: 1, type: 1, status: 1 });

export default mongoose.model('Recommendation', recommendationSchema);
