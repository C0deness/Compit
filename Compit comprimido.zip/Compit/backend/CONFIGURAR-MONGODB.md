# 🔧 Configuración de MongoDB Atlas

## Nueva URI de MongoDB Atlas

Tu nueva URI de conexión es:

```
mongodb+srv://njmartin96_db_user:<db_password>@cluster0.x0sw3xh.mongodb.net/?appName=Cluster0
```

## Pasos para Configurar

### 1. Obtener la Contraseña

Reemplaza `<db_password>` con tu contraseña real de MongoDB Atlas.

### 2. Agregar Nombre de Base de Datos

Agrega el nombre de la base de datos al final de la URI. Ejemplo:

```
mongodb+srv://njmartin96_db_user:TU_CONTRASEÑA@cluster0.x0sw3xh.mongodb.net/crm_inmobiliario?retryWrites=true&w=majority&appName=Cluster0
```

O si prefieres usar la base de datos existente:

```
mongodb+srv://njmartin96_db_user:TU_CONTRASEÑA@cluster0.x0sw3xh.mongodb.net/make-agent?retryWrites=true&w=majority&appName=Cluster0
```

### 3. Actualizar archivo `.env`

Edita el archivo `backend/.env` y actualiza la línea `MONGODB_URI`:

```env
MONGODB_URI=mongodb+srv://njmartin96_db_user:TU_CONTRASEÑA@cluster0.x0sw3xh.mongodb.net/crm_inmobiliario?retryWrites=true&w=majority&appName=Cluster0
```

**Reemplaza:**
- `TU_CONTRASEÑA` con tu contraseña real
- `crm_inmobiliario` con el nombre de tu base de datos (o `make-agent` si prefieres usar esa)

### 4. Verificar Conexión

Ejecuta:

```bash
cd backend
npm run check-db
```

Deberías ver:
```
✅ Conexión exitosa a MongoDB!
```

## Ejemplo Completo de `.env`

```env
# Server Configuration
PORT=5000
NODE_ENV=development

# MongoDB Atlas Connection String
MONGODB_URI=mongodb+srv://njmartin96_db_user:TU_CONTRASEÑA@cluster0.x0sw3xh.mongodb.net/crm_inmobiliario?retryWrites=true&w=majority&appName=Cluster0

# JWT Configuration
JWT_SECRET=tu_secreto_jwt_super_seguro_cambiar_en_produccion
JWT_EXPIRES_IN=7d

# OpenAI API Key
OPENAI_API_KEY=sk-tu-api-key-de-openai-aqui

# Make.com API Key (opcional)
MAKE_API_KEY=tu-make-api-key-aqui

# Admin User
ADMIN_EMAIL=admin@crm.com
ADMIN_PASSWORD=admin123
ADMIN_FIRST_NAME=Admin
ADMIN_LAST_NAME=Usuario
```

## ⚠️ Importante

1. **Whitelist de IPs**: Asegúrate de que tu IP esté en la whitelist de MongoDB Atlas
   - Ve a MongoDB Atlas → Network Access
   - Agrega tu IP actual o usa `0.0.0.0/0` para desarrollo (no recomendado en producción)

2. **Contraseña**: No compartas tu contraseña ni la subas a Git
   - El archivo `.env` debe estar en `.gitignore`

3. **Base de Datos**: MongoDB creará las colecciones automáticamente cuando insertes el primer documento

## Solución de Problemas

Si tienes errores de conexión:

1. Verifica que la contraseña sea correcta
2. Verifica que tu IP esté en la whitelist
3. Verifica que el nombre de usuario sea correcto: `njmartin96_db_user`
4. Verifica que el cluster esté activo en MongoDB Atlas


