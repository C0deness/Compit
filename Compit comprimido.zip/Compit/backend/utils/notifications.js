import Notification from '../models/Notification.js';

/**
 * Crea una notificación para un usuario
 */
export const createNotification = async (userId, type, title, message, link = null, metadata = {}) => {
  try {
    const notification = await Notification.create({
      user_id: userId,
      type,
      title,
      message,
      link,
      metadata,
    });
    return notification;
  } catch (error) {
    console.error('Error creando notificación:', error);
    return null;
  }
};

/**
 * Crea notificaciones para múltiples usuarios
 */
export const createNotificationsForUsers = async (userIds, type, title, message, link = null, metadata = {}) => {
  try {
    const notifications = userIds.map(userId => ({
      user_id: userId,
      type,
      title,
      message,
      link,
      metadata,
    }));

    await Notification.insertMany(notifications);
    return true;
  } catch (error) {
    console.error('Error creando notificaciones múltiples:', error);
    return false;
  }
};



