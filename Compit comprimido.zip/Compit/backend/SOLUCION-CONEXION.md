# 🔧 Solución: Error de Conexión a MongoDB

## Error Actual

```
❌ Error conectando a MongoDB: connect ECONNREFUSED ::1:27017, connect ECONNREFUSED 127.0.0.1:27017
```

Este error indica que está intentando conectarse a **localhost** en lugar de **MongoDB Atlas**.

## Causa

El archivo `backend/.env` no existe o no tiene la variable `MONGODB_URI` configurada correctamente.

## Solución Rápida

### Opción 1: Script Automático (Recomendado)

Ejecuta el script batch:

```cmd
cd backend
configurar-mongodb.bat
```

Este script te pedirá:
1. Tu contraseña de MongoDB Atlas
2. El nombre de la base de datos (opcional, por defecto: `crm_inmobiliario`)

### Opción 2: Manual

1. **Crea el archivo `backend/.env`** con este contenido:

```env
# Server Configuration
PORT=5000
NODE_ENV=development

# MongoDB Atlas Connection String
MONGODB_URI=mongodb+srv://njmartin96_db_user:TU_CONTRASEÑA@cluster0.x0sw3xh.mongodb.net/crm_inmobiliario?retryWrites=true&w=majority&appName=Cluster0

# JWT Configuration
JWT_SECRET=tu_secreto_jwt_super_seguro_cambiar_en_produccion
JWT_EXPIRES_IN=7d

# OpenAI API Key
OPENAI_API_KEY=sk-tu-api-key-de-openai-aqui

# Make.com API Key (opcional)
MAKE_API_KEY=tu-make-api-key-aqui

# Admin User
ADMIN_EMAIL=admin@crm.com
ADMIN_PASSWORD=admin123
ADMIN_FIRST_NAME=Admin
ADMIN_LAST_NAME=Usuario
```

2. **Reemplaza `TU_CONTRASEÑA`** con tu contraseña real de MongoDB Atlas

3. **Verifica la conexión:**
```cmd
npm run check-db
```

## Verificar que Funciona

Después de crear el `.env`, ejecuta:

```cmd
cd backend
npm run check-db
```

Deberías ver:
```
✅ Conectado a MongoDB: cluster0-shard-00-00.xxxxx.mongodb.net
✅ Conexión exitosa a MongoDB!
```

## Checklist

- [ ] Archivo `backend/.env` existe
- [ ] Variable `MONGODB_URI` está configurada
- [ ] La contraseña está correcta (sin espacios)
- [ ] El nombre de la base de datos está incluido en la URI
- [ ] Tu IP está en la whitelist de MongoDB Atlas

## Si Sigue Sin Funcionar

1. **Verifica la contraseña:**
   - Asegúrate de que no tenga espacios
   - Si tiene caracteres especiales, puede necesitar codificación URL

2. **Verifica la whitelist:**
   - Ve a MongoDB Atlas → Network Access
   - Agrega tu IP o usa `0.0.0.0/0` temporalmente para desarrollo

3. **Verifica el formato de la URI:**
   - Debe empezar con `mongodb+srv://`
   - Debe incluir el nombre de la base de datos antes del `?`
   - Los parámetros deben estar después del `?`

## Ejemplo de URI Correcta

```
mongodb+srv://njmartin96_db_user:miPassword123@cluster0.x0sw3xh.mongodb.net/crm_inmobiliario?retryWrites=true&w=majority&appName=Cluster0
```


