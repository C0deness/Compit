import express from 'express';
import { authenticateToken } from '../middleware/auth.js';
import News from '../models/News.js';
import OpenAI from 'openai';

const router = express.Router();
router.use(authenticateToken);

const openai = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

// Obtener todas las noticias del usuario
router.get('/', async (req, res) => {
  try {
    const { category, brand, model, is_read, limit = 50, page = 1 } = req.query;
    const query = { user_id: req.user.userId };

    if (category) query.category = category;
    if (brand) query.brand = brand;
    if (model) query.model = model;
    if (is_read !== undefined) query.is_read = is_read === 'true';

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const news = await News.find(query)
      .sort({ published_at: -1 })
      .limit(parseInt(limit))
      .skip(skip);

    const total = await News.countDocuments(query);

    res.json({
      news,
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(total / parseInt(limit)),
      },
    });
  } catch (error) {
    console.error('Error obteniendo noticias:', error);
    res.status(500).json({ error: 'Error al obtener noticias' });
  }
});

// Obtener una noticia específica
router.get('/:id', async (req, res) => {
  try {
    const news = await News.findOne({
      _id: req.params.id,
      user_id: req.user.userId,
    });

    if (!news) {
      return res.status(404).json({ error: 'Noticia no encontrada' });
    }

    res.json(news);
  } catch (error) {
    console.error('Error obteniendo noticia:', error);
    res.status(500).json({ error: 'Error al obtener noticia' });
  }
});

// Crear una nueva noticia (usado por scraping)
router.post('/', async (req, res) => {
  try {
    const {
      title,
      content,
      source,
      source_url,
      category,
      brand,
      model,
      price,
      competitor_id,
    } = req.body;

    // Generar resumen y keywords con IA
    let summary = '';
    let keywords = [];

    if (openai && content) {
      try {
        const prompt = `Analiza esta noticia sobre el mercado automovilístico y genera:
1. Un resumen conciso de máximo 150 palabras
2. Una lista de 5-10 palabras clave relevantes separadas por comas

Noticia:
${title}

${content}

Responde en formato JSON:
{
  "summary": "resumen aquí",
  "keywords": ["palabra1", "palabra2", ...]
}`;

        const completion = await openai.chat.completions.create({
          model: 'gpt-4',
          messages: [{ role: 'user', content: prompt }],
          response_format: { type: 'json_object' },
          temperature: 0.7,
        });

        const result = JSON.parse(completion.choices[0].message.content);
        summary = result.summary || '';
        keywords = result.keywords || [];
      } catch (aiError) {
        console.error('Error generando resumen con IA:', aiError);
        // Continuar sin resumen generado
      }
    }

    const news = await News.create({
      user_id: req.user.userId,
      title,
      content,
      summary,
      source,
      source_url,
      category: category || 'general',
      keywords,
      brand,
      model,
      price,
      competitor_id,
      relevance_score: calculateRelevanceScore(content, brand, model),
    });

    res.status(201).json(news);
  } catch (error) {
    console.error('Error creando noticia:', error);
    res.status(500).json({ error: 'Error al crear noticia' });
  }
});

// Marcar noticia como leída
router.patch('/:id/read', async (req, res) => {
  try {
    const news = await News.findOneAndUpdate(
      { _id: req.params.id, user_id: req.user.userId },
      { is_read: true },
      { new: true }
    );

    if (!news) {
      return res.status(404).json({ error: 'Noticia no encontrada' });
    }

    res.json(news);
  } catch (error) {
    console.error('Error marcando noticia como leída:', error);
    res.status(500).json({ error: 'Error al actualizar noticia' });
  }
});

// Eliminar noticia
router.delete('/:id', async (req, res) => {
  try {
    const news = await News.findOneAndDelete({
      _id: req.params.id,
      user_id: req.user.userId,
    });

    if (!news) {
      return res.status(404).json({ error: 'Noticia no encontrada' });
    }

    res.json({ message: 'Noticia eliminada correctamente' });
  } catch (error) {
    console.error('Error eliminando noticia:', error);
    res.status(500).json({ error: 'Error al eliminar noticia' });
  }
});

// Función auxiliar para calcular relevancia
function calculateRelevanceScore(content, brand, model) {
  let score = 50;
  if (brand) score += 20;
  if (model) score += 20;
  if (content && content.length > 200) score += 10;
  return Math.min(100, score);
}

export default router;
