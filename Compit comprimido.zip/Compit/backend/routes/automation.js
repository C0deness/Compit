import express from 'express';
import Workflow from '../models/Workflow.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();
router.use(authenticateToken);

// Obtener workflows
router.get('/workflows', async (req, res) => {
  try {
    const workflows = await Workflow.find({ user_id: req.user.userId }).sort({ createdAt: -1 });
    res.json(workflows);
  } catch (error) {
    console.error('Error obteniendo workflows:', error);
    res.status(500).json({ error: 'Error al obtener workflows' });
  }
});

// Crear workflow
router.post('/workflows', async (req, res) => {
  try {
    const { name, triggerType, triggerCondition, actions, isActive } = req.body;

    if (!name || !triggerType || !actions) {
      return res.status(400).json({ error: 'Nombre, tipo de trigger y acciones son requeridos' });
    }

    const workflow = await Workflow.create({
      user_id: req.user.userId,
      name,
      trigger_type: triggerType,
      trigger_condition: triggerCondition || null,
      actions,
      is_active: isActive !== undefined ? isActive : true,
    });

    res.status(201).json(workflow);
  } catch (error) {
    console.error('Error creando workflow:', error);
    res.status(500).json({ error: 'Error al crear workflow' });
  }
});

// Actualizar workflow
router.put('/workflows/:id', async (req, res) => {
  try {
    const { name, triggerType, triggerCondition, actions, isActive } = req.body;

    const updateData = {};
    if (name !== undefined) updateData.name = name;
    if (triggerType !== undefined) updateData.trigger_type = triggerType;
    if (triggerCondition !== undefined) updateData.trigger_condition = triggerCondition;
    if (actions !== undefined) updateData.actions = actions;
    if (isActive !== undefined) updateData.is_active = isActive;

    const workflow = await Workflow.findOneAndUpdate(
      { _id: req.params.id, user_id: req.user.userId },
      { $set: updateData },
      { new: true, runValidators: true }
    );

    if (!workflow) {
      return res.status(404).json({ error: 'Workflow no encontrado' });
    }

    res.json(workflow);
  } catch (error) {
    console.error('Error actualizando workflow:', error);
    res.status(500).json({ error: 'Error al actualizar workflow' });
  }
});

// Eliminar workflow
router.delete('/workflows/:id', async (req, res) => {
  try {
    const workflow = await Workflow.findOneAndDelete({
      _id: req.params.id,
      user_id: req.user.userId,
    });

    if (!workflow) {
      return res.status(404).json({ error: 'Workflow no encontrado' });
    }

    res.json({ message: 'Workflow eliminado exitosamente' });
  } catch (error) {
    console.error('Error eliminando workflow:', error);
    res.status(500).json({ error: 'Error al eliminar workflow' });
  }
});

export default router;
