import express from 'express';
import { authenticateToken } from '../middleware/auth.js';
import KPI from '../models/KPI.js';

const router = express.Router();
router.use(authenticateToken);

// Obtener todos los KPIs del usuario
router.get('/', async (req, res) => {
  try {
    const { category, period, limit = 100, page = 1 } = req.query;
    const query = { user_id: req.user.userId };

    if (category) query.category = category;
    if (period) query.period = period;

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const kpis = await KPI.find(query)
      .sort({ period_date: -1 })
      .limit(parseInt(limit))
      .skip(skip)
      .populate('metadata.competitor_id');

    const total = await KPI.countDocuments(query);

    res.json({
      kpis,
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(total / parseInt(limit)),
      },
    });
  } catch (error) {
    console.error('Error obteniendo KPIs:', error);
    res.status(500).json({ error: 'Error al obtener KPIs' });
  }
});

// Obtener KPIs agregados por categoría
router.get('/summary', async (req, res) => {
  try {
    const { period = 'monthly' } = req.query;

    const kpis = await KPI.find({
      user_id: req.user.userId,
      period,
    })
      .sort({ period_date: -1 })
      .limit(100);

    // Agrupar por categoría y calcular promedios/tendencias
    const summary = {};
    kpis.forEach((kpi) => {
      if (!summary[kpi.category]) {
        summary[kpi.category] = {
          category: kpi.category,
          values: [],
          trends: [],
        };
      }
      summary[kpi.category].values.push(kpi.value);
      if (kpi.trend) {
        summary[kpi.category].trends.push(kpi.trend);
      }
    });

    // Calcular estadísticas
    Object.keys(summary).forEach((category) => {
      const values = summary[category].values;
      const trends = summary[category].trends;
      summary[category] = {
        category,
        current: values[0] || 0,
        average: values.length > 0
          ? values.reduce((a, b) => a + b, 0) / values.length
          : 0,
        min: Math.min(...values),
        max: Math.max(...values),
        trend: trends.filter((t) => t === 'up').length >
          trends.filter((t) => t === 'down').length
          ? 'up'
          : trends.filter((t) => t === 'down').length >
            trends.filter((t) => t === 'up').length
          ? 'down'
          : 'stable',
        count: values.length,
      };
    });

    res.json({ summary: Object.values(summary) });
  } catch (error) {
    console.error('Error obteniendo resumen de KPIs:', error);
    res.status(500).json({ error: 'Error al obtener resumen de KPIs' });
  }
});

// Obtener un KPI específico
router.get('/:id', async (req, res) => {
  try {
    const kpi = await KPI.findOne({
      _id: req.params.id,
      user_id: req.user.userId,
    }).populate('metadata.competitor_id');

    if (!kpi) {
      return res.status(404).json({ error: 'KPI no encontrado' });
    }

    res.json(kpi);
  } catch (error) {
    console.error('Error obteniendo KPI:', error);
    res.status(500).json({ error: 'Error al obtener KPI' });
  }
});

// Crear un nuevo KPI
router.post('/', async (req, res) => {
  try {
    const {
      name,
      category,
      value,
      previous_value,
      unit,
      target_value,
      period,
      period_date,
      metadata,
    } = req.body;

    // Calcular tendencia y cambio porcentual
    let trend = 'stable';
    let change_percentage = 0;

    if (previous_value !== undefined && previous_value !== null) {
      change_percentage =
        previous_value !== 0
          ? ((value - previous_value) / previous_value) * 100
          : 0;

      if (change_percentage > 5) trend = 'up';
      else if (change_percentage < -5) trend = 'down';
    }

    const kpi = await KPI.create({
      user_id: req.user.userId,
      name,
      category,
      value,
      previous_value,
      unit: unit || 'unidad',
      trend,
      change_percentage,
      target_value,
      period: period || 'daily',
      period_date: period_date || new Date(),
      metadata: metadata || {},
    });

    res.status(201).json(kpi);
  } catch (error) {
    console.error('Error creando KPI:', error);
    res.status(500).json({ error: 'Error al crear KPI' });
  }
});

// Eliminar KPI
router.delete('/:id', async (req, res) => {
  try {
    const kpi = await KPI.findOneAndDelete({
      _id: req.params.id,
      user_id: req.user.userId,
    });

    if (!kpi) {
      return res.status(404).json({ error: 'KPI no encontrado' });
    }

    res.json({ message: 'KPI eliminado correctamente' });
  } catch (error) {
    console.error('Error eliminando KPI:', error);
    res.status(500).json({ error: 'Error al eliminar KPI' });
  }
});

export default router;
