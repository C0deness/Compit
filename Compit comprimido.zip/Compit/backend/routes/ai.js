import express from 'express';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import { authenticateToken } from '../middleware/auth.js';
import OpenAI from 'openai';
import Contact from '../models/Contact.js';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const router = express.Router();
router.use(authenticateToken);

// Función para consultar ASNEF (simulada - en producción usar API real)
async function consultarASNEF(dni, nombre, apellidos) {
  try {
    // En producción, aquí se haría una llamada real a la API de ASNEF
    // Por ahora, simulamos una consulta con lógica probabilística
    
    if (!dni) {
      return {
        has_debt: false,
        checked: false,
        message: 'DNI no disponible para consulta',
      };
    }

    // Simulación: 30% de probabilidad de tener deudas en mora
    // En producción, esto sería una consulta real a ASNEF
    const hasDebt = Math.random() < 0.3;
    
    if (!hasDebt) {
      return {
        has_debt: false,
        checked: true,
        checked_at: new Date(),
        total_debt: 0,
        debt_details: [],
        risk_level: 'low',
        message: 'Cliente sin deudas registradas en ASNEF',
      };
    }

    // Simular detalles de deudas
    const numDebts = Math.floor(Math.random() * 3) + 1; // 1-3 deudas
    const debtDetails = [];
    let totalDebt = 0;

    const creditors = ['Banco Popular', 'BBVA', 'Santander', 'CaixaBank', 'Banco Sabadell', 'Otro acreedor'];
    const statuses = ['En mora', 'Impagado', 'Proceso judicial'];

    for (let i = 0; i < numDebts; i++) {
      const amount = Math.floor(Math.random() * 50000) + 1000; // Entre 1,000 y 50,000
      totalDebt += amount;
      debtDetails.push({
        creditor: creditors[Math.floor(Math.random() * creditors.length)],
        amount: amount,
        status: statuses[Math.floor(Math.random() * statuses.length)],
        date: new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000), // Último año
      });
    }

    // Determinar nivel de riesgo
    let riskLevel = 'medium';
    if (totalDebt > 30000) riskLevel = 'very_high';
    else if (totalDebt > 15000) riskLevel = 'high';
    else if (totalDebt > 5000) riskLevel = 'medium';

    return {
      has_debt: true,
      checked: true,
      checked_at: new Date(),
      total_debt: totalDebt,
      debt_details: debtDetails,
      risk_level: riskLevel,
      message: `Cliente con ${numDebts} deuda(s) registrada(s) en ASNEF por un total de €${totalDebt.toLocaleString()}`,
    };
  } catch (error) {
    console.error('Error consultando ASNEF:', error);
    return {
      has_debt: false,
      checked: false,
      error: error.message,
      message: 'Error al consultar ASNEF',
    };
  }
}

// Configurar multer para subida de archivos
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, '../uploads');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, 'doc-' + uniqueSuffix + path.extname(file.originalname));
  },
});

const upload = multer({ 
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB max
});

const openai = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

// Asistente Rockit - Chat
router.post('/chat/mortgage', async (req, res) => {
  try {
    const { message, conversationHistory = [] } = req.body;

    if (!message) {
      return res.status(400).json({ error: 'Mensaje requerido' });
    }

    if (!openai) {
      // Respuesta mock si no hay API key
      return res.json({
        response:
          'Hola, soy tu Asistente Rockit. Puedo ayudarte con información sobre préstamos hipotecarios, tasas de interés, documentación requerida y más. ¿En qué puedo asistirte?',
      });
    }

    const systemPrompt = `Eres un experto Asistente Rockit especializado en asesoramiento inmobiliario y préstamos hipotecarios. 
    Tu función es:
    1. Pre-calificar a clientes para préstamos hipotecarios
    2. Explicar procesos hipotecarios de forma clara
    3. Guiar sobre documentación requerida
    4. Responder preguntas sobre tasas, plazos y condiciones
    5. Ofrecer información sobre diferentes tipos de préstamos
    
    Siempre sé profesional, amigable y educativo. Si no tienes información específica, recomienda consultar con un asesor financiero.
    Responde en español.`;

    const messages = [
      { role: 'system', content: systemPrompt },
      ...conversationHistory,
      { role: 'user', content: message },
    ];

    const completion = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: messages,
      temperature: 0.7,
      max_tokens: 500,
    });

    const response = completion.choices[0].message.content;

    res.json({ response });
  } catch (error) {
    console.error('Error en chat hipotecario:', error);
    res.status(500).json({ error: 'Error al procesar mensaje' });
  }
});

// Generador de contenido social para propiedades
router.post('/generate-social-content', async (req, res) => {
  try {
    const { propertyId } = req.body;

    if (!propertyId) {
      return res.status(400).json({ error: 'ID de propiedad requerido' });
    }

    // Obtener datos de la propiedad
    const propertyResult = await pool.query(
      'SELECT * FROM properties WHERE id = $1 AND user_id = $2',
      [propertyId, req.user.userId]
    );

    if (propertyResult.rows.length === 0) {
      return res.status(404).json({ error: 'Propiedad no encontrada' });
    }

    const property = propertyResult.rows[0];

    if (!openai) {
      // Respuesta mock
      return res.json({
        posts: [
          `🏠 Nueva propiedad disponible: ${property.title} - ${property.address}`,
          `✨ Oportunidad única en ${property.city}: ${property.title}. ${property.bedrooms} habitaciones, ${property.bathrooms} baños.`,
          `💰 Inversión inteligente: ${property.title}. Precio: $${property.price.toLocaleString()}`,
        ],
      });
    }

    const prompt = `Genera 5 ideas creativas de posts para redes sociales (Facebook, Instagram) sobre esta propiedad inmobiliaria:
    
    Título: ${property.title}
    Descripción: ${property.description || 'Sin descripción'}
    Tipo: ${property.type}
    Precio: $${property.price.toLocaleString()}
    Ubicación: ${property.address}, ${property.city}
    Características: ${property.bedrooms} habitaciones, ${property.bathrooms} baños, ${property.area_sqft} sqft
    
    Genera posts atractivos, con emojis apropiados, que destaquen las características principales y generen interés.
    Cada post debe ser máximo 280 caracteres.
    Responde en formato JSON con una clave "posts" que sea un array de strings.`;

    const completion = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [{ role: 'user', content: prompt }],
      response_format: { type: 'json_object' },
      temperature: 0.8,
    });

    const content = JSON.parse(completion.choices[0].message.content);

    res.json({
      posts: content.posts || [],
    });
  } catch (error) {
    console.error('Error generando contenido social:', error);
    res.status(500).json({ error: 'Error al generar contenido social' });
  }
});

// Extraer datos de documentos con IA y crear contacto automáticamente
router.post('/extract-document-data', upload.single('document'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Archivo requerido' });
    }

    const filePath = req.file.path;
    const fileName = req.file.originalname;

    // Leer el archivo como base64 para OpenAI Vision
    const fileBuffer = fs.readFileSync(filePath);
    const base64File = fileBuffer.toString('base64');
    const mimeType = req.file.mimetype;

    let extractedData = null;

    if (openai) {
      try {
        // Para imágenes, usar Vision API
        if (mimeType.startsWith('image/')) {
          const completion = await openai.chat.completions.create({
            model: 'gpt-4o',
            messages: [
              {
                role: 'user',
                content: [
                  {
                    type: 'text',
                    text: `Analiza este documento y extrae TODOS los datos disponibles. Responde SOLO con un JSON válido que contenga:
{
  "personalData": {
    "firstName": "string o null",
    "lastName": "string o null",
    "fullName": "string o null",
    "dni": "string o null",
    "email": "string o null",
    "phone": "string o null",
    "address": "string o null",
    "city": "string o null",
    "birthDate": "string o null",
    "nationality": "string o null"
  },
  "economicData": {
    "monthlyIncome": "number o null",
    "employmentStatus": "string o null",
    "employer": "string o null",
    "bankAccount": "string o null",
    "creditScore": "number o null",
    "debts": "number o null",
    "assets": "number o null"
  },
  "documentType": "string (DNI, estado de cuenta, comprobante, etc)",
  "confidence": "number entre 0 y 1"
}

Extrae TODO lo que puedas identificar. Si no encuentras un dato, usa null.`,
                  },
                  {
                    type: 'image_url',
                    image_url: {
                      url: `data:${mimeType};base64,${base64File}`,
                    },
                  },
                ],
              },
            ],
            max_tokens: 2000,
            response_format: { type: 'json_object' },
          });

          const content = completion.choices[0].message.content;
          extractedData = JSON.parse(content);
        } else {
          // Para PDFs y otros documentos, simular extracción
          // En producción, usar una librería de OCR o API especializada
          extractedData = {
            personalData: {
              firstName: null,
              lastName: null,
              fullName: null,
              dni: null,
              email: null,
              phone: null,
              address: null,
              city: null,
              birthDate: null,
              nationality: null,
            },
            economicData: {
              monthlyIncome: null,
              employmentStatus: null,
              employer: null,
              bankAccount: null,
              creditScore: null,
              debts: null,
              assets: null,
            },
            documentType: 'documento',
            confidence: 0.5,
          };
        }
      } catch (aiError) {
        console.error('Error en extracción con IA:', aiError);
        // Continuar con datos simulados
      }
    }

    // Si no hay datos extraídos, usar datos simulados
    if (!extractedData) {
      extractedData = {
        personalData: {
          firstName: null,
          lastName: null,
          fullName: null,
          dni: null,
          email: null,
          phone: null,
          address: null,
          city: null,
          birthDate: null,
          nationality: null,
        },
        economicData: {
          monthlyIncome: null,
          employmentStatus: null,
          employer: null,
          bankAccount: null,
          creditScore: null,
          debts: null,
          assets: null,
        },
        documentType: 'documento',
        confidence: 0.3,
      };
    }

    // Crear contacto automáticamente si hay datos personales
    let createdContact = null;
    if (extractedData.personalData && (extractedData.personalData.firstName || extractedData.personalData.fullName)) {
      try {
        const nameParts = extractedData.personalData.fullName
          ? extractedData.personalData.fullName.split(' ')
          : extractedData.personalData.firstName
          ? [extractedData.personalData.firstName, extractedData.personalData.lastName || '']
          : ['Cliente', 'Sin Nombre'];

        const firstName = nameParts[0] || extractedData.personalData.firstName || 'Cliente';
        const lastName = nameParts.slice(1).join(' ') || extractedData.personalData.lastName || 'Sin Apellido';

        // Verificar si el contacto ya existe (por email o DNI)
        let existingContact = null;
        if (extractedData.personalData.email) {
          existingContact = await Contact.findOne({
            user_id: req.user.userId,
            email: extractedData.personalData.email,
          });
        } else if (extractedData.personalData.dni) {
          // Si hay un campo DNI en el modelo, buscar por ahí
          // Por ahora, buscar por nombre completo
          existingContact = await Contact.findOne({
            user_id: req.user.userId,
            first_name: firstName,
            last_name: lastName,
          });
        }

        if (!existingContact) {
          // Consultar ASNEF si hay DNI disponible
          let asnefResult = null;
          if (extractedData.personalData.dni) {
            console.log(`Consultando ASNEF para DNI: ${extractedData.personalData.dni}`);
            asnefResult = await consultarASNEF(
              extractedData.personalData.dni,
              firstName,
              lastName
            );
          }

          // Calcular lead score inicial basado en datos disponibles
          let leadScore = 0;
          if (extractedData.personalData.email) leadScore += 10;
          if (extractedData.personalData.phone) leadScore += 10;
          if (extractedData.personalData.dni) leadScore += 15;
          if (extractedData.economicData.monthlyIncome) leadScore += 20;
          if (extractedData.economicData.employmentStatus) leadScore += 15;
          if (extractedData.economicData.creditScore) leadScore += 10;

          // Ajustar lead score basado en resultado ASNEF
          if (asnefResult && asnefResult.checked) {
            if (asnefResult.has_debt) {
              // Reducir score si hay deudas en mora
              if (asnefResult.risk_level === 'very_high') leadScore -= 30;
              else if (asnefResult.risk_level === 'high') leadScore -= 20;
              else if (asnefResult.risk_level === 'medium') leadScore -= 10;
              leadScore = Math.max(0, leadScore); // No permitir score negativo
            } else {
              // Aumentar score si no hay deudas
              leadScore += 10;
            }
          }

          const status = leadScore >= 50 ? 'caliente' : leadScore >= 30 ? 'tibio' : 'frio';

          // Crear notas con información económica y ASNEF
          const notes = [
            extractedData.economicData.monthlyIncome ? `Ingresos mensuales: $${extractedData.economicData.monthlyIncome}` : null,
            extractedData.economicData.employmentStatus ? `Estado laboral: ${extractedData.economicData.employmentStatus}` : null,
            extractedData.economicData.employer ? `Empleador: ${extractedData.economicData.employer}` : null,
            extractedData.economicData.creditScore ? `Score crediticio: ${extractedData.economicData.creditScore}` : null,
            extractedData.documentType ? `Tipo de documento: ${extractedData.documentType}` : null,
            asnefResult && asnefResult.checked ? `\n--- Consulta ASNEF ---\n${asnefResult.message}` : null,
            asnefResult && asnefResult.has_debt && asnefResult.debt_details ? 
              `\nDeudas: ${asnefResult.debt_details.map(d => `${d.creditor}: €${d.amount.toLocaleString()} (${d.status})`).join(', ')}` : null,
          ].filter(Boolean).join('\n');

          // Preparar datos de ASNEF para el contacto
          const asnefData = asnefResult && asnefResult.checked ? {
            has_debt: asnefResult.has_debt,
            checked_at: asnefResult.checked_at,
            total_debt: asnefResult.total_debt || null,
            debt_details: asnefResult.debt_details || [],
            risk_level: asnefResult.risk_level || null,
          } : {
            has_debt: false,
            checked_at: null,
            total_debt: null,
            debt_details: [],
            risk_level: null,
          };

          createdContact = await Contact.create({
            user_id: req.user.userId,
            first_name: firstName,
            last_name: lastName,
            email: extractedData.personalData.email || null,
            phone: extractedData.personalData.phone || null,
            status: status,
            source: 'Extracción automática de documento',
            notes: notes || null,
            lead_score: Math.min(100, Math.max(0, leadScore)),
            asnef_check: asnefData,
          });
        } else {
          // Si el contacto ya existe, actualizar consulta ASNEF si hay DNI nuevo
          if (extractedData.personalData.dni && (!existingContact.asnef_check || !existingContact.asnef_check.checked_at)) {
            console.log(`Consultando ASNEF para contacto existente con DNI: ${extractedData.personalData.dni}`);
            const asnefResult = await consultarASNEF(
              extractedData.personalData.dni,
              existingContact.first_name,
              existingContact.last_name
            );

            if (asnefResult && asnefResult.checked) {
              existingContact.asnef_check = {
                has_debt: asnefResult.has_debt,
                checked_at: asnefResult.checked_at,
                total_debt: asnefResult.total_debt || null,
                debt_details: asnefResult.debt_details || [],
                risk_level: asnefResult.risk_level || null,
              };

              // Actualizar notas con información ASNEF
              const existingNotes = existingContact.notes || '';
              const asnefNote = `\n--- Consulta ASNEF (${new Date().toLocaleDateString()}) ---\n${asnefResult.message}`;
              existingContact.notes = existingNotes + asnefNote;

              await existingContact.save();
            }
          }
          createdContact = existingContact;
        }
      } catch (contactError) {
        console.error('Error creando contacto:', contactError);
        // Continuar aunque falle la creación del contacto
      }
    }

    // Limpiar archivo temporal después de procesarlo
    try {
      fs.unlinkSync(filePath);
    } catch (unlinkError) {
      console.error('Error eliminando archivo temporal:', unlinkError);
    }

    // Obtener información ASNEF del contacto creado/actualizado
    let asnefInfo = null;
    if (createdContact && createdContact.asnef_check) {
      asnefInfo = {
        has_debt: createdContact.asnef_check.has_debt,
        checked: createdContact.asnef_check.checked_at !== null,
        checked_at: createdContact.asnef_check.checked_at,
        total_debt: createdContact.asnef_check.total_debt,
        risk_level: createdContact.asnef_check.risk_level,
        debt_details: createdContact.asnef_check.debt_details || [],
      };
    }

    res.json({
      success: true,
      extractedData: extractedData,
      contactCreated: createdContact ? {
        id: createdContact._id,
        name: `${createdContact.first_name} ${createdContact.last_name}`,
        email: createdContact.email,
        leadScore: createdContact.lead_score,
        asnef: asnefInfo,
      } : null,
      asnefCheck: asnefInfo,
      message: createdContact
        ? 'Documento procesado y cliente creado automáticamente'
        : 'Documento procesado (cliente ya existía o no se pudieron extraer datos suficientes)',
    });
  } catch (error) {
    console.error('Error extrayendo datos del documento:', error);
    res.status(500).json({ error: 'Error al procesar documento', details: error.message });
  }
});

export default router;

