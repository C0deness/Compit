import express from 'express';
import Property from '../models/Property.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

router.use(authenticateToken);

// Obtener todas las propiedades
router.get('/', async (req, res) => {
  try {
    const { status, type, search, minPrice, maxPrice } = req.query;
    const query = { user_id: req.user.userId };

    if (status) query.status = status;
    if (type) query.type = type;
    if (minPrice) query.price = { ...query.price, $gte: Number(minPrice) };
    if (maxPrice) query.price = { ...query.price, $lte: Number(maxPrice) };

    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { address: { $regex: search, $options: 'i' } },
        { city: { $regex: search, $options: 'i' } },
      ];
    }

    const properties = await Property.find(query).sort({ createdAt: -1 });
    res.json(properties);
  } catch (error) {
    console.error('Error obteniendo propiedades:', error);
    res.status(500).json({ error: 'Error al obtener propiedades' });
  }
});

// Obtener una propiedad por ID
router.get('/:id', async (req, res) => {
  try {
    const property = await Property.findOne({
      _id: req.params.id,
      user_id: req.user.userId,
    });

    if (!property) {
      return res.status(404).json({ error: 'Propiedad no encontrada' });
    }

    res.json(property);
  } catch (error) {
    console.error('Error obteniendo propiedad:', error);
    res.status(500).json({ error: 'Error al obtener propiedad' });
  }
});

// Crear nueva propiedad
router.post('/', async (req, res) => {
  try {
    const {
      title,
      description,
      type,
      price,
      address,
      city,
      state,
      zipCode,
      latitude,
      longitude,
      bedrooms,
      bathrooms,
      areaSqft,
      yearBuilt,
      status,
      images,
      features,
    } = req.body;

    if (!title || !type || !price) {
      return res.status(400).json({ error: 'Título, tipo y precio son requeridos' });
    }

    const property = await Property.create({
      user_id: req.user.userId,
      title,
      description: description || null,
      type,
      price: Number(price),
      address: address || null,
      city: city || null,
      state: state || null,
      zip_code: zipCode || null,
      latitude: latitude ? Number(latitude) : null,
      longitude: longitude ? Number(longitude) : null,
      bedrooms: bedrooms ? Number(bedrooms) : null,
      bathrooms: bathrooms ? Number(bathrooms) : null,
      area_sqft: areaSqft ? Number(areaSqft) : null,
      year_built: yearBuilt ? Number(yearBuilt) : null,
      status: status || 'available',
      images: images || [],
      features: features || [],
    });

    res.status(201).json(property);
  } catch (error) {
    console.error('Error creando propiedad:', error);
    res.status(500).json({ error: 'Error al crear propiedad' });
  }
});

// Actualizar propiedad
router.put('/:id', async (req, res) => {
  try {
    const {
      title,
      description,
      type,
      price,
      address,
      city,
      state,
      zipCode,
      latitude,
      longitude,
      bedrooms,
      bathrooms,
      areaSqft,
      yearBuilt,
      status,
      images,
      features,
    } = req.body;

    const updateData = {};
    if (title !== undefined) updateData.title = title;
    if (description !== undefined) updateData.description = description;
    if (type !== undefined) updateData.type = type;
    if (price !== undefined) updateData.price = Number(price);
    if (address !== undefined) updateData.address = address;
    if (city !== undefined) updateData.city = city;
    if (state !== undefined) updateData.state = state;
    if (zipCode !== undefined) updateData.zip_code = zipCode;
    if (latitude !== undefined) updateData.latitude = latitude ? Number(latitude) : null;
    if (longitude !== undefined) updateData.longitude = longitude ? Number(longitude) : null;
    if (bedrooms !== undefined) updateData.bedrooms = bedrooms ? Number(bedrooms) : null;
    if (bathrooms !== undefined) updateData.bathrooms = bathrooms ? Number(bathrooms) : null;
    if (areaSqft !== undefined) updateData.area_sqft = areaSqft ? Number(areaSqft) : null;
    if (yearBuilt !== undefined) updateData.year_built = yearBuilt ? Number(yearBuilt) : null;
    if (status !== undefined) updateData.status = status;
    if (images !== undefined) updateData.images = images;
    if (features !== undefined) updateData.features = features;

    const property = await Property.findOneAndUpdate(
      { _id: req.params.id, user_id: req.user.userId },
      { $set: updateData },
      { new: true, runValidators: true }
    );

    if (!property) {
      return res.status(404).json({ error: 'Propiedad no encontrada' });
    }

    res.json(property);
  } catch (error) {
    console.error('Error actualizando propiedad:', error);
    res.status(500).json({ error: 'Error al actualizar propiedad' });
  }
});

// Eliminar propiedad
router.delete('/:id', async (req, res) => {
  try {
    const property = await Property.findOneAndDelete({
      _id: req.params.id,
      user_id: req.user.userId,
    });

    if (!property) {
      return res.status(404).json({ error: 'Propiedad no encontrada' });
    }

    res.json({ message: 'Propiedad eliminada exitosamente' });
  } catch (error) {
    console.error('Error eliminando propiedad:', error);
    res.status(500).json({ error: 'Error al eliminar propiedad' });
  }
});

export default router;
