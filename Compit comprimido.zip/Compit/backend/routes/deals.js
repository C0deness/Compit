import express from 'express';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import Deal from '../models/Deal.js';
import Document from '../models/Document.js';
import Contact from '../models/Contact.js';
import Property from '../models/Property.js';
import { authenticateToken } from '../middleware/auth.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const router = express.Router();
router.use(authenticateToken);

// Configurar multer para subida de archivos
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, '../uploads'));
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  },
});

const upload = multer({ storage });

// Obtener todos los deals
router.get('/', async (req, res) => {
  try {
    const { status } = req.query;
    const query = { user_id: req.user.userId };
    if (status) query.status = status;

    const deals = await Deal.find(query)
      .populate('contact_id', 'first_name last_name email')
      .populate('property_id', 'title address')
      .sort({ createdAt: -1 });

    // Formatear respuesta
    const formattedDeals = deals.map(deal => ({
      ...deal.toObject(),
      contact_first_name: deal.contact_id?.first_name,
      contact_last_name: deal.contact_id?.last_name,
      contact_email: deal.contact_id?.email,
      property_title: deal.property_id?.title,
      property_address: deal.property_id?.address,
    }));

    res.json(formattedDeals);
  } catch (error) {
    console.error('Error obteniendo deals:', error);
    res.status(500).json({ error: 'Error al obtener deals' });
  }
});

// Obtener un deal por ID con documentos
router.get('/:id', async (req, res) => {
  try {
    const deal = await Deal.findOne({
      _id: req.params.id,
      user_id: req.user.userId,
    })
      .populate('contact_id', 'first_name last_name email')
      .populate('property_id', 'title address');

    if (!deal) {
      return res.status(404).json({ error: 'Deal no encontrado' });
    }

    const documents = await Document.find({ deal_id: req.params.id }).sort({ uploaded_at: -1 });

    const dealObj = deal.toObject();
    dealObj.documents = documents;
    dealObj.contact_first_name = deal.contact_id?.first_name;
    dealObj.contact_last_name = deal.contact_id?.last_name;
    dealObj.contact_email = deal.contact_id?.email;
    dealObj.property_title = deal.property_id?.title;
    dealObj.property_address = deal.property_id?.address;

    res.json(dealObj);
  } catch (error) {
    console.error('Error obteniendo deal:', error);
    res.status(500).json({ error: 'Error al obtener deal' });
  }
});

// Crear nuevo deal
router.post('/', async (req, res) => {
  try {
    const { contactId, propertyId, type, offerPrice, closingDate, commission, notes } = req.body;

    if (!type) {
      return res.status(400).json({ error: 'El tipo de deal es requerido' });
    }

    const deal = await Deal.create({
      user_id: req.user.userId,
      contact_id: contactId || null,
      property_id: propertyId || null,
      type,
      offer_price: offerPrice || null,
      closing_date: closingDate || null,
      commission: commission || null,
      notes: notes || null,
    });

    res.status(201).json(deal);
  } catch (error) {
    console.error('Error creando deal:', error);
    res.status(500).json({ error: 'Error al crear deal' });
  }
});

// Actualizar deal
router.put('/:id', async (req, res) => {
  try {
    const { contactId, propertyId, type, status, offerPrice, closingDate, commission, notes } =
      req.body;

    const updateData = {};
    if (contactId !== undefined) updateData.contact_id = contactId;
    if (propertyId !== undefined) updateData.property_id = propertyId;
    if (type !== undefined) updateData.type = type;
    if (status !== undefined) updateData.status = status;
    if (offerPrice !== undefined) updateData.offer_price = offerPrice;
    if (closingDate !== undefined) updateData.closing_date = closingDate;
    if (commission !== undefined) updateData.commission = commission;
    if (notes !== undefined) updateData.notes = notes;

    const deal = await Deal.findOneAndUpdate(
      { _id: req.params.id, user_id: req.user.userId },
      { $set: updateData },
      { new: true, runValidators: true }
    );

    if (!deal) {
      return res.status(404).json({ error: 'Deal no encontrado' });
    }

    res.json(deal);
  } catch (error) {
    console.error('Error actualizando deal:', error);
    res.status(500).json({ error: 'Error al actualizar deal' });
  }
});

// Subir documento
router.post('/:id/documents', upload.single('document'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Archivo requerido' });
    }

    const { name, type } = req.body;

    // Simular análisis de documento
    const validationData = {
      documentType: type || 'unknown',
      extracted: true,
      validated: false,
      confidence: 0.85,
    };

    const document = await Document.create({
      deal_id: req.params.id,
      name: name || req.file.originalname,
      type: type || 'other',
      file_path: `/uploads/${req.file.filename}`,
      status: 'pending',
      validation_data: validationData,
    });

    res.status(201).json(document);
  } catch (error) {
    console.error('Error subiendo documento:', error);
    res.status(500).json({ error: 'Error al subir documento' });
  }
});

// Actualizar estado de documento
router.put('/:id/documents/:docId', async (req, res) => {
  try {
    const { status, validationData } = req.body;

    const updateData = {};
    if (status) {
      updateData.status = status;
      if (status === 'validated') {
        updateData.validated_at = new Date();
      }
    }
    if (validationData) updateData.validation_data = validationData;

    const document = await Document.findOneAndUpdate(
      { _id: req.params.docId, deal_id: req.params.id },
      { $set: updateData },
      { new: true }
    );

    if (!document) {
      return res.status(404).json({ error: 'Documento no encontrado' });
    }

    res.json(document);
  } catch (error) {
    console.error('Error actualizando documento:', error);
    res.status(500).json({ error: 'Error al actualizar documento' });
  }
});

export default router;
