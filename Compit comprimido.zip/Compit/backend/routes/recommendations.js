import express from 'express';
import { authenticateToken } from '../middleware/auth.js';
import Recommendation from '../models/Recommendation.js';

const router = express.Router();
router.use(authenticateToken);

// Obtener todas las recomendaciones del usuario
router.get('/', async (req, res) => {
  try {
    const { type, status, limit = 50, page = 1 } = req.query;
    const query = { user_id: req.user.userId };

    if (type) query.type = type;
    if (status) query.status = status;

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const recommendations = await Recommendation.find(query)
      .sort({ created_at: -1 })
      .limit(parseInt(limit))
      .skip(skip)
      .populate('related_data.competitor_id')
      .populate('related_data.kpi_id');

    const total = await Recommendation.countDocuments(query);

    res.json({
      recommendations,
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(total / parseInt(limit)),
      },
    });
  } catch (error) {
    console.error('Error obteniendo recomendaciones:', error);
    res.status(500).json({ error: 'Error al obtener recomendaciones' });
  }
});

// Obtener una recomendación específica
router.get('/:id', async (req, res) => {
  try {
    const recommendation = await Recommendation.findOne({
      _id: req.params.id,
      user_id: req.user.userId,
    })
      .populate('related_data.competitor_id')
      .populate('related_data.kpi_id');

    if (!recommendation) {
      return res.status(404).json({ error: 'Recomendación no encontrada' });
    }

    res.json(recommendation);
  } catch (error) {
    console.error('Error obteniendo recomendación:', error);
    res.status(500).json({ error: 'Error al obtener recomendación' });
  }
});

// Crear una nueva recomendación
router.post('/', async (req, res) => {
  try {
    const {
      type,
      title,
      description,
      action_items,
      expected_impact,
      confidence_score,
      related_data,
    } = req.body;

    const recommendation = await Recommendation.create({
      user_id: req.user.userId,
      type,
      title,
      description,
      action_items: action_items || [],
      expected_impact: expected_impact || 'medium',
      confidence_score: confidence_score || 50,
      related_data: related_data || {},
    });

    res.status(201).json(recommendation);
  } catch (error) {
    console.error('Error creando recomendación:', error);
    res.status(500).json({ error: 'Error al crear recomendación' });
  }
});

// Actualizar estado de recomendación
router.patch('/:id/status', async (req, res) => {
  try {
    const { status, results } = req.body;

    const updateData = { status };
    if (status === 'completed' || status === 'in_progress') {
      updateData.acted_upon_at = new Date();
    }
    if (results) {
      updateData.results = results;
    }

    const recommendation = await Recommendation.findOneAndUpdate(
      { _id: req.params.id, user_id: req.user.userId },
      updateData,
      { new: true }
    );

    if (!recommendation) {
      return res.status(404).json({ error: 'Recomendación no encontrada' });
    }

    res.json(recommendation);
  } catch (error) {
    console.error('Error actualizando recomendación:', error);
    res.status(500).json({ error: 'Error al actualizar recomendación' });
  }
});

// Eliminar recomendación
router.delete('/:id', async (req, res) => {
  try {
    const recommendation = await Recommendation.findOneAndDelete({
      _id: req.params.id,
      user_id: req.user.userId,
    });

    if (!recommendation) {
      return res.status(404).json({ error: 'Recomendación no encontrada' });
    }

    res.json({ message: 'Recomendación eliminada correctamente' });
  } catch (error) {
    console.error('Error eliminando recomendación:', error);
    res.status(500).json({ error: 'Error al eliminar recomendación' });
  }
});

export default router;
