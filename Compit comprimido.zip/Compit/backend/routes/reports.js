import express from 'express';
import { authenticateToken } from '../middleware/auth.js';
import Contact from '../models/Contact.js';
import Deal from '../models/Deal.js';
import Property from '../models/Property.js';
import Financing from '../models/Financing.js';
import User from '../models/User.js';
import { generateMonthlyReportPDF, generateConsolidatedReportPDF } from '../services/pdfGenerator.js';

const router = express.Router();

// Todas las rutas requieren autenticación
router.use(authenticateToken);

// Generar reporte de contactos
router.get('/contacts', async (req, res) => {
  try {
    const { status, startDate, endDate } = req.query;
    const query = { user_id: req.user.userId };

    if (status) {
      query.status = status;
    }

    if (startDate || endDate) {
      query.createdAt = {};
      if (startDate) query.createdAt.$gte = new Date(startDate);
      if (endDate) query.createdAt.$lte = new Date(endDate);
    }

    const contacts = await Contact.find(query).sort({ createdAt: -1 });

    // Formatear datos para exportación
    const reportData = contacts.map(contact => ({
      Nombre: `${contact.first_name || ''} ${contact.last_name || ''}`.trim(),
      Email: contact.email || '',
      Teléfono: contact.phone || '',
      Estado: contact.status || '',
      'Lead Score': contact.lead_score || 0,
      Fuente: contact.source || '',
      'Fecha Creación': contact.createdAt ? new Date(contact.createdAt).toLocaleDateString('es-ES') : '',
    }));

    res.json({
      type: 'contacts',
      total: contacts.length,
      data: reportData,
      generatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Error generando reporte de contactos:', error);
    res.status(500).json({ error: 'Error al generar reporte' });
  }
});

// Generar reporte de deals
router.get('/deals', async (req, res) => {
  try {
    const { status, startDate, endDate } = req.query;
    const query = { user_id: req.user.userId };

    if (status) {
      query.status = status;
    }

    if (startDate || endDate) {
      query.createdAt = {};
      if (startDate) query.createdAt.$gte = new Date(startDate);
      if (endDate) query.createdAt.$lte = new Date(endDate);
    }

    const deals = await Deal.find(query)
      .populate('contact_id', 'first_name last_name email')
      .populate('property_id', 'title address price')
      .sort({ createdAt: -1 });

    const reportData = deals.map(deal => ({
      'ID Transacción': deal._id.toString().substring(0, 8),
      Tipo: deal.type || '',
      Estado: deal.status || '',
      Cliente: deal.contact_id 
        ? `${deal.contact_id.first_name || ''} ${deal.contact_id.last_name || ''}`.trim()
        : 'Sin cliente',
      'Email Cliente': deal.contact_id?.email || '',
      Propiedad: deal.property_id?.title || 'Sin propiedad',
      'Precio Oferta': deal.offer_price ? `€${deal.offer_price.toLocaleString()}` : '',
      'Fecha Cierre': deal.closing_date ? new Date(deal.closing_date).toLocaleDateString('es-ES') : '',
      Comisión: deal.commission ? `€${deal.commission.toLocaleString()}` : '',
      'Fecha Creación': deal.createdAt ? new Date(deal.createdAt).toLocaleDateString('es-ES') : '',
    }));

    const totalValue = deals.reduce((sum, deal) => sum + (Number(deal.offer_price) || 0), 0);
    const closedDeals = deals.filter(d => d.status === 'closed').length;

    res.json({
      type: 'deals',
      total: deals.length,
      closed: closedDeals,
      totalValue,
      data: reportData,
      generatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Error generando reporte de deals:', error);
    res.status(500).json({ error: 'Error al generar reporte' });
  }
});

// Generar reporte de propiedades
router.get('/properties', async (req, res) => {
  try {
    const { status, type, startDate, endDate } = req.query;
    const query = { user_id: req.user.userId };

    if (status) {
      query.status = status;
    }

    if (type) {
      query.type = type;
    }

    if (startDate || endDate) {
      query.createdAt = {};
      if (startDate) query.createdAt.$gte = new Date(startDate);
      if (endDate) query.createdAt.$lte = new Date(endDate);
    }

    const properties = await Property.find(query).sort({ createdAt: -1 });

    const reportData = properties.map(property => ({
      Título: property.title || '',
      Tipo: property.type || '',
      Estado: property.status || '',
      Precio: property.price ? `€${property.price.toLocaleString()}` : '',
      Dirección: property.address || '',
      Ciudad: property.city || '',
      Habitaciones: property.bedrooms || '',
      Baños: property.bathrooms || '',
      'Área (sqft)': property.area_sqft || '',
      'Año Construcción': property.year_built || '',
      'Fecha Creación': property.createdAt ? new Date(property.createdAt).toLocaleDateString('es-ES') : '',
    }));

    const totalValue = properties.reduce((sum, prop) => sum + (Number(prop.price) || 0), 0);
    const available = properties.filter(p => p.status === 'available').length;

    res.json({
      type: 'properties',
      total: properties.length,
      available,
      totalValue,
      data: reportData,
      generatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Error generando reporte de propiedades:', error);
    res.status(500).json({ error: 'Error al generar reporte' });
  }
});

// Generar reporte de financiación
router.get('/financing', async (req, res) => {
  try {
    const { status, loan_type, startDate, endDate } = req.query;
    const query = { user_id: req.user.userId };

    if (status) {
      query.status = status;
    }

    if (loan_type) {
      query.loan_type = loan_type;
    }

    if (startDate || endDate) {
      query.createdAt = {};
      if (startDate) query.createdAt.$gte = new Date(startDate);
      if (endDate) query.createdAt.$lte = new Date(endDate);
    }

    const financings = await Financing.find(query)
      .populate('contact_id', 'first_name last_name email')
      .sort({ createdAt: -1 });

    const reportData = financings.map(financing => ({
      Cliente: financing.contact_id 
        ? `${financing.contact_id.first_name || ''} ${financing.contact_id.last_name || ''}`.trim()
        : 'Sin cliente',
      'Email Cliente': financing.contact_id?.email || '',
      'Tipo Préstamo': financing.loan_type || '',
      Estado: financing.status || '',
      'Monto Préstamo': financing.loan_amount ? `€${financing.loan_amount.toLocaleString()}` : '',
      'Tasa Interés': financing.interest_rate ? `${financing.interest_rate}%` : '',
      Plazo: financing.loan_term ? `${financing.loan_term} años` : '',
      'Pago Mensual': financing.monthly_payment ? `€${financing.monthly_payment.toLocaleString()}` : '',
      'Pago Inicial': financing.down_payment ? `€${financing.down_payment.toLocaleString()}` : '',
      Prestamista: financing.lender_name || '',
      'Score Crediticio': financing.credit_score || '',
      'Fecha Creación': financing.createdAt ? new Date(financing.createdAt).toLocaleDateString('es-ES') : '',
    }));

    const totalAmount = financings.reduce((sum, f) => sum + (Number(f.loan_amount) || 0), 0);
    const approved = financings.filter(f => f.status === 'approved').length;

    res.json({
      type: 'financing',
      total: financings.length,
      approved,
      totalAmount,
      data: reportData,
      generatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Error generando reporte de financiación:', error);
    res.status(500).json({ error: 'Error al generar reporte' });
  }
});

// Reporte consolidado (dashboard)
router.get('/dashboard', async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    const dateFilter = {};
    if (startDate || endDate) {
      dateFilter.createdAt = {};
      if (startDate) dateFilter.createdAt.$gte = new Date(startDate);
      if (endDate) dateFilter.createdAt.$lte = new Date(endDate);
    }

    const userId = req.user.userId;

    const [contacts, deals, properties, financings] = await Promise.all([
      Contact.countDocuments({ user_id: userId, ...dateFilter }),
      Deal.find({ user_id: userId, ...dateFilter }),
      Property.find({ user_id: userId, ...dateFilter }),
      Financing.find({ user_id: userId, ...dateFilter }),
    ]);

    const closedDeals = deals.filter(d => d.status === 'closed');
    const totalRevenue = closedDeals.reduce((sum, d) => sum + (Number(d.offer_price) || 0), 0);
    const totalPropertiesValue = properties.reduce((sum, p) => sum + (Number(p.price) || 0), 0);
    const totalFinancingAmount = financings.reduce((sum, f) => sum + (Number(f.loan_amount) || 0), 0);

    res.json({
      type: 'dashboard',
      period: {
        start: startDate || null,
        end: endDate || null,
      },
      summary: {
        contacts,
        deals: deals.length,
        closedDeals: closedDeals.length,
        properties: properties.length,
        financings: financings.length,
        totalRevenue,
        totalPropertiesValue,
        totalFinancingAmount,
      },
      generatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Error generando reporte consolidado:', error);
    res.status(500).json({ error: 'Error al generar reporte' });
  }
});

// Generar PDF de reporte mensual
router.get('/monthly/pdf', async (req, res) => {
  try {
    const { month, year } = req.query;
    const currentDate = new Date();
    const reportMonth = month || currentDate.getMonth() + 1;
    const reportYear = year || currentDate.getFullYear();

    const userId = req.user.userId;

    // Obtener datos del mes
    const startDate = new Date(reportYear, reportMonth - 1, 1);
    const endDate = new Date(reportYear, reportMonth, 0, 23, 59, 59);

    const [contacts, deals, properties, financings, user] = await Promise.all([
      Contact.find({
        user_id: userId,
        createdAt: { $gte: startDate, $lte: endDate },
      }),
      Deal.find({
        user_id: userId,
        createdAt: { $gte: startDate, $lte: endDate },
      })
        .populate('contact_id', 'first_name last_name email')
        .populate('property_id', 'title address price'),
      Property.find({
        user_id: userId,
        createdAt: { $gte: startDate, $lte: endDate },
      }),
      Financing.find({
        user_id: userId,
        createdAt: { $gte: startDate, $lte: endDate },
      })
        .populate('contact_id', 'first_name last_name email'),
      User.findById(userId),
    ]);

    const closedDeals = deals.filter(d => d.status === 'closed');
    const totalRevenue = closedDeals.reduce((sum, d) => sum + (Number(d.offer_price) || 0), 0);

    const monthNames = [
      'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
      'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
    ];

    const stats = {
      totalContacts: contacts.length,
      totalDeals: deals.length,
      closedDeals: closedDeals.length,
      totalProperties: properties.length,
      totalRevenue,
      totalFinancings: financings.length,
    };

    const data = {
      month: monthNames[reportMonth - 1],
      year: reportYear.toString(),
      contacts,
      deals,
      properties,
      financings,
      stats,
      userInfo: user ? {
        first_name: user.first_name,
        last_name: user.last_name,
        email: user.email,
      } : null,
    };

    const doc = await generateMonthlyReportPDF(data);

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="reporte-mensual-${reportMonth}-${reportYear}.pdf"`);

    doc.pipe(res);
    doc.end();
  } catch (error) {
    console.error('Error generando PDF mensual:', error);
    console.error('Stack trace:', error.stack);
    res.status(500).json({ 
      error: 'Error al generar PDF',
      message: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Generar PDF de reporte consolidado
router.get('/consolidated/pdf', async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    const userId = req.user.userId;

    const dateFilter = {};
    if (startDate || endDate) {
      dateFilter.createdAt = {};
      if (startDate) dateFilter.createdAt.$gte = new Date(startDate);
      if (endDate) dateFilter.createdAt.$lte = new Date(endDate);
    }

    const [contacts, deals, properties, financings, user] = await Promise.all([
      Contact.find({ user_id: userId, ...dateFilter }),
      Deal.find({ user_id: userId, ...dateFilter })
        .populate('contact_id', 'first_name last_name email')
        .populate('property_id', 'title address price'),
      Property.find({ user_id: userId, ...dateFilter }),
      Financing.find({ user_id: userId, ...dateFilter })
        .populate('contact_id', 'first_name last_name email'),
      User.findById(userId),
    ]);

    const closedDeals = deals.filter(d => d.status === 'closed');
    const totalRevenue = closedDeals.reduce((sum, d) => sum + (Number(d.offer_price) || 0), 0);
    const totalPropertiesValue = properties.reduce((sum, p) => sum + (Number(p.price) || 0), 0);
    const totalFinancingAmount = financings.reduce((sum, f) => sum + (Number(f.loan_amount) || 0), 0);

    const summary = {
      contacts: contacts.length,
      deals: deals.length,
      closedDeals: closedDeals.length,
      properties: properties.length,
      financings: financings.length,
      totalRevenue,
      totalPropertiesValue,
      totalFinancingAmount,
    };

    const data = {
      period: {
        start: startDate || null,
        end: endDate || null,
      },
      summary,
      contacts,
      deals,
      properties,
      financings,
      userInfo: user ? {
        first_name: user.first_name,
        last_name: user.last_name,
        email: user.email,
      } : null,
    };

    const doc = await generateConsolidatedReportPDF(data);

    const filename = startDate && endDate
      ? `reporte-consolidado-${startDate}-${endDate}.pdf`
      : `reporte-consolidado-${new Date().toISOString().split('T')[0]}.pdf`;

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);

    doc.pipe(res);
    doc.end();
  } catch (error) {
    console.error('Error generando PDF consolidado:', error);
    console.error('Stack trace:', error.stack);
    res.status(500).json({ 
      error: 'Error al generar PDF',
      message: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

export default router;

