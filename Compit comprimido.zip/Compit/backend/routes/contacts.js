import express from 'express';
import Contact from '../models/Contact.js';
import LeadActivity from '../models/LeadActivity.js';

const router = express.Router();

import { authenticateToken } from '../middleware/auth.js';

router.use(authenticateToken);

// Obtener todos los contactos
router.get('/', async (req, res) => {
  try {
    const { status, search } = req.query;
    const query = { user_id: req.user.userId };

    if (status) {
      query.status = status;
    }

    if (search) {
      query.$or = [
        { first_name: { $regex: search, $options: 'i' } },
        { last_name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
      ];
    }

    const contacts = await Contact.find(query).sort({ createdAt: -1 });
    res.json(contacts);
  } catch (error) {
    console.error('Error obteniendo contactos:', error);
    res.status(500).json({ error: 'Error al obtener contactos' });
  }
});

// Obtener un contacto por ID
router.get('/:id', async (req, res) => {
  try {
    const contact = await Contact.findOne({
      _id: req.params.id,
      user_id: req.user.userId,
    });

    if (!contact) {
      return res.status(404).json({ error: 'Contacto no encontrado' });
    }

    res.json(contact);
  } catch (error) {
    console.error('Error obteniendo contacto:', error);
    res.status(500).json({ error: 'Error al obtener contacto' });
  }
});

// Crear nuevo contacto
router.post('/', async (req, res) => {
  try {
    const { firstName, lastName, email, phone, status, source, notes } = req.body;

    if (!firstName) {
      return res.status(400).json({ error: 'El nombre es requerido' });
    }

    // Calcular lead score inicial basado en datos disponibles
    let leadScore = 0;
    if (email) leadScore += 10;
    if (phone) leadScore += 10;
    if (lastName) leadScore += 5;
    if (source) leadScore += 5;
    if (notes) leadScore += 5;

    // Determinar status si no se proporciona
    let finalStatus = status;
    if (!finalStatus) {
      if (leadScore >= 30) finalStatus = 'tibio';
      else if (leadScore >= 20) finalStatus = 'frio';
      else finalStatus = 'frio';
    }

    const contact = await Contact.create({
      user_id: req.user.userId,
      first_name: firstName,
      last_name: lastName || null,
      email: email || null,
      phone: phone || null,
      status: finalStatus,
      source: source || null,
      notes: notes || null,
      lead_score: Math.min(100, Math.max(0, leadScore)),
    });

    res.status(201).json(contact);
  } catch (error) {
    console.error('Error creando contacto:', error);
    res.status(500).json({ error: 'Error al crear contacto' });
  }
});

// Actualizar contacto
router.put('/:id', async (req, res) => {
  try {
    const { firstName, lastName, email, phone, status, source, notes, leadScore } = req.body;

    const contact = await Contact.findOneAndUpdate(
      { _id: req.params.id, user_id: req.user.userId },
      {
        $set: {
          ...(firstName && { first_name: firstName }),
          ...(lastName !== undefined && { last_name: lastName }),
          ...(email !== undefined && { email }),
          ...(phone !== undefined && { phone }),
          ...(status && { status }),
          ...(source !== undefined && { source }),
          ...(notes !== undefined && { notes }),
          ...(leadScore !== undefined && { lead_score: leadScore }),
        },
      },
      { new: true, runValidators: true }
    );

    if (!contact) {
      return res.status(404).json({ error: 'Contacto no encontrado' });
    }

    res.json(contact);
  } catch (error) {
    console.error('Error actualizando contacto:', error);
    res.status(500).json({ error: 'Error al actualizar contacto' });
  }
});

// Eliminar contacto
router.delete('/:id', async (req, res) => {
  try {
    const contact = await Contact.findOneAndDelete({
      _id: req.params.id,
      user_id: req.user.userId,
    });

    if (!contact) {
      return res.status(404).json({ error: 'Contacto no encontrado' });
    }

    res.json({ message: 'Contacto eliminado exitosamente' });
  } catch (error) {
    console.error('Error eliminando contacto:', error);
    res.status(500).json({ error: 'Error al eliminar contacto' });
  }
});

// Registrar actividad de lead
router.post('/:id/activities', async (req, res) => {
  try {
    const { activityType, activityData, scoreChange } = req.body;

    const activity = await LeadActivity.create({
      contact_id: req.params.id,
      activity_type: activityType,
      activity_data: activityData || {},
      score_change: scoreChange || 0,
    });

    // Actualizar lead score del contacto
    const contact = await Contact.findById(req.params.id);
    if (contact) {
      contact.lead_score = Math.min(100, Math.max(0, contact.lead_score + (scoreChange || 0)));
      
      // Actualizar status basado en lead score
      if (contact.lead_score >= 70) contact.status = 'caliente';
      else if (contact.lead_score >= 40) contact.status = 'tibio';
      else contact.status = 'frio';
      
      await contact.save();
    }

    res.status(201).json(activity);
  } catch (error) {
    console.error('Error registrando actividad:', error);
    res.status(500).json({ error: 'Error al registrar actividad' });
  }
});

export default router;
