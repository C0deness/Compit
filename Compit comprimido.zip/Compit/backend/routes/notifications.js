import express from 'express';
import { authenticateToken } from '../middleware/auth.js';
import Notification from '../models/Notification.js';

const router = express.Router();

// Todas las rutas requieren autenticación
router.use(authenticateToken);

// Obtener todas las notificaciones del usuario
router.get('/', async (req, res) => {
  try {
    const { read, type, limit = 50 } = req.query;
    const query = { user_id: req.user.userId };

    if (read !== undefined) {
      query.read = read === 'true';
    }

    if (type) {
      query.type = type;
    }

    const notifications = await Notification.find(query)
      .sort({ createdAt: -1 })
      .limit(parseInt(limit));

    res.json(notifications);
  } catch (error) {
    console.error('Error obteniendo notificaciones:', error);
    res.status(500).json({ error: 'Error al obtener notificaciones' });
  }
});

// Obtener contador de notificaciones no leídas
router.get('/unread-count', async (req, res) => {
  try {
    const count = await Notification.countDocuments({
      user_id: req.user.userId,
      read: false,
    });

    res.json({ count });
  } catch (error) {
    console.error('Error obteniendo contador:', error);
    res.status(500).json({ error: 'Error al obtener contador' });
  }
});

// Marcar notificación como leída
router.put('/:id/read', async (req, res) => {
  try {
    const notification = await Notification.findOneAndUpdate(
      {
        _id: req.params.id,
        user_id: req.user.userId,
      },
      { read: true },
      { new: true }
    );

    if (!notification) {
      return res.status(404).json({ error: 'Notificación no encontrada' });
    }

    res.json(notification);
  } catch (error) {
    console.error('Error marcando notificación:', error);
    res.status(500).json({ error: 'Error al marcar notificación' });
  }
});

// Marcar todas las notificaciones como leídas
router.put('/read-all', async (req, res) => {
  try {
    const result = await Notification.updateMany(
      {
        user_id: req.user.userId,
        read: false,
      },
      { read: true }
    );

    res.json({ updated: result.modifiedCount });
  } catch (error) {
    console.error('Error marcando notificaciones:', error);
    res.status(500).json({ error: 'Error al marcar notificaciones' });
  }
});

// Eliminar notificación
router.delete('/:id', async (req, res) => {
  try {
    const notification = await Notification.findOneAndDelete({
      _id: req.params.id,
      user_id: req.user.userId,
    });

    if (!notification) {
      return res.status(404).json({ error: 'Notificación no encontrada' });
    }

    res.json({ message: 'Notificación eliminada exitosamente' });
  } catch (error) {
    console.error('Error eliminando notificación:', error);
    res.status(500).json({ error: 'Error al eliminar notificación' });
  }
});

export default router;



