import express from 'express';
import { authenticateToken } from '../middleware/auth.js';
import Alert from '../models/Alert.js';

const router = express.Router();
router.use(authenticateToken);

// Obtener todas las alertas del usuario
router.get('/', async (req, res) => {
  try {
    const { type, severity, is_read, limit = 50, page = 1 } = req.query;
    const query = { user_id: req.user.userId };

    if (type) query.type = type;
    if (severity) query.severity = severity;
    if (is_read !== undefined) query.is_read = is_read === 'true';

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const alerts = await Alert.find(query)
      .sort({ created_at: -1 })
      .limit(parseInt(limit))
      .skip(skip)
      .populate('related_news_id')
      .populate('related_kpi_id')
      .populate('competitor_id');

    const total = await Alert.countDocuments(query);
    const unreadCount = await Alert.countDocuments({ ...query, is_read: false });

    res.json({
      alerts,
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(total / parseInt(limit)),
      },
      unread_count: unreadCount,
    });
  } catch (error) {
    console.error('Error obteniendo alertas:', error);
    res.status(500).json({ error: 'Error al obtener alertas' });
  }
});

// Obtener una alerta específica
router.get('/:id', async (req, res) => {
  try {
    const alert = await Alert.findOne({
      _id: req.params.id,
      user_id: req.user.userId,
    })
      .populate('related_news_id')
      .populate('related_kpi_id')
      .populate('competitor_id');

    if (!alert) {
      return res.status(404).json({ error: 'Alerta no encontrada' });
    }

    res.json(alert);
  } catch (error) {
    console.error('Error obteniendo alerta:', error);
    res.status(500).json({ error: 'Error al obtener alerta' });
  }
});

// Crear una nueva alerta
router.post('/', async (req, res) => {
  try {
    const {
      type,
      severity,
      title,
      message,
      related_news_id,
      related_kpi_id,
      brand,
      model,
      competitor_id,
      metadata,
    } = req.body;

    const alert = await Alert.create({
      user_id: req.user.userId,
      type,
      severity: severity || 'medium',
      title,
      message,
      related_news_id,
      related_kpi_id,
      brand,
      model,
      competitor_id,
      metadata,
    });

    res.status(201).json(alert);
  } catch (error) {
    console.error('Error creando alerta:', error);
    res.status(500).json({ error: 'Error al crear alerta' });
  }
});

// Marcar alerta como leída
router.patch('/:id/read', async (req, res) => {
  try {
    const alert = await Alert.findOneAndUpdate(
      { _id: req.params.id, user_id: req.user.userId },
      { is_read: true },
      { new: true }
    );

    if (!alert) {
      return res.status(404).json({ error: 'Alerta no encontrada' });
    }

    res.json(alert);
  } catch (error) {
    console.error('Error marcando alerta como leída:', error);
    res.status(500).json({ error: 'Error al actualizar alerta' });
  }
});

// Marcar acción tomada
router.patch('/:id/action', async (req, res) => {
  try {
    const { results } = req.body;

    const alert = await Alert.findOneAndUpdate(
      { _id: req.params.id, user_id: req.user.userId },
      {
        action_taken: true,
        action_taken_at: new Date(),
        results,
      },
      { new: true }
    );

    if (!alert) {
      return res.status(404).json({ error: 'Alerta no encontrada' });
    }

    res.json(alert);
  } catch (error) {
    console.error('Error marcando acción tomada:', error);
    res.status(500).json({ error: 'Error al actualizar alerta' });
  }
});

// Eliminar alerta
router.delete('/:id', async (req, res) => {
  try {
    const alert = await Alert.findOneAndDelete({
      _id: req.params.id,
      user_id: req.user.userId,
    });

    if (!alert) {
      return res.status(404).json({ error: 'Alerta no encontrada' });
    }

    res.json({ message: 'Alerta eliminada correctamente' });
  } catch (error) {
    console.error('Error eliminando alerta:', error);
    res.status(500).json({ error: 'Error al eliminar alerta' });
  }
});

export default router;
