import express from 'express';
import FarmingZone from '../models/FarmingZone.js';
import { authenticateToken } from '../middleware/auth.js';
import OpenAI from 'openai';

const router = express.Router();
router.use(authenticateToken);

const openai = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

// Obtener zonas de farming
router.get('/zones', async (req, res) => {
  try {
    const zones = await FarmingZone.find({ user_id: req.user.userId }).sort({ createdAt: -1 });
    res.json(zones);
  } catch (error) {
    console.error('Error obteniendo zonas:', error);
    res.status(500).json({ error: 'Error al obtener zonas' });
  }
});

// Analizar zona (simulación de análisis predictivo)
router.post('/analyze', async (req, res) => {
  try {
    const { latitude, longitude, radius = 5 } = req.body;

    if (!latitude || !longitude) {
      return res.status(400).json({ error: 'Latitud y longitud son requeridas' });
    }

    // Simular análisis predictivo
    const analysisData = {
      potentialScore: Math.random() * 30 + 70,
      demographics: {
        averageAge: 35 + Math.floor(Math.random() * 15),
        medianIncome: 50000 + Math.floor(Math.random() * 50000),
        populationGrowth: (Math.random() * 10 - 2).toFixed(2),
      },
      marketIndicators: {
        averageDaysOnMarket: Math.floor(Math.random() * 30 + 20),
        priceTrend: Math.random() > 0.5 ? 'up' : 'stable',
        inventoryLevel: Math.random() > 0.5 ? 'low' : 'medium',
      },
      socialSentiment: {
        score: Math.random() * 20 + 70,
        mentions: Math.floor(Math.random() * 100 + 50),
      },
      businessActivity: {
        newLicenses: Math.floor(Math.random() * 20 + 5),
        businessGrowth: (Math.random() * 15 + 5).toFixed(2),
      },
      hotZones: [
        {
          coordinates: [latitude + (Math.random() - 0.5) * 0.01, longitude + (Math.random() - 0.5) * 0.01],
          score: Math.random() * 20 + 80,
        },
        {
          coordinates: [latitude + (Math.random() - 0.5) * 0.01, longitude + (Math.random() - 0.5) * 0.01],
          score: Math.random() * 20 + 75,
        },
      ],
    };

    res.json(analysisData);
  } catch (error) {
    console.error('Error analizando zona:', error);
    res.status(500).json({ error: 'Error al analizar zona' });
  }
});

// Generar kit de farming digital
router.post('/generate-kit', async (req, res) => {
  try {
    const { zoneName, analysisData } = req.body;

    if (!openai) {
      return res.json({
        facebookAds: [
          'Descubre las mejores oportunidades inmobiliarias en ' + zoneName,
          'Zona en crecimiento: ' + zoneName + ' - Tu próximo hogar te espera',
          'Inversión inteligente en ' + zoneName + ' - Propiedades premium disponibles',
        ],
        emailMarketing: [
          'Hola, soy especialista en la zona de ' + zoneName + '. ¿Te interesa conocer las mejores oportunidades?',
          'Zona en auge: ' + zoneName + '. Propiedades exclusivas con excelente potencial de revalorización.',
        ],
        coldCallScript: `Hola, mi nombre es [Tu Nombre] y soy agente inmobiliario especializado en ${zoneName}. 
        He notado que esta zona está experimentando un crecimiento significativo con [mencionar datos clave]. 
        ¿Te gustaría conocer las oportunidades disponibles en esta área?`,
      });
    }

    const prompt = `Eres un experto en marketing inmobiliario. Genera contenido de marketing para la zona "${zoneName}" basándote en estos datos:
    
    ${JSON.stringify(analysisData, null, 2)}
    
    Genera:
    1. 3 variantes de copy para anuncios de Facebook/Instagram (máximo 150 caracteres cada una)
    2. 2 variantes de texto para email marketing (máximo 200 palabras cada una)
    3. 1 borrador de guion para una llamada en frío (máximo 300 palabras)
    
    Responde en formato JSON con las claves: facebookAds (array), emailMarketing (array), coldCallScript (string).`;

    const completion = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [{ role: 'user', content: prompt }],
      response_format: { type: 'json_object' },
    });

    const content = JSON.parse(completion.choices[0].message.content);

    res.json({
      facebookAds: content.facebookAds || [],
      emailMarketing: content.emailMarketing || [],
      coldCallScript: content.coldCallScript || '',
    });
  } catch (error) {
    console.error('Error generando kit:', error);
    res.status(500).json({ error: 'Error al generar kit de farming' });
  }
});

// Guardar zona de farming
router.post('/zones', async (req, res) => {
  try {
    const { name, coordinates, potentialScore, analysisData } = req.body;

    if (!name || !coordinates) {
      return res.status(400).json({ error: 'Nombre y coordenadas son requeridos' });
    }

    const zone = await FarmingZone.create({
      user_id: req.user.userId,
      name,
      coordinates,
      potential_score: potentialScore || null,
      analysis_data: analysisData || null,
    });

    res.status(201).json(zone);
  } catch (error) {
    console.error('Error guardando zona:', error);
    res.status(500).json({ error: 'Error al guardar zona' });
  }
});

export default router;
