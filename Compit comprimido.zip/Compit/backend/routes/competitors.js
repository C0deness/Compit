import express from 'express';
import { authenticateToken } from '../middleware/auth.js';
import Competitor from '../models/Competitor.js';

const router = express.Router();
router.use(authenticateToken);

// Obtener todos los competidores del usuario
router.get('/', async (req, res) => {
  try {
    const { is_active, type } = req.query;
    const query = { user_id: req.user.userId };

    if (is_active !== undefined) query.is_active = is_active === 'true';
    if (type) query.type = type;

    const competitors = await Competitor.find(query).sort({ name: 1 });

    res.json({ competitors });
  } catch (error) {
    console.error('Error obteniendo competidores:', error);
    res.status(500).json({ error: 'Error al obtener competidores' });
  }
});

// Obtener un competidor específico
router.get('/:id', async (req, res) => {
  try {
    const competitor = await Competitor.findOne({
      _id: req.params.id,
      user_id: req.user.userId,
    });

    if (!competitor) {
      return res.status(404).json({ error: 'Competidor no encontrado' });
    }

    res.json(competitor);
  } catch (error) {
    console.error('Error obteniendo competidor:', error);
    res.status(500).json({ error: 'Error al obtener competidor' });
  }
});

// Crear un nuevo competidor
router.post('/', async (req, res) => {
  try {
    const {
      name,
      website,
      type,
      region,
      brands_monitored,
      metadata,
    } = req.body;

    const competitor = await Competitor.create({
      user_id: req.user.userId,
      name,
      website,
      type: type || 'concesionario',
      region,
      brands_monitored: brands_monitored || [],
      metadata: metadata || {},
    });

    res.status(201).json(competitor);
  } catch (error) {
    console.error('Error creando competidor:', error);
    res.status(500).json({ error: 'Error al crear competidor' });
  }
});

// Actualizar competidor
router.put('/:id', async (req, res) => {
  try {
    const {
      name,
      website,
      type,
      region,
      brands_monitored,
      is_active,
      metadata,
    } = req.body;

    const competitor = await Competitor.findOneAndUpdate(
      { _id: req.params.id, user_id: req.user.userId },
      {
        name,
        website,
        type,
        region,
        brands_monitored,
        is_active,
        metadata,
      },
      { new: true }
    );

    if (!competitor) {
      return res.status(404).json({ error: 'Competidor no encontrado' });
    }

    res.json(competitor);
  } catch (error) {
    console.error('Error actualizando competidor:', error);
    res.status(500).json({ error: 'Error al actualizar competidor' });
  }
});

// Eliminar competidor
router.delete('/:id', async (req, res) => {
  try {
    const competitor = await Competitor.findOneAndDelete({
      _id: req.params.id,
      user_id: req.user.userId,
    });

    if (!competitor) {
      return res.status(404).json({ error: 'Competidor no encontrado' });
    }

    res.json({ message: 'Competidor eliminado correctamente' });
  } catch (error) {
    console.error('Error eliminando competidor:', error);
    res.status(500).json({ error: 'Error al eliminar competidor' });
  }
});

export default router;
