import express from 'express';
import { authenticateToken } from '../middleware/auth.js';
import Financing from '../models/Financing.js';

const router = express.Router();

// Todas las rutas requieren autenticación
router.use(authenticateToken);

// Obtener todas las solicitudes de financiación
router.get('/', async (req, res) => {
  try {
    const { status, loan_type } = req.query;
    const query = { user_id: req.user.userId };

    if (status) {
      query.status = status;
    }

    if (loan_type) {
      query.loan_type = loan_type;
    }

    const financings = await Financing.find(query)
      .populate('contact_id', 'first_name last_name email phone')
      .populate('deal_id', 'offer_price status')
      .populate('property_id', 'title address price')
      .sort({ createdAt: -1 });

    res.json(financings);
  } catch (error) {
    console.error('Error obteniendo financiaciones:', error);
    res.status(500).json({ error: 'Error al obtener financiaciones' });
  }
});

// Obtener una solicitud de financiación por ID
router.get('/:id', async (req, res) => {
  try {
    const financing = await Financing.findOne({
      _id: req.params.id,
      user_id: req.user.userId,
    })
      .populate('contact_id', 'first_name last_name email phone')
      .populate('deal_id', 'offer_price status')
      .populate('property_id', 'title address price');

    if (!financing) {
      return res.status(404).json({ error: 'Financiación no encontrada' });
    }

    res.json(financing);
  } catch (error) {
    console.error('Error obteniendo financiación:', error);
    res.status(500).json({ error: 'Error al obtener financiación' });
  }
});

// Crear nueva solicitud de financiación
router.post('/', async (req, res) => {
  try {
    const {
      contact_id,
      deal_id,
      property_id,
      loan_type,
      loan_amount,
      interest_rate,
      loan_term,
      down_payment,
      down_payment_percentage,
      monthly_payment,
      lender_name,
      lender_contact,
      notes,
      credit_score,
      debt_to_income_ratio,
    } = req.body;

    // Calcular pago mensual si no se proporciona
    let calculatedMonthlyPayment = monthly_payment;
    if (!calculatedMonthlyPayment && loan_amount && interest_rate && loan_term) {
      const monthlyRate = interest_rate / 100 / 12;
      const numPayments = loan_term * 12;
      calculatedMonthlyPayment = 
        (loan_amount * monthlyRate * Math.pow(1 + monthlyRate, numPayments)) /
        (Math.pow(1 + monthlyRate, numPayments) - 1);
    }

    const financing = await Financing.create({
      user_id: req.user.userId,
      contact_id,
      deal_id: deal_id || null,
      property_id: property_id || null,
      loan_type,
      loan_amount,
      interest_rate: interest_rate || null,
      loan_term,
      down_payment: down_payment || 0,
      down_payment_percentage: down_payment_percentage || 0,
      monthly_payment: calculatedMonthlyPayment || null,
      lender_name: lender_name || null,
      lender_contact: lender_contact || null,
      notes: notes || null,
      credit_score: credit_score || null,
      debt_to_income_ratio: debt_to_income_ratio || null,
      status: 'draft',
    });

    const populatedFinancing = await Financing.findById(financing._id)
      .populate('contact_id', 'first_name last_name email phone')
      .populate('deal_id', 'offer_price status')
      .populate('property_id', 'title address price');

    res.status(201).json(populatedFinancing);
  } catch (error) {
    console.error('Error creando financiación:', error);
    res.status(500).json({ error: 'Error al crear financiación' });
  }
});

// Actualizar solicitud de financiación
router.put('/:id', async (req, res) => {
  try {
    const {
      loan_type,
      loan_amount,
      interest_rate,
      loan_term,
      down_payment,
      down_payment_percentage,
      monthly_payment,
      status,
      lender_name,
      lender_contact,
      notes,
      credit_score,
      debt_to_income_ratio,
      approval_date,
      closing_date,
    } = req.body;

    // Recalcular pago mensual si cambian los parámetros
    let calculatedMonthlyPayment = monthly_payment;
    if (!calculatedMonthlyPayment && loan_amount && interest_rate && loan_term) {
      const monthlyRate = interest_rate / 100 / 12;
      const numPayments = loan_term * 12;
      calculatedMonthlyPayment = 
        (loan_amount * monthlyRate * Math.pow(1 + monthlyRate, numPayments)) /
        (Math.pow(1 + monthlyRate, numPayments) - 1);
    }

    const updateData = {
      loan_type,
      loan_amount,
      interest_rate,
      loan_term,
      down_payment,
      down_payment_percentage,
      monthly_payment: calculatedMonthlyPayment || monthly_payment,
      status,
      lender_name,
      lender_contact,
      notes,
      credit_score,
      debt_to_income_ratio,
    };

    if (approval_date) updateData.approval_date = approval_date;
    if (closing_date) updateData.closing_date = closing_date;

    const financing = await Financing.findOneAndUpdate(
      {
        _id: req.params.id,
        user_id: req.user.userId,
      },
      updateData,
      { new: true, runValidators: true }
    )
      .populate('contact_id', 'first_name last_name email phone')
      .populate('deal_id', 'offer_price status')
      .populate('property_id', 'title address price');

    if (!financing) {
      return res.status(404).json({ error: 'Financiación no encontrada' });
    }

    res.json(financing);
  } catch (error) {
    console.error('Error actualizando financiación:', error);
    res.status(500).json({ error: 'Error al actualizar financiación' });
  }
});

// Eliminar solicitud de financiación
router.delete('/:id', async (req, res) => {
  try {
    const financing = await Financing.findOneAndDelete({
      _id: req.params.id,
      user_id: req.user.userId,
    });

    if (!financing) {
      return res.status(404).json({ error: 'Financiación no encontrada' });
    }

    res.json({ message: 'Financiación eliminada exitosamente' });
  } catch (error) {
    console.error('Error eliminando financiación:', error);
    res.status(500).json({ error: 'Error al eliminar financiación' });
  }
});

// Calcular pago mensual
router.post('/calculate', async (req, res) => {
  try {
    const { loan_amount, interest_rate, loan_term, down_payment } = req.body;

    if (!loan_amount || !interest_rate || !loan_term) {
      return res.status(400).json({ error: 'Faltan parámetros requeridos' });
    }

    const principal = loan_amount - (down_payment || 0);
    const monthlyRate = interest_rate / 100 / 12;
    const numPayments = loan_term * 12;

    const monthlyPayment = 
      (principal * monthlyRate * Math.pow(1 + monthlyRate, numPayments)) /
      (Math.pow(1 + monthlyRate, numPayments) - 1);

    const totalPayment = monthlyPayment * numPayments;
    const totalInterest = totalPayment - principal;

    res.json({
      monthly_payment: Math.round(monthlyPayment * 100) / 100,
      total_payment: Math.round(totalPayment * 100) / 100,
      total_interest: Math.round(totalInterest * 100) / 100,
      principal: principal,
    });
  } catch (error) {
    console.error('Error calculando pago:', error);
    res.status(500).json({ error: 'Error al calcular pago mensual' });
  }
});

export default router;


