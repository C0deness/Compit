# Script PowerShell para iniciar el sistema completo
# CRM Inmobiliario - Iniciando Sistema

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  CRM Inmobiliario - Iniciando Sistema" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Verificar que Node.js esté instalado
try {
    $nodeVersion = node --version
    Write-Host "[INFO] Node.js encontrado: $nodeVersion" -ForegroundColor Green
} catch {
    Write-Host "[ERROR] Node.js no está instalado o no está en el PATH" -ForegroundColor Red
    Write-Host "Por favor instala Node.js desde https://nodejs.org/" -ForegroundColor Yellow
    Read-Host "Presiona Enter para salir"
    exit 1
}

Write-Host ""

# Verificar e instalar dependencias del backend
if (-not (Test-Path "backend\node_modules")) {
    Write-Host "[INFO] Instalando dependencias del backend..." -ForegroundColor Yellow
    Set-Location backend
    npm install
    Set-Location ..
    Write-Host ""
}

# Verificar e instalar dependencias del frontend
if (-not (Test-Path "node_modules")) {
    Write-Host "[INFO] Instalando dependencias del frontend..." -ForegroundColor Yellow
    npm install
    Write-Host ""
}

# Verificar archivo .env
if (-not (Test-Path "backend\.env")) {
    Write-Host "[ADVERTENCIA] El archivo backend\.env no existe" -ForegroundColor Yellow
    Write-Host "Por favor crea el archivo .env basado en .env.example" -ForegroundColor Yellow
    Write-Host ""
}

# Iniciar el backend en una nueva ventana
Write-Host "[INFO] Iniciando servidor backend..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PWD\backend'; Write-Host 'Iniciando backend en http://localhost:5000' -ForegroundColor Cyan; npm run dev"

# Esperar un poco
Start-Sleep -Seconds 3

# Iniciar el frontend en una nueva ventana
Write-Host "[INFO] Iniciando servidor frontend..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PWD'; Write-Host 'Iniciando frontend en http://localhost:5173' -ForegroundColor Cyan; npm run dev"

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Sistema iniciado correctamente" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Backend:  http://localhost:5000" -ForegroundColor Yellow
Write-Host "Frontend: http://localhost:5173" -ForegroundColor Yellow
Write-Host ""
Write-Host "Las ventanas del backend y frontend están abiertas" -ForegroundColor Green
Write-Host "Presiona cualquier tecla para cerrar esta ventana..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")


