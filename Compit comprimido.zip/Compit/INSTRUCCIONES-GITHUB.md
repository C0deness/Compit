# 📦 Instrucciones para Subir el Proyecto a GitHub

## Opción 1: Usando GitHub CLI (Recomendado)

### 1. Instalar GitHub CLI
- Descarga desde: https://cli.github.com/
- O usando winget: `winget install --id GitHub.cli`

### 2. Autenticarse
```powershell
gh auth login
```

### 3. Crear y subir el repositorio
```powershell
gh repo create rockit-crm --public --description "Sistema CRM Inmobiliario potenciado por Inteligencia Artificial. Gestión de contactos, propiedades, deals, farming predictivo y automatización con IA." --source=. --remote=origin --push
```

## Opción 2: Crear Repositorio Manualmente

### 1. Crear el repositorio en GitHub
1. Ve a https://github.com/new
2. Nombre del repositorio: `rockit-crm`
3. Descripción: `Sistema CRM Inmobiliario potenciado por Inteligencia Artificial. Gestión de contactos, propiedades, deals, farming predictivo y automatización con IA.`
4. Visibilidad: Público o Privado
5. **NO** marques "Add a README file" (ya tenemos uno)
6. Haz clic en "Create repository"

### 2. Conectar y subir el código
Ejecuta estos comandos en PowerShell desde la carpeta del proyecto:

```powershell
# Cambiar a la rama main (si es necesario)
git branch -M main

# Agregar el repositorio remoto (reemplaza TU_USUARIO con tu usuario de GitHub)
git remote add origin https://github.com/TU_USUARIO/rockit-crm.git

# Subir el código
git push -u origin main
```

## Opción 3: Usando la API de GitHub

Si tienes un token de acceso personal de GitHub:

```powershell
# Configurar variables
$token = "TU_TOKEN_DE_GITHUB"
$repoName = "rockit-crm"
$description = "Sistema CRM Inmobiliario potenciado por Inteligencia Artificial. Gestión de contactos, propiedades, deals, farming predictivo y automatización con IA."

# Crear repositorio
$headers = @{
    "Authorization" = "token $token"
    "Accept" = "application/vnd.github.v3+json"
}
$body = @{
    name = $repoName
    description = $description
    private = $false
} | ConvertTo-Json

Invoke-RestMethod -Uri "https://api.github.com/user/repos" -Method Post -Headers $headers -Body $body

# Conectar y subir
git branch -M main
git remote add origin "https://github.com/TU_USUARIO/$repoName.git"
git push -u origin main
```

## Verificar

Después de subir, verifica que todo esté correcto:
- Visita: `https://github.com/TU_USUARIO/rockit-crm`
- Verifica que todos los archivos estén presentes
- Revisa que el README.md se muestre correctamente

## Notas Importantes

- ✅ Los archivos `.env` están en `.gitignore` y NO se subirán (seguro)
- ✅ Los `node_modules` están excluidos (se instalan con `npm install`)
- ✅ El proyecto está listo para ser clonado y usado por otros desarrolladores

