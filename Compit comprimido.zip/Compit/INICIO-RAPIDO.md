# 🚀 Inicio Rápido - RockIt

## Inicio Automático del Sistema

### Windows

#### Opción 1: Script Batch (CMD)
Haz doble clic en `start-system.bat` o ejecuta desde la terminal:

```cmd
start-system.bat
```

#### Opción 2: Script PowerShell
Ejecuta desde PowerShell:

```powershell
.\start-system.ps1
```

### ¿Qué hace el script?

1. ✅ Verifica que Node.js esté instalado
2. ✅ Instala dependencias automáticamente si faltan
3. ✅ Inicia el backend en una ventana separada (puerto 5000)
4. ✅ Inicia el frontend en otra ventana (puerto 5173)

### Detener el Sistema

Ejecuta:
```cmd
stop-system.bat
```

O cierra manualmente las ventanas del backend y frontend.

## Requisitos Previos

Antes de ejecutar el script, asegúrate de tener:

1. **Node.js** instalado (versión 18 o superior)
   - Descarga desde: https://nodejs.org/

2. **PostgreSQL** instalado y ejecutándose
   - Crea la base de datos: `crm_inmobiliario`

3. **Archivo `.env`** en la carpeta `backend/`
   - Copia `backend/.env.example` a `backend/.env`
   - Configura tus credenciales de base de datos

## Primera Ejecución

Si es la primera vez que ejecutas el sistema:

1. El script instalará automáticamente las dependencias
2. Ejecuta las migraciones de la base de datos:
   ```cmd
   cd backend
   npm run migrate
   ```
3. Crea el usuario administrador:
   ```cmd
   npm run seed
   cd ..
   ```
4. Ejecuta `start-system.bat`

**Credenciales admin por defecto:**
- Email: `admin@crm.com`
- Password: `admin123`

Ver `CREDENCIALES-ADMIN.md` para más detalles.

## Acceso al Sistema

Una vez iniciado:

- **Frontend**: http://localhost:5173
- **Backend API**: http://localhost:5000/api
- **Health Check**: http://localhost:5000/api/health

## Solución de Problemas

### Error: "Node.js no está instalado"
- Instala Node.js desde https://nodejs.org/
- Reinicia la terminal después de la instalación

### Error: "Puerto 5000 en uso"
- El backend ya está corriendo o hay otro proceso usando el puerto
- Ejecuta `stop-system.bat` y vuelve a intentar

### Error: "Puerto 5173 en uso"
- El frontend ya está corriendo
- Ejecuta `stop-system.bat` y vuelve a intentar

### Error de conexión a la base de datos
- Verifica que PostgreSQL esté ejecutándose
- Revisa las credenciales en `backend/.env`
- Asegúrate de que la base de datos `crm_inmobiliario` exista

## Inicio Manual (Alternativa)

Si prefieres iniciar manualmente:

**Terminal 1 - Backend:**
```cmd
cd backend
npm run dev
```

**Terminal 2 - Frontend:**
```cmd
npm run dev
```

---

**¡Listo!** El sistema debería estar funcionando. Abre http://localhost:5173 en tu navegador.

