# Script para crear repositorio en GitHub y subir el código
# Autor: Rockit CRM
# Descripción: Automatiza la creación del repositorio en GitHub

param(
    [string]$RepoName = "rockit-crm",
    [string]$Description = "Sistema CRM Inmobiliario potenciado por Inteligencia Artificial. Gestión de contactos, propiedades, deals, farming predictivo y automatización con IA.",
    [string]$Visibility = "public",
    [string]$GitHubToken = "",
    [string]$GitHubUser = ""
)

Write-Host ""
Write-Host "🚀 RockIt CRM - Crear Repositorio en GitHub" -ForegroundColor Cyan
Write-Host "=" * 60 -ForegroundColor Cyan
Write-Host ""

# Verificar si GitHub CLI está instalado
$ghInstalled = Get-Command gh -ErrorAction SilentlyContinue

if ($ghInstalled) {
    Write-Host "✅ GitHub CLI encontrado. Creando repositorio..." -ForegroundColor Green
    Write-Host ""
    
    # Verificar autenticación
    $authStatus = gh auth status 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Host "⚠️  No estás autenticado en GitHub CLI." -ForegroundColor Yellow
        Write-Host "   Ejecuta: gh auth login" -ForegroundColor White
        exit 1
    }
    
    # Crear repositorio con GitHub CLI
    Write-Host "📦 Creando repositorio: $RepoName" -ForegroundColor Yellow
    gh repo create $RepoName `
        --description $Description `
        --$Visibility `
        --source=. `
        --remote=origin `
        --push
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host ""
        Write-Host "✅ ¡Repositorio creado y código subido exitosamente!" -ForegroundColor Green
        $username = gh api user --jq .login
        Write-Host "📍 URL: https://github.com/$username/$RepoName" -ForegroundColor Cyan
        Write-Host ""
    } else {
        Write-Host "❌ Error al crear el repositorio" -ForegroundColor Red
        exit 1
    }
} elseif ($GitHubToken -ne "") {
    Write-Host "🔑 Usando token de GitHub para crear repositorio..." -ForegroundColor Green
    Write-Host ""
    
    if ($GitHubUser -eq "") {
        Write-Host "⚠️  Se requiere el nombre de usuario de GitHub" -ForegroundColor Yellow
        Write-Host "   Usa: -GitHubUser 'tu_usuario'" -ForegroundColor White
        exit 1
    }
    
    # Crear repositorio usando API
    $headers = @{
        "Authorization" = "token $GitHubToken"
        "Accept" = "application/vnd.github.v3+json"
    }
    $body = @{
        name = $RepoName
        description = $Description
        private = ($Visibility -eq "private")
    } | ConvertTo-Json
    
    try {
        $response = Invoke-RestMethod -Uri "https://api.github.com/user/repos" -Method Post -Headers $headers -Body $body
        Write-Host "✅ Repositorio creado exitosamente!" -ForegroundColor Green
        
        # Conectar y subir
        Write-Host "📤 Subiendo código..." -ForegroundColor Yellow
        git branch -M main
        git remote add origin "https://github.com/$GitHubUser/$RepoName.git"
        git push -u origin main
        
        Write-Host ""
        Write-Host "✅ ¡Código subido exitosamente!" -ForegroundColor Green
        Write-Host "📍 URL: https://github.com/$GitHubUser/$RepoName" -ForegroundColor Cyan
        Write-Host ""
    } catch {
        Write-Host "❌ Error: $_" -ForegroundColor Red
        exit 1
    }
} else {
    Write-Host "⚠️  GitHub CLI no está instalado y no se proporcionó token." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "📋 OPCIONES DISPONIBLES:" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "1️⃣  INSTALAR GITHUB CLI (Recomendado):" -ForegroundColor Green
    Write-Host "   Descarga desde: https://cli.github.com/" -ForegroundColor White
    Write-Host "   O ejecuta: winget install --id GitHub.cli" -ForegroundColor White
    Write-Host "   Luego: gh auth login" -ForegroundColor White
    Write-Host "   Y vuelve a ejecutar este script" -ForegroundColor White
    Write-Host ""
    Write-Host "2️⃣  CREAR MANUALMENTE:" -ForegroundColor Green
    Write-Host "   a) Ve a: https://github.com/new" -ForegroundColor White
    Write-Host "   b) Nombre: $RepoName" -ForegroundColor White
    Write-Host "   c) Descripción: $Description" -ForegroundColor White
    Write-Host "   d) NO marques 'Add README' (ya tenemos uno)" -ForegroundColor White
    Write-Host "   e) Crea el repositorio" -ForegroundColor White
    Write-Host "   f) Ejecuta estos comandos:" -ForegroundColor White
    Write-Host ""
    Write-Host "      git branch -M main" -ForegroundColor Yellow
    Write-Host "      git remote add origin https://github.com/TU_USUARIO/$RepoName.git" -ForegroundColor Yellow
    Write-Host "      git push -u origin main" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "3️⃣  USAR TOKEN DE GITHUB:" -ForegroundColor Green
    Write-Host "   Ejecuta este script con:" -ForegroundColor White
    Write-Host "   .\create-github-repo.ps1 -GitHubToken 'tu_token' -GitHubUser 'tu_usuario'" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "   Para crear un token: https://github.com/settings/tokens" -ForegroundColor White
    Write-Host "   (Necesitas el permiso 'repo')" -ForegroundColor White
    Write-Host ""
    Write-Host "📄 Ver INSTRUCCIONES-GITHUB.md para más detalles" -ForegroundColor Cyan
    Write-Host ""
}

