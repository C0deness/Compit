# 🏠 RockIt CRM - Sistema CRM Inmobiliario Potenciado por IA

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![React](https://img.shields.io/badge/React-19-blue.svg)](https://reactjs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.7-blue.svg)](https://www.typescriptlang.org/)
[![Node.js](https://img.shields.io/badge/Node.js-20-green.svg)](https://nodejs.org/)

**RockIt CRM** es un sistema completo de CRM (Customer Relationship Management) diseñado específicamente para el sector inmobiliario, potenciado por inteligencia artificial y automatización. Transforma la gestión de contactos, propiedades y transacciones con herramientas de IA avanzadas.

## 🚀 Características Principales

### Módulos Core
- **Gestión de Contactos (Leads/Clientes)**: Sistema completo de CRUD con lead scoring automático
- **Gestión de Propiedades**: Administración de listings con detalles completos
- **Deal Room Inteligente**: Gestión de transacciones con validación automática de documentos
- **Farming Predictivo Hiperlocal**: Identificación de zonas de alto potencial usando IA
- **Automatización del Ciclo de Vida**: Workflows y lead scoring automático
- **Asistente Rockit**: Chatbot especializado en asesoramiento hipotecario

### Funcionalidades de IA
- 🤖 Análisis predictivo de zonas inmobiliarias
- 📊 Lead scoring automático basado en actividad
- 📝 Generación automática de contenido de marketing
- 💬 Chatbot hipotecario con GPT-4
- 📄 Validación inteligente de documentos

## 🛠️ Stack Tecnológico

### Frontend
- **React 19** - Framework principal
- **TypeScript** - Tipado estático
- **Tailwind CSS 4** - Estilos
- **React Router** - Navegación
- **Vite** - Build tool

### Backend
- **Node.js** - Runtime
- **Express.js** - Framework web
- **MongoDB Atlas** - Base de datos (Mongoose)
- **JWT** - Autenticación
- **OpenAI API** - Integración de IA

## 📋 Prerrequisitos

- Node.js 18.x o superior (recomendado 20.x)
- MongoDB Atlas (cuenta gratuita disponible)
- npm o yarn
- Cuenta de OpenAI (opcional, para funcionalidades de IA)

## 🎯 Acerca de RockIt

**RockIt** es la plataforma CRM inmobiliario de nueva generación que combina inteligencia artificial con herramientas de gestión profesional para transformar la forma en que los agentes inmobiliarios trabajan.

## 🔧 Instalación

### 1. Clonar el repositorio

```bash
git clone <url-del-repositorio>
cd free-react-tailwind-admin-dashboard-main
```

### 2. Configurar el Backend

```bash
cd backend
npm install
```

Crear archivo `.env` basado en `.env.example`:

```bash
cp .env.example .env
```

Editar `.env` con tus credenciales:

```env
PORT=5000
NODE_ENV=development

DB_HOST=localhost
DB_PORT=5432
DB_NAME=crm_inmobiliario
DB_USER=postgres
DB_PASSWORD=tu_contraseña

JWT_SECRET=tu_secreto_jwt_super_seguro
JWT_EXPIRES_IN=7d

OPENAI_API_KEY=tu_api_key_de_openai
MAPBOX_ACCESS_TOKEN=tu_token_de_mapbox
```

### 3. Configurar MongoDB Atlas

**Configurar la conexión a MongoDB Atlas:**

1. Crea una cuenta en [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) (gratis)
2. Crea un cluster
3. Obtén tu connection string
4. Agrega tu IP a la whitelist (o usa `0.0.0.0/0` para desarrollo)

En el archivo `backend/.env`, configura:

```env
MONGODB_URI=mongodb+srv://usuario:contraseña@cluster.mongodb.net/crm_inmobiliario?retryWrites=true&w=majority
```

**Verificar conexión:**
```bash
cd backend
npm run check-db
```

**Nota:** MongoDB crea las colecciones automáticamente, no se necesitan migraciones.

Crear usuario admin:

```bash
npm run migrate
```

Crear usuario admin inicial:

```bash
npm run seed
```

O ejecuta el script batch:
```bash
backend\scripts\create-admin.bat
```

**Credenciales por defecto del admin:**
- Email: `admin@crm.com`
- Password: `admin123`

⚠️ **IMPORTANTE**: Cambia la contraseña después del primer inicio de sesión. Puedes personalizar las credenciales en el archivo `.env` del backend.

### 4. Configurar el Frontend

```bash
cd ..
npm install
```

Crear archivo `.env` en la raíz del proyecto:

```env
VITE_API_URL=http://localhost:5000/api
```

### 5. Ejecutar el Proyecto

#### Opción 1: Script Automático (Recomendado para Windows)

**Windows (CMD):**
```bash
start-system.bat
```

**Windows (PowerShell):**
```powershell
.\start-system.ps1
```

Este script:
- Verifica que Node.js esté instalado
- Instala dependencias si es necesario
- Inicia el backend y frontend en ventanas separadas

**Para detener el sistema:**
```bash
stop-system.bat
```

#### Opción 2: Manual

**Backend** (en una terminal):

```bash
cd backend
npm run dev
```

**Frontend** (en otra terminal):

```bash
npm run dev
```

El frontend estará disponible en `http://localhost:5173` y el backend en `http://localhost:5000`.

## 📁 Estructura del Proyecto

```
free-react-tailwind-admin-dashboard-main/
├── backend/
│   ├── config/
│   │   └── database.js          # Configuración de PostgreSQL
│   ├── middleware/
│   │   └── auth.js              # Middleware de autenticación JWT
│   ├── routes/
│   │   ├── auth.js              # Rutas de autenticación
│   │   ├── contacts.js          # Rutas de contactos
│   │   ├── properties.js         # Rutas de propiedades
│   │   ├── deals.js             # Rutas de transacciones
│   │   ├── farming.js            # Rutas de farming predictivo
│   │   ├── automation.js        # Rutas de automatización
│   │   └── ai.js                # Rutas de IA (chat, generación)
│   ├── scripts/
│   │   └── migrate.js            # Script de migración de BD
│   ├── uploads/                 # Carpeta para documentos
│   ├── server.js                # Servidor principal
│   └── package.json
├── src/
│   ├── components/              # Componentes reutilizables
│   ├── pages/
│   │   ├── Dashboard/           # Dashboard principal
│   │   └── CRM/                 # Páginas del CRM
│   │       ├── Contacts.tsx
│   │       ├── Properties.tsx
│   │       ├── Deals.tsx
│   │       ├── Farming.tsx
│   │       ├── Automation.tsx
│   │       └── MortgageChat.tsx
│   ├── services/
│   │   └── api.ts               # Cliente API
│   └── App.tsx                  # Componente principal
└── README.md
```

## 🔐 Autenticación

El sistema utiliza JWT (JSON Web Tokens) para la autenticación. Los tokens se almacenan en `localStorage` del navegador.

### Flujo de Autenticación

1. Usuario se registra o inicia sesión
2. Backend genera un JWT token
3. Token se almacena en `localStorage`
4. Todas las peticiones incluyen el token en el header `Authorization: Bearer <token>`

## 📊 Base de Datos

### Tablas Principales

- **users**: Usuarios del sistema (agentes/brokers)
- **contacts**: Contactos/leads
- **properties**: Propiedades/listings
- **deals**: Transacciones
- **documents**: Documentos asociados a deals
- **lead_activities**: Actividades de leads (para scoring)
- **workflows**: Automatizaciones configuradas
- **farming_zones**: Zonas de farming analizadas

## 🤖 Integración con IA

### OpenAI API

El sistema utiliza OpenAI GPT-4 para:

1. **Asistente Rockit**: Chatbot especializado con prompt de sistema
2. **Generación de Contenido Social**: Posts para redes sociales
3. **Kit de Farming Digital**: Copys de marketing, emails y guiones

### Configuración

Agregar tu API key de OpenAI en el archivo `.env` del backend:

```env
OPENAI_API_KEY=sk-tu-api-key-aqui
```

**Nota**: Si no tienes una API key, el sistema funcionará con respuestas mockeadas para desarrollo.

## 🗺️ Farming Predictivo

El módulo de Farming Predictivo analiza zonas geográficas para identificar oportunidades. En producción, se recomienda integrar:

- **Mapbox** o **Google Maps** para visualización de mapas
- APIs de datos inmobiliarios (Zillow, Redfin, etc.)
- APIs de datos demográficos
- APIs de análisis de sentimiento social

### Uso

1. Seleccionar una zona en el mapa (o ingresar coordenadas)
2. El sistema analiza la zona y genera un reporte
3. Generar kit de marketing digital con IA

## 📝 API Endpoints

### Autenticación
- `POST /api/auth/register` - Registro de usuario
- `POST /api/auth/login` - Inicio de sesión
- `GET /api/auth/me` - Obtener usuario actual

### Contactos
- `GET /api/contacts` - Listar contactos
- `GET /api/contacts/:id` - Obtener contacto
- `POST /api/contacts` - Crear contacto
- `PUT /api/contacts/:id` - Actualizar contacto
- `DELETE /api/contacts/:id` - Eliminar contacto
- `POST /api/contacts/:id/activities` - Registrar actividad

### Propiedades
- `GET /api/properties` - Listar propiedades
- `GET /api/properties/:id` - Obtener propiedad
- `POST /api/properties` - Crear propiedad
- `PUT /api/properties/:id` - Actualizar propiedad
- `DELETE /api/properties/:id` - Eliminar propiedad

### Transacciones (Deals)
- `GET /api/deals` - Listar deals
- `GET /api/deals/:id` - Obtener deal con documentos
- `POST /api/deals` - Crear deal
- `PUT /api/deals/:id` - Actualizar deal
- `POST /api/deals/:id/documents` - Subir documento
- `PUT /api/deals/:id/documents/:docId` - Actualizar documento

### Farming
- `GET /api/farming/zones` - Listar zonas guardadas
- `POST /api/farming/analyze` - Analizar zona
- `POST /api/farming/generate-kit` - Generar kit de marketing
- `POST /api/farming/zones` - Guardar zona

### Automatización
- `GET /api/automation/workflows` - Listar workflows
- `POST /api/automation/workflows` - Crear workflow
- `PUT /api/automation/workflows/:id` - Actualizar workflow
- `DELETE /api/automation/workflows/:id` - Eliminar workflow

### IA
- `POST /api/ai/chat/mortgage` - Chat hipotecario
- `POST /api/ai/generate-social-content` - Generar contenido social

## 🚀 Despliegue

### Backend

1. Configurar variables de entorno en producción
2. Usar un servicio de hosting (Heroku, Railway, AWS, etc.)
3. Configurar PostgreSQL en la nube (Supabase, AWS RDS, etc.)

### Frontend

1. Construir para producción:
```bash
npm run build
```

2. Desplegar en Vercel, Netlify, o similar

3. Configurar `VITE_API_URL` con la URL de tu backend en producción

## 🔒 Seguridad

- Las contraseñas se hashean con bcrypt
- JWT tokens con expiración
- Validación de datos en backend
- CORS configurado
- Sanitización de inputs

## 📚 Próximas Mejoras

- [ ] Integración con mapas interactivos (Mapbox/Google Maps)
- [ ] Sistema de notificaciones en tiempo real
- [ ] Dashboard de analytics avanzado
- [ ] Integración con APIs inmobiliarias reales
- [ ] Sistema de reportes y exportación
- [ ] App móvil
- [ ] Integración con calendario y recordatorios

## 📄 Licencia

Este proyecto está bajo la Licencia MIT.

## 👥 Contribución

Las contribuciones son bienvenidas. Por favor:

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

## 📞 Soporte

Para soporte, abre un issue en el repositorio o contacta al equipo de desarrollo.

---

**Desarrollado con ❤️ para el sector inmobiliario**
