# 🔐 Credenciales de Administrador - RockIt

## Usuario Admin por Defecto

Después de configurar MongoDB Atlas, puedes crear un usuario administrador con el siguiente comando:

### Crear Usuario Admin

**Desde la carpeta backend:**
```bash
cd backend
npm run seed
```

**O ejecuta el script batch:**
```bash
backend\scripts\create-admin.bat
```

### Credenciales por Defecto

Una vez ejecutado el script, las credenciales serán:

```
Email:    admin@crm.com
Password: admin123
Role:     admin
```

## Personalizar Credenciales

Puedes personalizar las credenciales del admin agregando estas variables en el archivo `backend/.env`:

```env
ADMIN_EMAIL=tu_email@admin.com
ADMIN_PASSWORD=tu_contraseña_segura
ADMIN_FIRST_NAME=Tu Nombre
ADMIN_LAST_NAME=Tu Apellido
```

Luego ejecuta:
```bash
npm run seed
```

## Primera Vez - Pasos Completos

1. **Ejecutar migraciones:**
   ```bash
   cd backend
   npm run migrate
   ```

2. **Crear usuario admin:**
   ```bash
   npm run seed
   ```

3. **Iniciar el sistema:**
   ```bash
   cd ..
   start-system.bat
   ```

4. **Iniciar sesión:**
   - Ve a http://localhost:5173
   - Usa las credenciales: `admin@crm.com` / `admin123`

## ⚠️ Seguridad

**IMPORTANTE**: 
- Cambia la contraseña después del primer inicio de sesión
- En producción, usa credenciales seguras y únicas
- No compartas las credenciales por defecto en producción

## Crear Usuarios Adicionales

Puedes crear usuarios adicionales desde la interfaz web:
1. Inicia sesión como admin
2. Ve a la página de registro (o crea un endpoint de administración)
3. O usa la API directamente:

```bash
POST http://localhost:5000/api/auth/register
Content-Type: application/json

{
  "email": "nuevo@usuario.com",
  "password": "contraseña123",
  "firstName": "Nombre",
  "lastName": "Apellido"
}
```

## Roles Disponibles

Actualmente el sistema soporta los siguientes roles:
- `admin` - Administrador del sistema
- `agent` - Agente inmobiliario (por defecto)

Los roles se pueden extender según las necesidades del proyecto.

