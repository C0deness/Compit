# 🔧 Solución de Problemas de PostgreSQL

## Error: ECONNREFUSED en puerto 5432

Este error indica que PostgreSQL no está ejecutándose o no es accesible.

## Pasos para Solucionar

### 1. Verificar que PostgreSQL esté Instalado

**Windows:**
- Abre el "Administrador de Servicios" (services.msc)
- Busca "postgresql" o "PostgreSQL"
- Verifica que el servicio esté "En ejecución"

**O desde la terminal:**
```cmd
sc query postgresql
```

### 2. Iniciar PostgreSQL

**Opción A: Desde el Administrador de Servicios**
1. Abre `services.msc`
2. Busca "PostgreSQL"
3. Click derecho → "Iniciar"

**Opción B: Desde la terminal (como administrador)**
```cmd
net start postgresql-x64-XX
```
(Reemplaza XX con tu versión, ej: 14, 15, 16)

**Opción C: Desde psql**
```cmd
pg_ctl start -D "C:\Program Files\PostgreSQL\XX\data"
```

### 3. Verificar la Configuración

Asegúrate de que el archivo `backend/.env` tenga la configuración correcta:

```env
DB_HOST=localhost
DB_PORT=5432
DB_NAME=crm_inmobiliario
DB_USER=postgres
DB_PASSWORD=tu_contraseña_postgres
```

### 4. Verificar Conexión

Ejecuta el script de verificación:

```cmd
cd backend
npm run check-db
```

Este script te dirá exactamente qué está mal.

### 5. Crear la Base de Datos

Si PostgreSQL está ejecutándose pero la base de datos no existe:

**Opción A: Desde psql**
```cmd
psql -U postgres
```

Luego en psql:
```sql
CREATE DATABASE crm_inmobiliario;
\q
```

**Opción B: Desde la terminal directamente**
```cmd
psql -U postgres -c "CREATE DATABASE crm_inmobiliario;"
```

### 6. Verificar Credenciales

Si no puedes conectarte, verifica:

1. **Usuario y contraseña correctos:**
   - Por defecto, el usuario es `postgres`
   - La contraseña es la que configuraste durante la instalación

2. **Resetear contraseña de postgres (si la olvidaste):**
   ```cmd
   # Edita el archivo pg_hba.conf
   # Cambia "md5" a "trust" temporalmente
   # Reinicia PostgreSQL
   # Luego cambia la contraseña:
   psql -U postgres
   ALTER USER postgres PASSWORD 'nueva_contraseña';
   # Vuelve a cambiar pg_hba.conf a "md5"
   ```

## Verificación Rápida

Ejecuta este comando para verificar que PostgreSQL esté escuchando:

```cmd
netstat -an | findstr 5432
```

Deberías ver algo como:
```
TCP    0.0.0.0:5432           0.0.0.0:0              LISTENING
```

## Instalación de PostgreSQL (si no está instalado)

1. Descarga PostgreSQL desde: https://www.postgresql.org/download/windows/
2. Ejecuta el instalador
3. Durante la instalación:
   - Anota la contraseña del usuario `postgres`
   - Asegúrate de que el puerto sea `5432`
4. Completa la instalación
5. Verifica que el servicio esté ejecutándose

## Alternativa: Usar PostgreSQL en Docker

Si prefieres usar Docker:

```cmd
docker run --name postgres-crm -e POSTGRES_PASSWORD=postgres -e POSTGRES_DB=crm_inmobiliario -p 5432:5432 -d postgres
```

Luego en `backend/.env`:
```env
DB_HOST=localhost
DB_PORT=5432
DB_NAME=crm_inmobiliario
DB_USER=postgres
DB_PASSWORD=postgres
```

## Script de Verificación Automática

He creado un script que verifica automáticamente la conexión:

```cmd
cd backend
npm run check-db
```

Este script te mostrará:
- ✅ Si la conexión es exitosa
- ❌ Si hay problemas y cómo solucionarlos
- ⚠️ Si la base de datos no existe

## Orden Correcto de Ejecución

1. ✅ PostgreSQL ejecutándose
2. ✅ Base de datos `crm_inmobiliario` creada
3. ✅ Archivo `backend/.env` configurado correctamente
4. ✅ Ejecutar `npm run check-db` para verificar
5. ✅ Ejecutar `npm run migrate` para crear tablas
6. ✅ Ejecutar `npm run seed` para crear usuario admin

---

**¿Sigue sin funcionar?** Verifica los logs de PostgreSQL en:
- Windows: `C:\Program Files\PostgreSQL\XX\data\log\`


